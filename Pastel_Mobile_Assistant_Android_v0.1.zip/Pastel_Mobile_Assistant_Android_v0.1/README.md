# Pastel Mobile Assistant

Android companion for Sage Pastel Accounting (desktop/non-cloud workflow).

Features in this build:
- Import a bank CSV and detect recurring payment identities such as `HOLLARD 6957` and `VODACOM 3783`.
- Save GL account + VAT treatment for each recurring identity while always taking the amount from the current CSV.
- Photograph an invoice and extract text on-device with ML Kit OCR.
- Choose Supplier or Customer, review/edit invoice fields, and generate a Pastel-ready CSV for review/import.
- Share/email generated CSV files using Android's secure share sheet.

**Safety:** generated files are intended to be reviewed in Sage Pastel before Update/Process.
