package za.co.pastelassistant.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int REQ_BANK = 1001;
    private static final int REQ_CAMERA = 1002;

    private final ArrayList<BankTxn> bankTransactions = new ArrayList<>();
    private final LinkedHashMap<String, ArrayList<BankTxn>> repeatGroups = new LinkedHashMap<>();

    private SharedPreferences prefs;
    private Spinner repeatSpinner;
    private Spinner documentTypeSpinner;
    private EditText glAccountEdit;
    private CheckBox vatCheck;
    private EditText partyEdit;
    private EditText invoiceNoEdit;
    private EditText invoiceDateEdit;
    private EditText invoiceTotalEdit;
    private EditText invoiceVatEdit;
    private TextView statusView;
    private Uri invoicePhotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("pastel_mobile_rules", MODE_PRIVATE);
        buildUi();
        refreshRepeatSpinner();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Pastel Mobile Assistant");
        title.setTextSize(24f);
        title.setPadding(0, 0, 0, dp(6));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Bank payments + invoice capture • review before Pastel import");
        subtitle.setPadding(0, 0, 0, dp(16));
        root.addView(subtitle);

        Button importBank = button("Import bank CSV");
        importBank.setOnClickListener(v -> chooseBankCsv());
        root.addView(importBank);

        addLabel(root, "Repeat description");
        repeatSpinner = new Spinner(this);
        root.addView(repeatSpinner, matchWrap());
        repeatSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener() {
            @Override
            public void onSelected(int position) {
                loadSelectedRule();
            }
        });

        addLabel(root, "General ledger account");
        glAccountEdit = edit("e.g. 6100/005");
        root.addView(glAccountEdit, matchWrap());

        vatCheck = new CheckBox(this);
        vatCheck.setText("Apply VAT / tax treatment");
        root.addView(vatCheck);

        Button saveRule = button("Save recurring rule");
        saveRule.setOnClickListener(v -> saveSelectedRule());
        root.addView(saveRule);

        Button exportBank = button("Generate & email Pastel bank CSV");
        exportBank.setOnClickListener(v -> exportBankCsv());
        root.addView(exportBank);

        divider(root);

        TextView scanTitle = new TextView(this);
        scanTitle.setText("Invoice capture");
        scanTitle.setTextSize(20f);
        scanTitle.setPadding(0, dp(8), 0, dp(8));
        root.addView(scanTitle);

        Button camera = button("Take invoice photo");
        camera.setOnClickListener(v -> takeInvoicePhoto());
        root.addView(camera);

        addLabel(root, "Document type");
        documentTypeSpinner = new Spinner(this);
        documentTypeSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Supplier", "Customer"}));
        root.addView(documentTypeSpinner, matchWrap());

        addLabel(root, "Supplier / customer name");
        partyEdit = edit("Detected from invoice");
        root.addView(partyEdit, matchWrap());

        addLabel(root, "Invoice number");
        invoiceNoEdit = edit("Invoice number");
        root.addView(invoiceNoEdit, matchWrap());

        addLabel(root, "Invoice date");
        invoiceDateEdit = edit("YYYY-MM-DD or statement date");
        root.addView(invoiceDateEdit, matchWrap());

        addLabel(root, "Invoice total");
        invoiceTotalEdit = edit("0.00");
        invoiceTotalEdit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        root.addView(invoiceTotalEdit, matchWrap());

        addLabel(root, "VAT amount");
        invoiceVatEdit = edit("0.00");
        invoiceVatEdit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        root.addView(invoiceVatEdit, matchWrap());

        Button exportInvoice = button("Generate & email invoice Pastel CSV");
        exportInvoice.setOnClickListener(v -> exportInvoiceCsv());
        root.addView(exportInvoice);

        divider(root);
        statusView = new TextView(this);
        statusView.setText("Ready.");
        statusView.setPadding(0, dp(8), 0, 0);
        root.addView(statusView);

        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void divider(LinearLayout root) {
        View line = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(18), 0, dp(12));
        line.setBackgroundColor(0x22000000);
        root.addView(line, lp);
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setPadding(0, dp(12), 0, dp(4));
        root.addView(label);
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        return e;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        return b;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void chooseBankCsv() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/csv", "text/comma-separated-values", "text/plain"});
        startActivityForResult(i, REQ_BANK);
    }

    private void takeInvoicePhoto() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            toast("No camera app is available.");
            return;
        }
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (dir == null) throw new IOException("Pictures directory unavailable");
            File photo = File.createTempFile("invoice_", ".jpg", dir);
            invoicePhotoUri = FileProvider.getUriForFile(this,
                    getPackageName() + ".files", photo);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, invoicePhotoUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, REQ_CAMERA);
        } catch (IOException e) {
            showError("Could not prepare camera file", e);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        if (requestCode == REQ_BANK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            status("Reading bank CSV…");
            new Thread(() -> {
                try {
                    parseBankCsv(uri);
                    runOnUiThread(() -> {
                        refreshRepeatSpinner();
                        status(bankTransactions.size() + " payment rows loaded; " + repeatGroups.size() + " repeat descriptions detected.");
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> showError("Could not read bank CSV", e));
                }
            }).start();
        } else if (requestCode == REQ_CAMERA && invoicePhotoUri != null) {
            runInvoiceOcr(invoicePhotoUri);
        }
    }

    private void parseBankCsv(Uri uri) throws IOException {
        ArrayList<String> lines = new ArrayList<>();
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) lines.add(line);
            }
        }
        if (lines.isEmpty()) throw new IOException("CSV is empty");

        int headerLine = findHeaderLine(lines);
        List<String> header = parseCsvLine(lines.get(headerLine));
        int dateIdx = findHeader(header, "date", "transaction date", "value date");
        int descIdx = findHeader(header, "description", "details", "narrative", "transaction description", "reference");
        int refIdx = findHeader(header, "reference", "ref", "beneficiary reference");
        int amountIdx = findHeader(header, "amount", "transaction amount");
        int debitIdx = findHeader(header, "debit", "debit amount", "payments");
        int creditIdx = findHeader(header, "credit", "credit amount", "receipts");

        if (descIdx < 0) throw new IOException("Could not identify a description/reference column in the CSV");
        if (amountIdx < 0 && debitIdx < 0) throw new IOException("Could not identify an amount/debit column in the CSV");

        ArrayList<BankTxn> parsed = new ArrayList<>();
        for (int n = headerLine + 1; n < lines.size(); n++) {
            List<String> row = parseCsvLine(lines.get(n));
            if (row.size() <= descIdx) continue;
            String desc = safe(row, descIdx).trim();
            String ref = refIdx >= 0 ? safe(row, refIdx).trim() : "";
            String combined = (desc + " " + ref).trim();
            if (combined.isEmpty()) continue;

            double amount;
            boolean isPayment;
            if (debitIdx >= 0 && debitIdx < row.size()) {
                double debit = parseMoney(safe(row, debitIdx));
                if (Math.abs(debit) > 0.00001) {
                    amount = Math.abs(debit);
                    isPayment = true;
                } else if (amountIdx >= 0) {
                    double raw = parseMoney(safe(row, amountIdx));
                    amount = Math.abs(raw);
                    isPayment = raw < 0;
                } else {
                    continue;
                }
            } else {
                double raw = parseMoney(safe(row, amountIdx));
                amount = Math.abs(raw);
                isPayment = raw < 0;
                if (creditIdx >= 0 && creditIdx < row.size() && Math.abs(parseMoney(safe(row, creditIdx))) > 0.00001) {
                    isPayment = false;
                }
            }
            if (!isPayment || amount <= 0.00001) continue;
            String date = dateIdx >= 0 ? safe(row, dateIdx).trim() : "";
            BankTxn t = new BankTxn(date, combined, amount, recurringKey(combined));
            parsed.add(t);
        }

        synchronized (bankTransactions) {
            bankTransactions.clear();
            bankTransactions.addAll(parsed);
            repeatGroups.clear();
            for (BankTxn t : parsed) {
                repeatGroups.computeIfAbsent(t.key, k -> new ArrayList<>()).add(t);
            }
            repeatGroups.entrySet().removeIf(e -> e.getValue().size() < 2 && !hasRule(e.getKey()));
        }
    }

    private int findHeaderLine(List<String> lines) {
        int max = Math.min(lines.size(), 15);
        for (int i = 0; i < max; i++) {
            String lower = lines.get(i).toLowerCase(Locale.ROOT);
            if ((lower.contains("description") || lower.contains("details") || lower.contains("reference"))
                    && (lower.contains("amount") || lower.contains("debit") || lower.contains("payments"))) {
                return i;
            }
        }
        return 0;
    }

    private int findHeader(List<String> header, String... aliases) {
        for (int i = 0; i < header.size(); i++) {
            String h = header.get(i).trim().toLowerCase(Locale.ROOT);
            for (String alias : aliases) {
                if (h.equals(alias) || h.contains(alias)) return i;
            }
        }
        return -1;
    }

    private List<String> parseCsvLine(String line) {
        ArrayList<String> out = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    cell.append('"'); i++;
                } else {
                    quoted = !quoted;
                }
            } else if (c == ',' && !quoted) {
                out.add(cell.toString()); cell.setLength(0);
            } else {
                cell.append(c);
            }
        }
        out.add(cell.toString());
        return out;
    }

    private String safe(List<String> row, int idx) {
        return idx >= 0 && idx < row.size() ? row.get(idx) : "";
    }

    private double parseMoney(String raw) {
        if (raw == null) return 0;
        String s = raw.trim().replace("R", "").replace(" ", "").replace("\u00A0", "");
        boolean negative = s.startsWith("(") && s.endsWith(")");
        s = s.replace("(", "").replace(")", "");
        if (s.contains(",") && s.contains(".")) {
            s = s.replace(",", "");
        } else if (s.contains(",") && !s.contains(".")) {
            int lastComma = s.lastIndexOf(',');
            if (s.length() - lastComma == 3) s = s.replace(',', '.'); else s = s.replace(",", "");
        }
        s = s.replaceAll("[^0-9.\\-]", "");
        if (s.isEmpty() || s.equals("-") || s.equals(".")) return 0;
        try {
            double v = Double.parseDouble(s);
            return negative ? -Math.abs(v) : v;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String recurringKey(String description) {
        String upper = description.toUpperCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        if (upper.isEmpty()) return "UNKNOWN";
        String[] tokens = upper.split(" ");

        ArrayList<String> merchantWords = new ArrayList<>();
        for (String token : tokens) {
            if (token.matches(".*\\d.*")) break;
            String cleaned = token.replaceAll("[^A-Z&]", "");
            if (!cleaned.isEmpty()) merchantWords.add(cleaned);
            if (merchantWords.size() >= 3) break;
        }
        if (merchantWords.isEmpty()) {
            String first = tokens[0].replaceAll("[^A-Z]", "");
            merchantWords.add(first.isEmpty() ? "PAYMENT" : first);
        }
        String merchant = join(merchantWords, " ");

        String bestDigits = null;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < tokens.length; i++) {
            String token = tokens[i].replaceAll("[^A-Z0-9\\-/]", "");
            if (!token.matches(".*\\d.*")) continue;
            String[] parts = token.split("[-/]");
            for (int p = 0; p < parts.length; p++) {
                String part = parts[p];
                String digits = part.replaceAll("\\D", "");
                if (digits.length() < 4) continue;
                if (looksLikeDateCode(digits)) continue;
                int score = 20 - i;
                if (part.matches(".*[A-Z].*")) score += 100;
                if (p == 0) score += 25;
                if (digits.length() >= 7 && digits.length() <= 10) score += 10;
                if (digits.length() > 12) score -= 20;
                if (score > bestScore) {
                    bestScore = score;
                    bestDigits = digits;
                }
            }
        }
        if (bestDigits != null) {
            String suffix = bestDigits.substring(Math.max(0, bestDigits.length() - 4));
            return merchant + " " + suffix;
        }
        return merchant;
    }

    private boolean looksLikeDateCode(String digits) {
        if (digits.length() != 6 && digits.length() != 8) return false;
        try {
            if (digits.length() == 6) {
                int mm = Integer.parseInt(digits.substring(2, 4));
                int dd = Integer.parseInt(digits.substring(4, 6));
                return mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31;
            }
            int mm = Integer.parseInt(digits.substring(4, 6));
            int dd = Integer.parseInt(digits.substring(6, 8));
            return mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31;
        } catch (Exception ignored) {
            return false;
        }
    }

    private String join(List<String> parts, String sep) {
        StringBuilder b = new StringBuilder();
        for (String s : parts) {
            if (b.length() > 0) b.append(sep);
            b.append(s);
        }
        return b.toString();
    }

    private void refreshRepeatSpinner() {
        Set<String> keys = new LinkedHashSet<>();
        synchronized (bankTransactions) {
            keys.addAll(repeatGroups.keySet());
        }
        for (String prefKey : prefs.getAll().keySet()) {
            if (prefKey.startsWith("rule.")) keys.add(prefKey.substring(5));
        }
        ArrayList<String> display = new ArrayList<>();
        display.add("Select repeat description");
        for (String key : keys) {
            int count = repeatGroups.containsKey(key) ? repeatGroups.get(key).size() : 0;
            display.add(count > 0 ? key + " (x" + count + ")" : key);
        }
        repeatSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, display));
    }

    private String selectedRepeatKey() {
        if (repeatSpinner == null || repeatSpinner.getSelectedItemPosition() <= 0) return null;
        String s = String.valueOf(repeatSpinner.getSelectedItem());
        return s.replaceFirst(" \\(x\\d+\\)$", "");
    }

    private boolean hasRule(String key) {
        return prefs.contains("rule." + key);
    }

    private JSONObject getRule(String key) {
        String raw = prefs.getString("rule." + key, null);
        if (raw == null) return null;
        try { return new JSONObject(raw); } catch (JSONException e) { return null; }
    }

    private void loadSelectedRule() {
        String key = selectedRepeatKey();
        if (key == null || glAccountEdit == null) return;
        JSONObject rule = getRule(key);
        if (rule == null) {
            glAccountEdit.setText("");
            vatCheck.setChecked(false);
        } else {
            glAccountEdit.setText(rule.optString("gl", ""));
            vatCheck.setChecked(rule.optBoolean("vat", false));
        }
    }

    private void saveSelectedRule() {
        String key = selectedRepeatKey();
        if (key == null) {
            toast("Select a repeat description first.");
            return;
        }
        String gl = glAccountEdit.getText().toString().trim();
        if (gl.isEmpty()) {
            toast("Enter a GL account.");
            return;
        }
        try {
            JSONObject rule = new JSONObject();
            rule.put("gl", gl);
            rule.put("vat", vatCheck.isChecked());
            prefs.edit().putString("rule." + key, rule.toString()).apply();
            status("Saved: " + key + " → " + gl + (vatCheck.isChecked() ? " (VAT)" : " (No VAT)"));
        } catch (JSONException e) {
            showError("Could not save rule", e);
        }
    }

    private void exportBankCsv() {
        ArrayList<BankTxn> copy;
        synchronized (bankTransactions) {
            copy = new ArrayList<>(bankTransactions);
        }
        if (copy.isEmpty()) {
            toast("Import a bank CSV first.");
            return;
        }
        LinkedHashSet<String> missing = new LinkedHashSet<>();
        for (BankTxn t : copy) if (getRule(t.key) == null) missing.add(t.key);
        if (!missing.isEmpty()) {
            StringBuilder msg = new StringBuilder("Assign a GL/VAT rule before export for:\n\n");
            int shown = 0;
            for (String key : missing) {
                msg.append("• ").append(key).append('\n');
                if (++shown >= 12) { msg.append("…and more"); break; }
            }
            new AlertDialog.Builder(this)
                    .setTitle("Export blocked")
                    .setMessage(msg.toString())
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }

        try {
            File file = createExportFile("Pastel_Bank_Payments_" + stamp() + ".csv");
            try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
                for (BankTxn t : copy) {
                    JSONObject rule = getRule(t.key);
                    String[] cols = new String[18];
                    for (int i = 0; i < cols.length; i++) cols[i] = "";
                    cols[0] = t.date;
                    cols[1] = t.key;
                    cols[2] = t.description;
                    cols[3] = rule.optString("gl", "");
                    cols[4] = rule.optBoolean("vat", false) ? "VAT" : "NO VAT";
                    cols[5] = String.format(Locale.US, "%.2f", t.amount);
                    w.write(csvRow(cols));
                    w.write("\r\n");
                }
            }
            status("Pastel bank CSV created: " + file.getName());
            shareFile(file, "Pastel bank payments import");
        } catch (Exception e) {
            showError("Could not generate bank CSV", e);
        }
    }

    private void runInvoiceOcr(Uri uri) {
        status("Reading invoice…");
        try {
            InputImage image = InputImage.fromFilePath(this, uri);
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        parseInvoiceText(result.getText());
                        status("Invoice text detected. Check every field before export.");
                        recognizer.close();
                    })
                    .addOnFailureListener(e -> {
                        showError("Invoice OCR failed", e);
                        recognizer.close();
                    });
        } catch (IOException e) {
            showError("Could not read invoice image", e);
        }
    }

    private void parseInvoiceText(String text) {
        if (text == null) text = "";
        String[] lines = text.split("\\r?\\n");
        String party = "";
        for (String line : lines) {
            String s = line.trim();
            if (s.length() >= 3 && s.matches(".*[A-Za-z].*")) {
                party = s;
                break;
            }
        }
        if (!party.isEmpty()) partyEdit.setText(party);

        Matcher inv = Pattern.compile("(?i)(?:invoice|inv\\.?|tax invoice)[^A-Z0-9]{0,12}([A-Z0-9][A-Z0-9\\-/]{2,})").matcher(text);
        if (inv.find()) invoiceNoEdit.setText(inv.group(1));

        Matcher date = Pattern.compile("\\b(20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2}|\\d{1,2}[-/]\\d{1,2}[-/]20\\d{2})\\b").matcher(text);
        if (date.find()) invoiceDateEdit.setText(date.group(1));

        String total = findMoneyNearKeyword(lines, new String[]{"TOTAL DUE", "AMOUNT DUE", "TOTAL"});
        if (total != null) invoiceTotalEdit.setText(total);
        String vat = findMoneyNearKeyword(lines, new String[]{"VAT", "TAX"});
        if (vat != null) invoiceVatEdit.setText(vat);
    }

    private String findMoneyNearKeyword(String[] lines, String[] keywords) {
        Pattern money = Pattern.compile("(?:R\\s*)?([0-9][0-9 ,]*[.,][0-9]{2})");
        for (String keyword : keywords) {
            for (int i = lines.length - 1; i >= 0; i--) {
                String upper = lines[i].toUpperCase(Locale.ROOT);
                if (!upper.contains(keyword)) continue;
                Matcher m = money.matcher(lines[i]);
                String last = null;
                while (m.find()) last = m.group(1);
                if (last != null) return String.format(Locale.US, "%.2f", Math.abs(parseMoney(last)));
                if (i + 1 < lines.length) {
                    m = money.matcher(lines[i + 1]);
                    while (m.find()) last = m.group(1);
                    if (last != null) return String.format(Locale.US, "%.2f", Math.abs(parseMoney(last)));
                }
            }
        }
        return null;
    }

    private void exportInvoiceCsv() {
        String party = partyEdit.getText().toString().trim();
        String invNo = invoiceNoEdit.getText().toString().trim();
        String date = invoiceDateEdit.getText().toString().trim();
        double total = parseMoney(invoiceTotalEdit.getText().toString());
        double vat = parseMoney(invoiceVatEdit.getText().toString());
        String gl = glAccountEdit.getText().toString().trim();
        String type = String.valueOf(documentTypeSpinner.getSelectedItem());

        if (party.isEmpty() || invNo.isEmpty() || total <= 0) {
            toast("Check supplier/customer, invoice number and total first.");
            return;
        }
        if (gl.isEmpty()) {
            toast("Enter the GL account to use for the invoice detail line.");
            return;
        }

        try {
            File file = createExportFile("Pastel_" + type + "_Invoice_" + invNo.replaceAll("[^A-Za-z0-9_-]", "_") + "_" + stamp() + ".csv");
            try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
                String[] header = new String[]{"H", type.toUpperCase(Locale.ROOT), party, invNo, date,
                        String.format(Locale.US, "%.2f", total), String.format(Locale.US, "%.2f", vat)};
                String[] detail = new String[]{"D", gl, party + " " + invNo,
                        String.format(Locale.US, "%.2f", Math.max(0, total - vat)),
                        String.format(Locale.US, "%.2f", vat), String.format(Locale.US, "%.2f", total)};
                w.write(csvRow(header)); w.write("\r\n");
                w.write(csvRow(detail)); w.write("\r\n");
            }
            status(type + " invoice CSV created. Review it before importing/updating Pastel.");
            shareFile(file, "Pastel " + type + " invoice import");
        } catch (Exception e) {
            showError("Could not generate invoice CSV", e);
        }
    }

    private File createExportFile(String name) throws IOException {
        File dir = new File(getFilesDir(), "exports");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create exports directory");
        return new File(dir, name);
    }

    private void shareFile(File file, String subject) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", file);
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/csv");
        share.putExtra(Intent.EXTRA_SUBJECT, subject);
        share.putExtra(Intent.EXTRA_TEXT, "Attached Pastel import CSV. Please review the batch in Sage Pastel before Update/Process.");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, "Email / share Pastel file"));
    }

    private String csvRow(String[] values) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) b.append(',');
            String v = values[i] == null ? "" : values[i];
            if (v.contains(",") || v.contains("\"") || v.contains("\n") || v.contains("\r")) {
                b.append('"').append(v.replace("\"", "\"\"")).append('"');
            } else {
                b.append(v);
            }
        }
        return b.toString();
    }

    private String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    private void status(String text) {
        if (statusView != null) statusView.setText(text);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    private void showError(String title, Throwable e) {
        status(title + ": " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(e.getMessage() == null ? e.toString() : e.getMessage())
                .setPositiveButton("OK", null)
                .show();
    }

    private static class BankTxn {
        final String date;
        final String description;
        final double amount;
        final String key;

        BankTxn(String date, String description, double amount, String key) {
            this.date = date;
            this.description = description;
            this.amount = amount;
            this.key = key;
        }
    }

    private abstract static class SimpleItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {
        public abstract void onSelected(int position);
        @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { onSelected(position); }
        @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
    }
}
