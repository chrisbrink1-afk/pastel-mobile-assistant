Pastel Payment Assistant v1.11.15 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.15.exe

v1.11.15 UI and selection improvements:
- Auto and Manual quick-select actions are additive; clicking both keeps BOTH categories ticked.
- Main and recurring controls are grouped into clearer Allocation and Export Selection sections.
- Small ? icons beside the main actions show brief explanations when you hover the mouse over them.
- Rule amount-action, alternative GL, and alternative-description fields also include hover help.
- Existing selections remain ticked until you explicitly use a Clear action.

Retains saved-rule automatic behavior, resizable/scrollable Rule windows, amount-review controls, profiles, monthly references, and strict matching.
