from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
import tkinter as tk
from dataclasses import dataclass, field
from datetime import datetime, date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from tkinter import filedialog, messagebox, ttk, simpledialog
from typing import Optional, List, Dict, Tuple

APP_NAME = "Pastel Payment Assistant"
APP_VERSION = "1.11.22"
APP_DATA_NAMESPACE = "PastelPaymentAssistant"
APP_DATA_FALLBACK = ".pastel_payment_assistant"
SESSION_SETTING_KEY = "__autosaved_session_v1"
BUNDLED_RULES_FILENAME = "Pastel_Payment_Receipt_Rules_Backup.csv"
ALLOW_BUNDLED_RULE_BOOTSTRAP = True
DEFAULT_UI_MODE = "modern"
UI_MODES = {"modern", "classic"}
TUTORIAL_SETTING_KEY = "__tutorial_v2_state"

TUTORIAL_TOPICS = (
    {
        "id": "workflow", "title": "The complete workflow", "page": "dashboard",
        "keywords": "start beginner workflow load allocate select validate export pastel overview",
        "body": "The normal working cycle is: 1) Load the bank CSV. 2) Review and allocate Payments and Receipts. 3) Select the rows you want to export. 4) Validate the selection. 5) Export the separate Pastel Payment and Receipt files. Always review the imported Pastel batch before processing it."
    },
    {
        "id": "profiles", "title": "Company profiles", "page": "dashboard",
        "keywords": "company profile new company separate database switch company",
        "body": "Use one company profile per accounting workspace. Each profile keeps its own saved rules, settings, transaction history, recurring history and autosaved session. Switching profiles does not mix accounting data."
    },
    {
        "id": "settings", "title": "Essential Pastel settings", "page": "settings",
        "keywords": "settings contra bank gl vat tax type fiscal year period project",
        "body": "Before the first export, confirm the cash-book bank GL / contra setting, VAT tax type, VAT rate, fiscal-year start month and optional project code. The cash-book bank GL is a batch/cash-book setting, not a different contra for each transaction."
    },
    {
        "id": "load", "title": "Load a bank CSV", "page": "dashboard",
        "keywords": "load bank csv statement import bank file",
        "body": "Choose Load statement and select a supported bank CSV. The app separates outgoing Payments from incoming Receipts automatically and then applies saved rules for the active company profile."
    },
    {
        "id": "payments_receipts", "title": "Payments vs Receipts", "page": "payments",
        "keywords": "payment receipt money in money out negative positive bank amount sign",
        "body": "Payments are money leaving the bank. Receipts are money entering the bank. In the Pastel import, receipt GL-side amounts are intentionally exported as credits so Pastel displays a positive Bank Amount on the Receipts side."
    },
    {
        "id": "orange", "title": "Why is a transaction orange?", "page": "payments",
        "keywords": "orange unassigned no gl not allocated missing account",
        "body": "Orange means the transaction is unassigned: it does not yet have a usable GL account. Use Assign once for a statement-only allocation or create/edit a saved rule if the same stable identity should be automated in future statements."
    },
    {
        "id": "green", "title": "What does green mean?", "page": "payments",
        "keywords": "green assigned allocated status",
        "body": "Green means a GL allocation exists. Still review the GL, description and VAT treatment before export; green means assigned, not automatically accounting-approved."
    },
    {
        "id": "ambiguous", "title": "Ambiguous or conflicting rules", "page": "rules",
        "keywords": "ambiguous conflict two rules wrong match red",
        "body": "Ambiguous means equally strong saved rules disagree about the allocation. Resolve the conflicting saved rules before export. The app deliberately blocks ambiguous selected rows instead of guessing."
    },
    {
        "id": "assign_once", "title": "Assign once vs saved rule", "page": "payments",
        "keywords": "assign once manual save rule future statement automatic allocation",
        "body": "Assign once changes only the current statement row. Save rule from selected teaches the app how that stable bank identity should allocate on future statements. Use a saved rule only when you are confident the identity should receive the same treatment again."
    },
    {
        "id": "wrong_gl", "title": "An automatic allocation used the wrong GL", "page": "payments",
        "keywords": "wrong gl incorrect allocation fix correct auto allocation update rule",
        "body": "Use Correct auto-allocation. Choose a statement-only correction when this transaction is exceptional, or update the saved rule when future matching transactions should use the corrected GL/VAT/description."
    },
    {
        "id": "vat", "title": "VAT and tax type", "page": "settings",
        "keywords": "vat tax type 15 percent inclusive output input",
        "body": "VAT-enabled rows need a valid Pastel tax type. The app calculates the VAT portion from the VAT-inclusive bank amount using the profile VAT rate, but the user remains responsible for deciding whether VAT is appropriate for that accounting transaction."
    },
    {
        "id": "amount_rules", "title": "Amount-based rules", "page": "rules",
        "keywords": "amount threshold greater less review alternative gl unusual amount",
        "body": "A saved rule can apply an alternative GL/description when an amount condition is met, or send qualifying amounts to Review so a person allocates those transactions individually. Review mode is safer when the amount changes the accounting purpose."
    },
    {
        "id": "recurring", "title": "How recurring transactions work", "page": "recurring_payments",
        "keywords": "recurring payment receipt repeat missing recurring group identity child",
        "body": "Recurring screens group identities that have been seen repeatedly. The group is organisational only: every child transaction can still have its own GL, VAT, description and export checkbox. Recurrence grouping does not loosen the saved-rule allocation matcher."
    },
    {
        "id": "recurring_missing", "title": "A recurring transaction is missing", "page": "recurring_payments",
        "keywords": "missing recurring not showing repeat payee name reference changing",
        "body": "A recurring identity normally needs to be seen at least twice. Changing bank-generated references can cause otherwise similar transactions to look different; verified payee-normalisation handles known cases, but unfamiliar wording may still need review."
    },
    {
        "id": "selection", "title": "Auto and Manual export selection", "page": "payments",
        "keywords": "select auto manual additive tick checkbox clear all export selection",
        "body": "Add Auto-Allocated and Add Manual Allocations are additive. Using both keeps both groups ticked. Use Clear All only when you intentionally want to start the export selection over."
    },
    {
        "id": "validation", "title": "Validation errors", "page": "dashboard",
        "keywords": "validate error blocked export check selected unassigned ambiguous field length",
        "body": "Validation blocks unsafe selected rows such as unassigned transactions, ambiguous rule matches, missing VAT tax types and invalid Pastel field lengths. Resolve the error or untick the transaction before exporting."
    },
    {
        "id": "export", "title": "Export to Pastel", "page": "dashboard",
        "keywords": "export pastel csv payment receipt import cash book",
        "body": "Export selected to Pastel creates separate Payment and Receipt CSV files plus review/validation files. Import the Payment CSV on Pastel's Payments side and the Receipt CSV on the Receipts side."
    },
    {
        "id": "receipt_sign", "title": "Receipt Bank Amount is negative in Pastel", "page": "receipts",
        "keywords": "receipt negative minus sign bank amount wrong sign money in",
        "body": "In current builds, receipts use the corrected export sign so Pastel shows a positive Bank Amount on the Receipts side. If a receipt still shows negative, confirm the Receipt CSV was imported into Pastel's Receipts side and that the current build is being used."
    },
    {
        "id": "references", "title": "Pastel references", "page": "dashboard",
        "keywords": "reference sequence p6 r6 duplicate monthly number",
        "body": "Final export references are generated automatically as separate monthly Payment and Receipt sequences, for example P6-0001 and R6-0001. This prevents duplicate rule-level references from being reused across exported rows."
    },
    {
        "id": "autosave", "title": "Autosave and resume", "page": "dashboard",
        "keywords": "autosave resume close quit previous session where left off",
        "body": "When the app closes normally it saves the active profile's statement, allocations, corrections, export ticks, filters, recurring view and current page. Reopening the same profile restores that session."
    },
    {
        "id": "classic", "title": "Modern vs Classic UI", "page": "dashboard",
        "keywords": "classic old ui previous layout modern switch backwards compatible",
        "body": "Modern and Classic UI are two views over the same company data and accounting logic. Switch at any time without migrating rules, settings, history or the current session."
    },
    {
        "id": "backup", "title": "Back up and move saved rules", "page": "rules",
        "keywords": "backup rules export import move pc migrate settings",
        "body": "Use Saved Rules to export/import a rules backup. Settings also have transfer options. For a full migration, close the app and back up the appropriate AppData workspace after confirming which Personal or Clean build you are using."
    },
)


def app_data_dir() -> Path:
    base = os.environ.get("APPDATA") if os.name == "nt" else None
    root = Path(base) if base else Path.home()
    p = root / APP_DATA_NAMESPACE if base else root / APP_DATA_FALLBACK
    p.mkdir(parents=True, exist_ok=True)
    return p

DB_PATH = app_data_dir() / "pastel_payment_assistant.db"
SETTINGS_TRANSFER_KEYS = ("contra_account", "vat_tax_type", "vat_rate", "fiscal_start_month", "project_code")


class ProfileManager:
    """Manage company profiles with a completely separate SQLite database each.

    The Default profile intentionally keeps using the historic DB_PATH so an
    upgrade preserves all existing rules, settings and transaction history.
    New profiles use their own database inside the app-data profiles folder.
    """
    def __init__(self, root: Optional[Path] = None, legacy_db_path: Optional[Path] = None):
        self.root = Path(root) if root is not None else app_data_dir()
        self.root.mkdir(parents=True, exist_ok=True)
        self.legacy_db_path = Path(legacy_db_path) if legacy_db_path is not None else DB_PATH
        self.profile_dir = self.root / "profiles"
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.index_path = self.root / "profiles.json"
        self.data = self._load()

    def _load(self) -> Dict[str, object]:
        data: Dict[str, object] = {}
        if self.index_path.exists():
            try:
                raw = json.loads(self.index_path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    data = raw
            except Exception:
                data = {}
        profiles = data.get("profiles") if isinstance(data.get("profiles"), dict) else {}
        profiles = {str(k): str(v) for k, v in profiles.items() if str(k).strip() and str(v).strip()}
        if "default" not in profiles:
            profiles["default"] = "Default"
        active = str(data.get("active") or "default")
        if active not in profiles:
            active = "default"
        clean = {"active": active, "profiles": profiles}
        self.data = clean
        self._save()
        return clean

    def _save(self) -> None:
        self.index_path.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")

    @property
    def active_id(self) -> str:
        return str(self.data.get("active") or "default")

    def profiles(self) -> Dict[str, str]:
        return dict(self.data.get("profiles") or {})

    def names(self) -> List[str]:
        return list(self.profiles().values())

    def profile_name(self, profile_id: str) -> str:
        return self.profiles().get(profile_id, profile_id)

    def id_for_name(self, name: str) -> Optional[str]:
        wanted = (name or "").strip()
        for pid, pname in self.profiles().items():
            if pname == wanted:
                return pid
        return None

    def db_path(self, profile_id: str) -> Path:
        if profile_id == "default":
            return self.legacy_db_path
        return self.profile_dir / f"{profile_id}.db"

    def create_profile(self, name: str) -> str:
        name = (name or "").strip()
        if not name:
            raise ValueError("Profile name is required.")
        if any(existing.casefold() == name.casefold() for existing in self.names()):
            raise ValueError("A profile with that name already exists.")
        seed = f"{name}|{datetime.now().isoformat(timespec='microseconds')}"
        pid = "profile_" + hashlib.sha1(seed.encode("utf-8")).hexdigest()[:12]
        profiles = self.profiles()
        profiles[pid] = name
        self.data["profiles"] = profiles
        self._save()
        return pid

    def rename_profile(self, profile_id: str, new_name: str) -> None:
        new_name = (new_name or "").strip()
        if not new_name:
            raise ValueError("Profile name is required.")
        profiles = self.profiles()
        if profile_id not in profiles:
            raise ValueError("Profile was not found.")
        if any(pid != profile_id and pname.casefold() == new_name.casefold() for pid, pname in profiles.items()):
            raise ValueError("A profile with that name already exists.")
        profiles[profile_id] = new_name
        self.data["profiles"] = profiles
        self._save()

    def set_active(self, profile_id: str) -> None:
        if profile_id not in self.profiles():
            raise ValueError("Profile was not found.")
        self.data["active"] = profile_id
        self._save()

    def delete_profile(self, profile_id: str) -> None:
        if profile_id == "default":
            raise ValueError("The Default profile cannot be deleted because it contains the original app database.")
        profiles = self.profiles()
        if profile_id not in profiles:
            raise ValueError("Profile was not found.")
        db = self.db_path(profile_id)
        profiles.pop(profile_id, None)
        self.data["profiles"] = profiles
        if self.active_id == profile_id:
            self.data["active"] = "default"
        self._save()
        for candidate in (db, Path(str(db) + "-wal"), Path(str(db) + "-shm")):
            try:
                if candidate.exists():
                    candidate.unlink()
            except OSError:
                pass


def read_settings_transfer(path: str) -> Dict[str, str]:
    p = Path(path)
    if p.suffix.lower() == ".db":
        conn = sqlite3.connect(p)
        try:
            rows = conn.execute("SELECT key, value FROM settings").fetchall()
        finally:
            conn.close()
        raw = {str(k): str(v) for k, v in rows}
    else:
        with open(p, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("Settings backup must contain a JSON object.")
        raw = data.get("settings", data)
        if not isinstance(raw, dict):
            raise ValueError("Settings backup does not contain a settings object.")
    out = {k: str(raw[k]) for k in SETTINGS_TRANSFER_KEYS if k in raw}
    if not out:
        raise ValueError("No compatible Pastel Payment Assistant settings were found in this file.")
    return out


def D(value) -> Decimal:
    try:
        return Decimal(str(value).replace(",", "").strip())
    except (InvalidOperation, AttributeError):
        return Decimal("0")


def money(value: Decimal) -> str:
    return f"{value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP):.2f}"


def amount_condition_matches(amount: Decimal, operator: str, threshold: str) -> bool:
    op = (operator or "").strip()
    if op not in {"<", "<=", ">", ">=", "="}:
        return False
    try:
        limit = Decimal(str(threshold).replace(",", "").strip())
    except (InvalidOperation, AttributeError, ValueError):
        return False
    value = abs(D(amount))
    if op == "<":
        return value < limit
    if op == "<=":
        return value <= limit
    if op == ">":
        return value > limit
    if op == ">=":
        return value >= limit
    return value == limit


def amount_rule_action(rule: "Rule") -> str:
    action = (getattr(rule, "amount_action", "AUTO") or "AUTO").strip().upper()
    return "REVIEW" if action == "REVIEW" else "AUTO"


def amount_rule_condition_active(rule: "Rule", amount: Decimal) -> bool:
    return bool(
        (rule.amount_operator or "").strip()
        and (rule.amount_threshold or "").strip()
        and amount_condition_matches(amount, rule.amount_operator, rule.amount_threshold)
    )


def effective_rule_account(rule: "Rule", amount: Decimal) -> Tuple[str, bool]:
    amount_branch = amount_rule_condition_active(rule, amount)
    if amount_branch:
        if amount_rule_action(rule) == "REVIEW":
            # The normal account is returned only as a rule signature/default;
            # apply_rules deliberately leaves the transaction unallocated.
            return rule.account.strip(), True
        if rule.amount_account.strip():
            return rule.amount_account.strip(), True
    return rule.account.strip(), False


def effective_rule_description(rule: "Rule", amount: Decimal) -> str:
    """Return the branch-specific Pastel description for an allocation rule."""
    _account, amount_branch = effective_rule_account(rule, amount)
    if amount_branch and amount_rule_action(rule) == "AUTO" and rule.amount_description.strip():
        return rule.amount_description.strip()
    return (rule.description or "").strip()


def normalize_text(value: str) -> str:
    value = (value or "").upper().replace("_", " ")
    value = re.sub(r"[^A-Z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def looks_like_date_code(token: str) -> bool:
    if not token.isdigit():
        return False
    candidates = []
    if len(token) == 6:
        candidates = ["%y%m%d"]
    elif len(token) == 8:
        candidates = ["%Y%m%d", "%d%m%Y"]
    for fmt in candidates:
        try:
            datetime.strptime(token, fmt)
            return True
        except ValueError:
            pass
    return False


def looks_like_time_code(token: str) -> bool:
    # Standard Bank often appends times such as 13H37 / 09H30. These are not
    # contract identifiers and must never become a recurring-payment suffix.
    return bool(re.fullmatch(r"\d{1,2}H\d{2}", (token or "").upper()))


def smart_key(details: str, txn_type: str = "") -> str:
    """Return a friendly recurring-payment identity, e.g. HOLLARD 0923.

    For known statement formats we prefer the *stable* contract/account identifier,
    not simply the first number in the description. This matters for references
    such as VODACOM where an earlier number changes monthly but B0003783 remains
    constant. The amount is never part of this identity.
    """
    raw = (details or "").upper()

    # Known recurring-payment reference structures observed in the supplied
    # Standard Bank statements. Keep these deliberately specific: a false
    # automatic allocation is worse than leaving a payment unassigned.
    special_patterns = [
        (r"\bHOLLARD\b.*?\bHOL(\d{4,})\b", "HOLLARD"),
        (r"\bBRIGHTROCK[_ ]*(\d{4,})\b", "BRIGHTROCK"),
        (r"\bDISC\s+PREM\b\s*(\d{4,})", "DISC PREM"),
        (r"\bMAS\b\s+PP(\d{4,})", "MAS"),
        # VODACOM: the leading 10-digit number changed between June and July;
        # B0003783 stayed fixed and is therefore the reliable identity.
        (r"\bVODACOM\b.*?\bB(\d{4,})\b", "VODACOM"),
        (r"\bCIB\b\s+(?:CIBC|CIBV)(\d{4,})", "CIB"),
        (r"ALLAN\s+GRAYAGLP(\d{4,})", "ALLAN GRAY"),
        (r"WESTERNINS(?:GAP|COMPLIGAP)(\d{4,})", "WESTERNINS"),
        (r"NORTHCOASTARB(\d{2,})", "NORTHCOAST"),
        (r"\b(\d{4})\s+AR\s+BRINK\b", "AR BRINK"),
        # Card autopay references are best distinguished by the card suffix
        # after the asterisk.
        (r"\bSB\s+AUTOPAY\b.*?\*(\d{4})\b", "SB AUTOPAY"),
    ]
    for pattern, merchant in special_patterns:
        m = re.search(pattern, raw)
        if m:
            digits = m.group(1)
            suffix = digits[-4:] if len(digits) >= 4 else digits
            return f"{merchant} {suffix}"

    # A VODACOM entry without the stable B-number may be a manual transfer.
    # Do not accidentally turn its bank timestamp (e.g. 13H37) into an ID.
    if re.search(r"\bVODACOM\b", raw):
        return "VODACOM"

    text = normalize_text(details)
    toks = text.split()
    if not toks:
        return normalize_text(txn_type)[:40]

    # Generic fallback: find a useful leading name and the first plausible ID.
    name_parts = []
    ident_suffix = None
    for tok in toks:
        has_alpha = bool(re.search(r"[A-Z]", tok))
        if looks_like_time_code(tok):
            continue
        digits = "".join(re.findall(r"\d", tok))
        if digits and not looks_like_date_code(digits):
            if len(digits) >= 4:
                ident_suffix = digits[-4:]
                break
        if has_alpha and not digits and len(name_parts) < 3:
            if tok not in {"PTY", "LTD", "CC"}:
                name_parts.append(tok)
        elif has_alpha and digits:
            if len(digits) >= 4 and not looks_like_date_code(digits):
                ident_suffix = digits[-4:]
                break

    if not name_parts:
        for tok in toks:
            letters = re.sub(r"[^A-Z]", "", tok)
            if letters:
                name_parts = [letters]
                break

    if ident_suffix and name_parts:
        return f"{name_parts[0]} {ident_suffix}"
    if name_parts:
        return " ".join(name_parts[:3])
    return text[:40]


def _contains_token_sequence(container: List[str], sequence: List[str]) -> bool:
    if not sequence:
        return True
    n = len(sequence)
    return any(container[i:i+n] == sequence for i in range(0, len(container) - n + 1))


def recurring_identity_key(details: str, txn_type: str = "") -> str:
    """Return the stable identity used only for recurrence grouping/history.

    This is intentionally separate from smart_key/rule_matches.  It may collapse
    verified bank-description variants for the same payee without making any
    automatic-allocation rule broader.
    """
    combined = normalize_text(f"{details} {txn_type}")

    # Verified from the supplied Standard Bank statement: Mary Hartslief appears
    # as plain name, PCASH/PETTY CASH variants and Immediate Payment rows with a
    # changing bank-generated leading reference.  All are the same recurring
    # payee for display/history purposes.
    if re.search(r"\bMARY\s+HARTSLIEF\b", combined):
        return "MARY HARTSLIEF"

    return smart_key(details, txn_type)


def smart_match(pattern: str, details: str, txn_type: str = "") -> bool:
    """Conservative SMART matching based only on the bank description identity.

    Names must match as whole tokens in the same order. If the saved rule contains
    a reference number, the transaction must contain that same numeric suffix.
    Transaction-type text is deliberately excluded so generic words cannot cause
    false matches (for example C E BRINK must never match CHRIS BRINK).
    """
    p = normalize_text(pattern)
    d = normalize_text(details)
    if not p or not d:
        return False

    # Exact canonical identities remain the strongest and safest match.
    if p == normalize_text(smart_key(details, txn_type)):
        return True

    ptoks = p.split()
    dtoks = d.split()
    name_tokens: List[str] = []
    reference_suffixes: List[str] = []

    for tok in ptoks:
        digits = "".join(re.findall(r"\d", tok))
        letters = re.sub(r"[^A-Z]", "", tok)
        if tok.isdigit():
            reference_suffixes.append(tok)
        elif letters and digits and len(digits) >= 4:
            # Treat long alphanumeric tokens as references (e.g. B0003783).
            reference_suffixes.append(digits)
        else:
            name_tokens.append(tok)

    # The saved name must occur as an exact whole-token sequence.
    if name_tokens and not _contains_token_sequence(dtoks, name_tokens):
        return False

    # Every saved numeric reference must be present as a non-date suffix.
    for suffix in reference_suffixes:
        matched = False
        for tok in dtoks:
            digits = "".join(re.findall(r"\d", tok))
            if not digits or looks_like_date_code(digits):
                continue
            if digits.endswith(suffix):
                matched = True
                break
        if not matched:
            return False

    return bool(name_tokens or reference_suffixes)


def apply_saved_recurring_identity_rule(
    txns: List["Transaction"], indices: List[int], identity_key: str, rule: "Rule", default_tax_type: int = 0
) -> Tuple[int, int]:
    """Apply one saved identity rule to the exact recurring rows selected in the UI.

    The rows are still identity-checked with smart_key before allocation. This is
    intentionally narrower than global matching: the user explicitly saved the
    rule from this recurring identity, so matching child rows should immediately
    inherit its GL/VAT/description and become automatic allocations.
    Returns (allocated_count, review_count).
    """
    nk = normalize_text(identity_key)
    allocated = 0
    review = 0
    for idx in indices:
        if idx < 0 or idx >= len(txns):
            continue
        t = txns[idx]
        if normalize_text(recurring_identity_key(t.details, t.txn_type)) != nk:
            continue

        t.manual_override = False
        t.ambiguous = False
        t.rule_id = rule.id
        t.rule_name = rule.name
        t.match_key = rule.pattern
        t.description = (rule.description or "").strip()
        t.vat = bool(rule.vat)
        t.tax_type = int(rule.tax_type or default_tax_type or 0) if t.vat else 0
        t.pastel_ref = (rule.pastel_ref or derive_pastel_reference(t.details, rule.pattern, t.row_no))[:8]

        amount_branch = amount_rule_condition_active(rule, t.payment_amount)
        if amount_branch and amount_rule_action(rule) == "REVIEW":
            t.account = ""
            t.auto_allocated = False
            t.amount_condition_applied = True
            t.status = f"Amount review required • amount {rule.amount_operator} R {money(D(rule.amount_threshold))}"
            review += 1
            continue

        account, amount_branch = effective_rule_account(rule, t.payment_amount)
        t.account = account
        t.auto_allocated = bool(account)
        t.amount_condition_applied = amount_branch
        if account:
            amount_note = ""
            if amount_branch:
                amount_note = f" • amount {rule.amount_operator} R {money(D(rule.amount_threshold))}"
            t.status = f"Auto-assigned{amount_note} • saved recurring identity rule"
            allocated += 1
        else:
            t.status = "Unassigned • saved recurring identity rule has no GL account"
    return allocated, review


def repeat_description_choices(txns: List["Transaction"]) -> List[str]:
    """Return recurring Smart name + stable-reference identities.

    The amount is intentionally ignored; each statement row keeps its own
    current amount for export.
    """
    keys = {recurring_identity_key(t.details, t.txn_type) for t in txns if t.include and t.recurring_count >= 2}
    return sorted((k for k in keys if k), key=lambda x: normalize_text(x))


def recurring_parent_name(key: str) -> str:
    """Group identities such as HOLLARD 6957/0923/2091 under HOLLARD.

    Only a trailing numeric identifier is removed. The full smart key remains
    the rule identity, so each child can map to a different GL/VAT rule.
    """
    key = normalize_text(key)
    m = re.match(r"^(.*?)(?:\s+)(\d{2,8})$", key)
    if m and m.group(1).strip():
        return m.group(1).strip()
    return key


def recurring_child_label(key: str) -> str:
    key = normalize_text(key)
    parent = recurring_parent_name(key)
    if parent != key and key.startswith(parent + " "):
        return key[len(parent) + 1:]
    return key


def rule_matches(mode: str, pattern: str, details: str, txn_type: str) -> bool:
    """Match saved rules conservatively, including bank charges with blank details.

    Normal transactions still use the strict whole-token/reference safety gate.
    Some Standard Bank charge rows (for example STOP ORDER HANDLING FEE) have a
    blank description/reference field and carry their only stable identity in the
    transaction-type field. For those blank-detail rows we allow exactly one safe
    fallback: the saved rule pattern must equal the canonical smart_key identity.
    Loose Contains/Starts behavior is never used for this fallback.
    """
    p = normalize_text(pattern)
    d = normalize_text(details)
    if not p:
        return False

    # blank bank-description/reference fallback. smart_key('', txn_type) returns
    # the normalized transaction type, so only an exact canonical identity can
    # match. This fixes bank-charge rows without weakening normal matching.
    if not d:
        canonical = normalize_text(smart_key(details, txn_type))
        return bool(canonical and p == canonical)

    # GLOBAL SAFETY GATE: all normal automatic allocations must first satisfy
    # the conservative whole-token/reference matcher.
    if not smart_match(pattern, details, txn_type):
        return False

    mode = (mode or "SMART").upper()
    if mode == "EXACT":
        return p == d
    if mode == "STARTS":
        return d.startswith(p)
    if mode == "CONTAINS":
        return p in d
    return True


def mode_rank(mode: str) -> int:
    return {"EXACT": 4, "SMART": 3, "STARTS": 2, "CONTAINS": 1}.get((mode or "").upper(), 0)


def derive_pastel_reference(details: str, key: str, row_no: int) -> str:
    # Prefer the user's friendly numeric suffix, e.g. HOLLARD 0923 -> 0923.
    key_tokens = normalize_text(key).split()
    nums = [t for t in key_tokens if t.isdigit() and not looks_like_date_code(t)]
    if nums:
        return nums[-1][-8:]

    # Then use a non-date identifier embedded in the bank details.
    for tok in normalize_text(details).split():
        digits = "".join(re.findall(r"\d", tok))
        if digits and not looks_like_date_code(digits):
            return digits[-8:]

    # Final deterministic fallback: 8 chars, useful for review even without a bank reference.
    return f"P{row_no:07d}"[-8:]


def assign_monthly_sequential_references(txns: List["Transaction"]) -> None:
    """Assign a unique Pastel reference to every transaction in calendar-month order.

    Payments use P<month>-0001 and receipts use R<month>-0001. Multiple
    transactions on the same date are sequenced by their original bank-statement
    row number, so no two rows in the same direction/month receive the same
    reference in a loaded statement. Saved/manual rule references are deliberately
    overwritten by this transaction-level sequence.
    """
    counters: Dict[Tuple[str, int], int] = {}
    ordered = sorted(
        txns,
        key=lambda t: (
            (t.direction or "PAYMENT").upper(),
            t.txn_date.year,
            t.txn_date.month,
            t.txn_date,
            t.row_no,
        ),
    )
    for t in ordered:
        direction = (t.direction or "PAYMENT").upper()
        prefix = "R" if direction == "RECEIPT" else "P"
        key = (direction, t.txn_date.month)
        seq = counters.get(key, 0) + 1
        counters[key] = seq
        t.pastel_ref = f"{prefix}{t.txn_date.month}-{seq:04d}"


def period_for_date(d: date, fiscal_start_month: int) -> int:
    return ((d.month - fiscal_start_month) % 12) + 1


class HoverHelp:
    """Show a short explanation when the pointer rests over a ? icon."""
    def __init__(self, widget, text: str, delay_ms: int = 300):
        self.widget = widget
        self.text = text
        self.delay_ms = delay_ms
        self._after_id = None
        self._tip = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _schedule(self, _event=None):
        self._cancel()
        self._after_id = self.widget.after(self.delay_ms, self._show)

    def _cancel(self):
        if self._after_id is not None:
            try:
                self.widget.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None

    def _show(self):
        self._after_id = None
        if self._tip is not None or not self.text:
            return
        x = self.widget.winfo_rootx() + self.widget.winfo_width() + 8
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 2
        tip = tk.Toplevel(self.widget)
        tip.wm_overrideredirect(True)
        tip.wm_geometry(f"+{x}+{y}")
        ttk.Label(
            tip, text=self.text, justify="left", wraplength=360,
            padding=(9, 7), relief="solid", borderwidth=1
        ).pack()
        self._tip = tip

    def _hide(self, _event=None):
        self._cancel()
        if self._tip is not None:
            try:
                self._tip.destroy()
            except Exception:
                pass
            self._tip = None


def help_icon(parent, text: str):
    icon = ttk.Label(parent, text="?", width=2, anchor="center", relief="groove", cursor="question_arrow")
    icon._hover_help = HoverHelp(icon, text)
    return icon


def help_action(parent, text: str, command, help_text: str, side: str = "left", padx=3):
    holder = ttk.Frame(parent)
    holder.pack(side=side, padx=padx, pady=2)
    button = ttk.Button(holder, text=text, command=command)
    button.pack(side="left")
    help_icon(holder, help_text).pack(side="left", padx=(2, 0))
    return button


@dataclass
class Rule:
    id: Optional[int]
    name: str
    mode: str
    pattern: str
    account: str
    vat: bool
    tax_type: int
    pastel_ref: str = ""
    priority: int = 100
    enabled: bool = True
    direction: str = "PAYMENT"
    description: str = ""
    amount_operator: str = ""
    amount_threshold: str = ""
    amount_account: str = ""
    amount_description: str = ""
    amount_action: str = "AUTO"


@dataclass
class Transaction:
    row_no: int
    txn_date: date
    amount: Decimal
    txn_type: str
    details: str
    bank_code: str = ""
    source: str = ""
    include: bool = True
    rule_id: Optional[int] = None
    rule_name: str = ""
    account: str = ""
    vat: bool = False
    tax_type: int = 0
    match_key: str = ""
    pastel_ref: str = ""
    status: str = "Unassigned"
    manual_override: bool = False
    ambiguous: bool = False
    recurring_count: int = 1
    previously_seen: bool = False
    direction: str = "PAYMENT"
    contra: str = ""  # legacy v1.9 field; ignored in v1.10 cash-book exports
    description: str = ""
    auto_allocated: bool = False
    amount_condition_applied: bool = False

    @property
    def payment_amount(self) -> Decimal:
        return abs(self.amount)


def rule_window_amount_candidates(txns: List["Transaction"], direction: str, mode: str, pattern: str, operator: str, threshold: str) -> List[Tuple[int, "Transaction"]]:
    """Rows from the current statement caught by this rule's amount condition.

    These are the exceptions the user needs to see inside the Rule window when
    Review each qualifying transaction is selected.
    """
    out: List[Tuple[int, "Transaction"]] = []
    direction = (direction or "PAYMENT").upper()
    if not (pattern or "").strip() or not (operator or "").strip() or not (threshold or "").strip():
        return out
    for idx, t in enumerate(txns):
        if (t.direction or "PAYMENT").upper() != direction:
            continue
        if not rule_matches(mode, pattern, t.details, t.txn_type):
            continue
        if amount_condition_matches(t.payment_amount, operator, threshold):
            out.append((idx, t))
    return out


def apply_rule_window_manual_assignment(txns: List["Transaction"], account: str, description: str = "", vat: bool = False, tax_type: int = 0) -> int:
    """Apply an allocation staged inside the Rule window to exactly these rows."""
    account = (account or "").strip()
    description = (description or "").strip()
    if not account:
        return 0
    count = 0
    for t in txns:
        t.account = account
        if description:
            t.description = description
        t.vat = bool(vat)
        t.tax_type = int(tax_type or 0) if t.vat else 0
        t.rule_id = None
        t.rule_name = "Manual amount review"
        t.status = "Amount review assigned manually"
        t.manual_override = True
        t.ambiguous = False
        t.auto_allocated = False
        t.amount_condition_applied = True
        count += 1
    return count


def apply_review_assignment(txns: List["Transaction"], account: str, description: str = "", vat: bool = False, tax_type: int = 0) -> int:
    """Apply one manual allocation to only the supplied amount-review rows.

    The caller chooses the exact rows (one or many). Other qualifying amount
    review transactions are deliberately untouched. A blank description keeps
    each selected transaction's existing description.
    """
    account = (account or "").strip()
    description = (description or "").strip()
    if not account:
        return 0
    count = 0
    for t in txns:
        if not (t.status or "").startswith("Amount review required"):
            continue
        t.account = account
        if description:
            t.description = description
        t.vat = bool(vat)
        t.tax_type = int(tax_type or 0) if t.vat else 0
        t.rule_id = None
        t.rule_name = "Manual amount review"
        t.status = "Amount review assigned manually"
        t.manual_override = True
        t.ambiguous = False
        t.auto_allocated = False
        t.amount_condition_applied = True
        count += 1
    return count


def transaction_to_session_dict(t: "Transaction") -> Dict[str, object]:
    """Serialize every user-editable transaction field needed to resume a session."""
    return {
        "row_no": int(t.row_no),
        "txn_date": t.txn_date.isoformat(),
        "amount": str(t.amount),
        "txn_type": t.txn_type,
        "details": t.details,
        "bank_code": t.bank_code,
        "source": t.source,
        "include": bool(t.include),
        "rule_id": t.rule_id,
        "rule_name": t.rule_name,
        "account": t.account,
        "vat": bool(t.vat),
        "tax_type": int(t.tax_type or 0),
        "match_key": t.match_key,
        "pastel_ref": t.pastel_ref,
        "status": t.status,
        "manual_override": bool(t.manual_override),
        "ambiguous": bool(t.ambiguous),
        "recurring_count": int(t.recurring_count or 1),
        "previously_seen": bool(t.previously_seen),
        "direction": (t.direction or "PAYMENT").upper(),
        "contra": t.contra,
        "description": t.description,
        "auto_allocated": bool(t.auto_allocated),
        "amount_condition_applied": bool(t.amount_condition_applied),
    }


def transaction_from_session_dict(data: Dict[str, object]) -> "Transaction":
    """Recreate a Transaction from an autosaved session snapshot."""
    raw_date = str(data.get("txn_date") or "")
    try:
        txn_date = date.fromisoformat(raw_date)
    except ValueError:
        txn_date = date.today()
    rid = data.get("rule_id")
    try:
        rule_id = int(rid) if rid not in (None, "") else None
    except (TypeError, ValueError):
        rule_id = None
    return Transaction(
        row_no=int(data.get("row_no") or 0),
        txn_date=txn_date,
        amount=D(data.get("amount") or "0"),
        txn_type=str(data.get("txn_type") or ""),
        details=str(data.get("details") or ""),
        bank_code=str(data.get("bank_code") or ""),
        source=str(data.get("source") or ""),
        include=bool(data.get("include", True)),
        rule_id=rule_id,
        rule_name=str(data.get("rule_name") or ""),
        account=str(data.get("account") or ""),
        vat=bool(data.get("vat", False)),
        tax_type=int(data.get("tax_type") or 0),
        match_key=str(data.get("match_key") or ""),
        pastel_ref=str(data.get("pastel_ref") or ""),
        status=str(data.get("status") or "Unassigned"),
        manual_override=bool(data.get("manual_override", False)),
        ambiguous=bool(data.get("ambiguous", False)),
        recurring_count=int(data.get("recurring_count") or 1),
        previously_seen=bool(data.get("previously_seen", False)),
        direction=str(data.get("direction") or "PAYMENT").upper(),
        contra=str(data.get("contra") or ""),
        description=str(data.get("description") or ""),
        auto_allocated=bool(data.get("auto_allocated", False)),
        amount_condition_applied=bool(data.get("amount_condition_applied", False)),
    )


class Store:
    def __init__(self, path: Path = DB_PATH):
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self._init()

    def _init(self):
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            mode TEXT NOT NULL DEFAULT 'SMART',
            pattern TEXT NOT NULL,
            account TEXT NOT NULL,
            vat INTEGER NOT NULL DEFAULT 0,
            tax_type INTEGER NOT NULL DEFAULT 0,
            pastel_ref TEXT NOT NULL DEFAULT '',
            priority INTEGER NOT NULL DEFAULT 100,
            enabled INTEGER NOT NULL DEFAULT 1,
            direction TEXT NOT NULL DEFAULT 'PAYMENT',
            description TEXT NOT NULL DEFAULT '',
            amount_operator TEXT NOT NULL DEFAULT '',
            amount_threshold TEXT NOT NULL DEFAULT '',
            amount_account TEXT NOT NULL DEFAULT '',
            amount_description TEXT NOT NULL DEFAULT '',
            amount_action TEXT NOT NULL DEFAULT 'AUTO',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS transaction_history (
            signature TEXT PRIMARY KEY,
            txn_date TEXT NOT NULL,
            match_key TEXT NOT NULL,
            details TEXT NOT NULL,
            amount TEXT NOT NULL,
            source_name TEXT NOT NULL DEFAULT '',
            direction TEXT NOT NULL DEFAULT 'PAYMENT',
            first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_history_match_key ON transaction_history(match_key);
        """)
        # Seamless upgrade from v1.6: all existing saved rules/history were payments.
        rule_cols = {r[1] for r in self.conn.execute("PRAGMA table_info(rules)").fetchall()}
        if "direction" not in rule_cols:
            self.conn.execute("ALTER TABLE rules ADD COLUMN direction TEXT NOT NULL DEFAULT 'PAYMENT'")
        for col, ddl in {
            "description": "TEXT NOT NULL DEFAULT ''",
            "amount_operator": "TEXT NOT NULL DEFAULT ''",
            "amount_threshold": "TEXT NOT NULL DEFAULT ''",
            "amount_account": "TEXT NOT NULL DEFAULT ''",
            "amount_description": "TEXT NOT NULL DEFAULT ''",
            "amount_action": "TEXT NOT NULL DEFAULT 'AUTO'",
        }.items():
            if col not in rule_cols:
                self.conn.execute(f"ALTER TABLE rules ADD COLUMN {col} {ddl}")
        hist_cols = {r[1] for r in self.conn.execute("PRAGMA table_info(transaction_history)").fetchall()}
        if "direction" not in hist_cols:
            self.conn.execute("ALTER TABLE transaction_history ADD COLUMN direction TEXT NOT NULL DEFAULT 'PAYMENT'")
        defaults = {
            "contra_account": "",
            "vat_tax_type": "",
            "vat_rate": "15",
            "fiscal_start_month": "3",
            "project_code": "",
            "last_folder": str(Path.home()),
        }
        for k, v in defaults.items():
            self.conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
        self.conn.commit()

    def get_setting(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row[0] if row else default

    def set_setting(self, key: str, value: str):
        self.conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
        self.conn.commit()

    @staticmethod
    def _row_to_rule(r) -> Rule:
        keys = set(r.keys())
        direction = (r["direction"] if "direction" in keys else "PAYMENT") or "PAYMENT"
        return Rule(
            r["id"], r["name"], r["mode"], r["pattern"], r["account"], bool(r["vat"]), int(r["tax_type"]),
            r["pastel_ref"], int(r["priority"]), bool(r["enabled"]), direction.upper(),
            (r["description"] if "description" in keys else "") or "",
            (r["amount_operator"] if "amount_operator" in keys else "") or "",
            (r["amount_threshold"] if "amount_threshold" in keys else "") or "",
            (r["amount_account"] if "amount_account" in keys else "") or "",
            (r["amount_description"] if "amount_description" in keys else "") or "",
            ((r["amount_action"] if "amount_action" in keys else "AUTO") or "AUTO").upper(),
        )

    def rules(self, direction: Optional[str] = None) -> List[Rule]:
        sql = "SELECT * FROM rules WHERE enabled=1"
        args = []
        if direction:
            sql += " AND UPPER(direction)=?"
            args.append(direction.upper())
        sql += " ORDER BY priority DESC, LENGTH(pattern) DESC, id ASC"
        rows = self.conn.execute(sql, args).fetchall()
        return [self._row_to_rule(r) for r in rows]

    def all_rules(self, direction: Optional[str] = None) -> List[Rule]:
        sql = "SELECT * FROM rules"
        args = []
        if direction:
            sql += " WHERE UPPER(direction)=?"
            args.append(direction.upper())
        sql += " ORDER BY enabled DESC, direction, priority DESC, id ASC"
        rows = self.conn.execute(sql, args).fetchall()
        return [self._row_to_rule(r) for r in rows]

    def save_rule(self, rule: Rule) -> int:
        direction = (rule.direction or "PAYMENT").upper()
        values = (
            rule.name, rule.mode, rule.pattern, rule.account, int(rule.vat), int(rule.tax_type), rule.pastel_ref,
            int(rule.priority), int(rule.enabled), direction, rule.description or "", rule.amount_operator or "",
            rule.amount_threshold or "", rule.amount_account or "", rule.amount_description or "", amount_rule_action(rule),
        )
        if rule.id:
            self.conn.execute(
                """UPDATE rules SET name=?,mode=?,pattern=?,account=?,vat=?,tax_type=?,pastel_ref=?,priority=?,enabled=?,direction=?,description=?,amount_operator=?,amount_threshold=?,amount_account=?,amount_description=?,amount_action=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                values + (rule.id,),
            )
            rid = rule.id
        else:
            cur = self.conn.execute(
                """INSERT INTO rules(name,mode,pattern,account,vat,tax_type,pastel_ref,priority,enabled,direction,description,amount_operator,amount_threshold,amount_account,amount_description,amount_action) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                values,
            )
            rid = int(cur.lastrowid)
        self.conn.commit()
        return rid

    def delete_rule(self, rid: int):
        self.conn.execute("DELETE FROM rules WHERE id=?", (rid,))
        self.conn.commit()

    def get_rule(self, rid: int) -> Optional[Rule]:
        r = self.conn.execute("SELECT * FROM rules WHERE id=?", (rid,)).fetchone()
        return self._row_to_rule(r) if r else None

    def known_accounts(self) -> List[str]:
        rows = self.conn.execute(
            "SELECT account FROM (SELECT TRIM(account) AS account FROM rules WHERE TRIM(account) <> '' UNION SELECT TRIM(amount_account) AS account FROM rules WHERE TRIM(amount_account) <> '') ORDER BY account"
        ).fetchall()
        return [r["account"] for r in rows if r["account"]]

    @staticmethod
    def _txn_signature(t: Transaction) -> str:
        # Preserve the legacy payment signature to avoid double-counting old history.
        base = f"{t.txn_date.isoformat()}|{normalize_text(t.details)}|{money(t.payment_amount)}"
        raw = base if (t.direction or "PAYMENT").upper() == "PAYMENT" else f"RECEIPT|{base}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def remember_transactions(self, txns: List[Transaction]):
        """Remember unique transactions by direction; amount is audit-only, never a match key."""
        if not txns:
            return
        key_pairs = []
        for t in txns:
            key = recurring_identity_key(t.details, t.txn_type)
            direction = (t.direction or "PAYMENT").upper()
            key_pairs.append((direction, key))
            sig = self._txn_signature(t)
            self.conn.execute(
                """INSERT INTO transaction_history(signature,txn_date,match_key,details,amount,source_name,direction) VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(signature) DO UPDATE SET
                    txn_date=excluded.txn_date, match_key=excluded.match_key, details=excluded.details,
                    amount=excluded.amount, source_name=excluded.source_name, direction=excluded.direction""",
                (sig, t.txn_date.isoformat(), key, t.details, money(t.payment_amount), Path(t.source).name if t.source else "", direction)
            )
        self.conn.commit()

        current_counts: Dict[Tuple[str, str], int] = {}
        for pair in key_pairs:
            current_counts[pair] = current_counts.get(pair, 0) + 1

        counts: Dict[Tuple[str, str], int] = {}
        for direction, key in sorted(set(key_pairs)):
            row = self.conn.execute(
                "SELECT COUNT(*) AS c FROM transaction_history WHERE UPPER(direction)=? AND match_key=?",
                (direction, key)
            ).fetchone()
            counts[(direction, key)] = int(row["c"] if row else 0)

        for t in txns:
            direction = (t.direction or "PAYMENT").upper()
            key = recurring_identity_key(t.details, t.txn_type)
            pair = (direction, key)
            t.recurring_count = max(counts.get(pair, 1), current_counts.get(pair, 1))
            t.previously_seen = counts.get(pair, 0) > current_counts.get(pair, 0)

    def recurring_summary(self, direction: Optional[str] = None) -> List[sqlite3.Row]:
        sql = "SELECT direction, match_key, COUNT(*) AS seen_count, MIN(txn_date) AS first_date, MAX(txn_date) AS last_date, MIN(CAST(amount AS REAL)) AS min_amount, MAX(CAST(amount AS REAL)) AS max_amount FROM transaction_history"
        args = []
        if direction:
            sql += " WHERE UPPER(direction)=?"
            args.append(direction.upper())
        sql += " GROUP BY direction, match_key HAVING COUNT(*) >= 2 ORDER BY last_date DESC, match_key"
        return self.conn.execute(sql, args).fetchall()


class BankCSVParser:
    DATE_NAMES = {"date", "transaction date", "trans date", "value date", "posting date"}
    AMOUNT_NAMES = {"amount", "transaction amount", "value"}
    DESC_NAMES = {"description", "details", "transaction description", "narrative", "payee", "beneficiary", "reference"}

    @staticmethod
    def load(path: str) -> Tuple[List[Transaction], List[Transaction], str]:
        with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as f:
            raw = list(csv.reader(f))
        if not raw:
            raise ValueError("The CSV file is empty.")

        payments, receipts = BankCSVParser._parse_hist(raw, path)
        if payments or receipts:
            return payments, receipts, "Standard Bank / HIST statement format"

        payments, receipts = BankCSVParser._parse_headered(raw, path)
        if payments or receipts:
            return payments, receipts, "Headered bank CSV"
        raise ValueError("I could not identify the transaction columns in this CSV. This version recognises the supplied HIST statement format and common headered CSV files.")

    @staticmethod
    def _parse_hist(raw, path):
        payments, receipts = [], []
        for i, row in enumerate(raw, 1):
            if len(row) < 7 or row[0].strip().upper() != "HIST":
                continue
            try:
                d = datetime.strptime(row[1].strip(), "%Y%m%d").date()
                amt = D(row[3])
            except Exception:
                continue
            if amt == 0:
                continue
            direction = "PAYMENT" if amt < 0 else "RECEIPT"
            txn = Transaction(i, d, amt, row[4].strip(), row[5].strip(), row[6].strip(), path, direction=direction)
            (payments if direction == "PAYMENT" else receipts).append(txn)
        return payments, receipts

    @staticmethod
    def _parse_date(s: str) -> Optional[date]:
        s = (s or "").strip()
        for fmt in ("%Y%m%d", "%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y"):
            try:
                return datetime.strptime(s, fmt).date()
            except ValueError:
                pass
        return None

    @staticmethod
    def _parse_headered(raw, path):
        headers = [normalize_text(x).lower() for x in raw[0]]
        def idx_for(names):
            for idx, h in enumerate(headers):
                if h in names:
                    return idx
            return None
        di = idx_for(BankCSVParser.DATE_NAMES)
        ai = idx_for(BankCSVParser.AMOUNT_NAMES)
        descis = [i for i, h in enumerate(headers) if h in BankCSVParser.DESC_NAMES]
        if di is None or ai is None or not descis:
            return [], []
        payments, receipts = [], []
        for i, row in enumerate(raw[1:], 2):
            if max([di, ai] + descis) >= len(row):
                continue
            d = BankCSVParser._parse_date(row[di])
            if not d:
                continue
            amt = D(row[ai])
            if amt == 0:
                continue
            details = " ".join(row[j].strip() for j in descis if row[j].strip())
            direction = "PAYMENT" if amt < 0 else "RECEIPT"
            txn = Transaction(i, d, amt, direction, details, "", path, direction=direction)
            (payments if direction == "PAYMENT" else receipts).append(txn)
        return payments, receipts


def apply_rules(txns: List[Transaction], rules: List[Rule], default_tax_type: int = 0):
    for t in txns:
        if t.manual_override:
            continue
        candidates = []
        for r in rules:
            if (r.direction or "PAYMENT").upper() != (t.direction or "PAYMENT").upper():
                continue
            if r.enabled and rule_matches(r.mode, r.pattern, t.details, t.txn_type):
                score = (int(r.priority), mode_rank(r.mode), len(normalize_text(r.pattern)))
                candidates.append((score, r))
        t.rule_id = None
        t.rule_name = ""
        t.account = ""
        t.description = ""
        t.vat = False
        t.tax_type = 0
        t.match_key = smart_key(t.details, t.txn_type)
        t.pastel_ref = derive_pastel_reference(t.details, t.match_key, t.row_no)
        t.status = f"Recurring x{t.recurring_count} • unassigned" if t.recurring_count >= 2 else "Unassigned"
        t.ambiguous = False
        t.auto_allocated = False
        t.amount_condition_applied = False
        if not candidates:
            continue
        candidates.sort(key=lambda x: x[0], reverse=True)
        top_score = candidates[0][0]
        top = [r for score, r in candidates if score == top_score]
        distinct = {
            (amount_rule_action(r), effective_rule_account(r, t.payment_amount)[0], bool(r.vat), int(r.tax_type), effective_rule_description(r, t.payment_amount))
            for r in top
        }
        if len(top) > 1 and len(distinct) > 1:
            t.status = "Ambiguous rules"
            t.ambiguous = True
            continue
        r = top[0]
        account, amount_branch = effective_rule_account(r, t.payment_amount)
        if amount_branch and amount_rule_action(r) == "REVIEW":
            # Qualifying amount is deliberately NOT auto-allocated. Keep enough
            # rule context to make one-at-a-time review quick and auditable.
            t.rule_id = r.id
            t.rule_name = f"Review • {r.name}"
            t.account = ""
            t.description = (r.description or "").strip()
            t.vat = bool(r.vat)
            t.tax_type = int(r.tax_type or default_tax_type or 0) if t.vat else 0
            t.match_key = r.pattern
            t.pastel_ref = (r.pastel_ref or derive_pastel_reference(t.details, r.pattern, t.row_no))[:8]
            t.auto_allocated = False
            t.amount_condition_applied = True
            t.status = f"Amount review required • amount {r.amount_operator} R {money(D(r.amount_threshold))}"
            continue
        t.rule_id = r.id
        t.rule_name = r.name
        t.account = account
        t.description = effective_rule_description(r, t.payment_amount)
        t.vat = bool(r.vat)
        t.tax_type = int(r.tax_type or default_tax_type or 0) if t.vat else 0
        t.match_key = r.pattern
        t.pastel_ref = (r.pastel_ref or derive_pastel_reference(t.details, r.pattern, t.row_no))[:8]
        t.auto_allocated = True
        t.amount_condition_applied = amount_branch
        amount_note = ""
        if amount_branch:
            amount_note = f" • amount {r.amount_operator} R {money(D(r.amount_threshold))}"
        base = f"Auto-assigned{amount_note}"
        t.status = f"{base} • recurring x{t.recurring_count}" if t.recurring_count >= 2 else base


def calculate_tax(gross: Decimal, vat: bool, rate: Decimal) -> Decimal:
    if not vat:
        return Decimal("0.00")
    if rate <= 0:
        return Decimal("0.00")
    # Bank payment is treated as VAT-inclusive by default.
    return (gross * rate / (Decimal("100") + rate)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def effective_contra(t: Transaction, settings: Dict[str, str]) -> str:
    """Return the cash-book bank GL used in Pastel import column L.

    Sage's import layout calls this field "Contra Account", but for a cash-book
    batch it is the bank/cash-book GL and is the same for every row in that batch.
    It is not a per-payment allocation.
    """
    return settings.get("contra_account", "").strip()


def validate_export(txns: List[Transaction], settings: Dict[str, str], label: str = "transactions") -> Tuple[List[str], List[str]]:
    assign_monthly_sequential_references(txns)
    errors, warnings = [], []
    cashbook_account = settings.get("contra_account", "").strip()
    if cashbook_account and len(cashbook_account) > 7:
        errors.append(f"Cash-book bank GL account '{cashbook_account}' is longer than Sage's 7-character layout.")
    if not cashbook_account:
        warnings.append("Cash-book bank GL account is blank. Pastel's CSV import layout calls column L 'Contra Account'; some Pastel versions require the bank GL of the selected cash book there. The app will still export with column L blank.")

    vat_rate = D(settings.get("vat_rate", "15"))
    try:
        default_tax = int(settings.get("vat_tax_type", "") or 0)
    except ValueError:
        default_tax = 0
    try:
        fiscal_start = int(settings.get("fiscal_start_month", "3"))
    except ValueError:
        fiscal_start = 0
    if not 1 <= fiscal_start <= 12:
        errors.append("Fiscal year start month must be between 1 and 12.")
    if settings.get("project_code", "") and len(settings.get("project_code", "")) > 5:
        errors.append("Project code is longer than Sage's 5-character layout.")

    selected = [t for t in txns if t.include]
    exportable = [t for t in selected if t.account]
    ambiguous = [t for t in selected if t.ambiguous]
    unassigned = [t for t in selected if not t.account and not t.ambiguous]
    if not selected:
        errors.append(f"There are no {label} selected for export.")
    elif not exportable:
        errors.append(f"There are no assigned {label} selected for export.")
    if unassigned:
        errors.append(f"{len(unassigned)} selected {label} are unassigned. Assign them or untick them before export.")
    if ambiguous:
        errors.append(f"{len(ambiguous)} selected {label} have ambiguous rule matches. Resolve the rule conflict or untick them before export.")

    vat_count = 0
    trunc_count = 0
    seen_refs = set()
    for t in exportable:
        if len(t.account) > 7:
            errors.append(f"Row {t.row_no}: GL account '{t.account}' exceeds 7 characters.")
        ref = (t.pastel_ref or "").strip()
        if len(ref) > 8:
            errors.append(f"Row {t.row_no}: Pastel reference '{ref}' exceeds 8 characters.")
        if ref in seen_refs:
            errors.append(f"Row {t.row_no}: duplicate Pastel reference '{ref}' was generated. Export is blocked to prevent duplicate references entering Pastel.")
        elif ref:
            seen_refs.add(ref)
        if len(t.description or t.details) > 36:
            trunc_count += 1
        if t.vat:
            vat_count += 1
            tax_type = int(t.tax_type or default_tax or 0)
            if tax_type <= 0:
                errors.append(f"Row {t.row_no}: VAT is ON but no valid Pastel VAT tax type is set.")
            if vat_rate <= 0:
                errors.append(f"Row {t.row_no}: VAT is ON but VAT rate is not greater than zero.")
        p = period_for_date(t.txn_date, fiscal_start) if 1 <= fiscal_start <= 12 else 0
        if not 1 <= p <= 13:
            errors.append(f"Row {t.row_no}: calculated period {p} is invalid.")

    if trunc_count:
        warnings.append(f"{trunc_count} description(s) exceed 36 characters and will be safely truncated in the Pastel file.")
    if vat_count:
        warnings.append("VAT amounts are calculated as VAT-inclusive from the bank transaction total. Confirm this treatment is correct for each selected row before posting.")
    if fiscal_start:
        warnings.append(f"Periods are calculated using fiscal-year start month {fiscal_start}. Confirm this matches Setup → Periods in Pastel.")
    return errors, warnings


def pastel_rows(txns: List[Transaction], settings: Dict[str, str]):
    # Re-assert unique sequential references at the final export boundary so
    # saved-rule or manual-reference text can never create duplicate CSV refs.
    assign_monthly_sequential_references(txns)
    project = settings.get("project_code", "").strip()
    fiscal_start = int(settings.get("fiscal_start_month", "3"))
    vat_rate = D(settings.get("vat_rate", "15"))
    default_tax = int(settings.get("vat_tax_type", "") or 0)
    for t in txns:
        if not (t.include and t.account):
            continue
        gross = t.payment_amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        tax_type = int(t.tax_type or default_tax or 0) if t.vat else 0
        tax_amount = calculate_tax(gross, t.vat, vat_rate)

        # Sage Pastel cash-book import Amount/Home Amount are the GL-side
        # debit/credit values (positive = DR, negative = CR). Payments debit the
        # allocated GL and therefore stay positive. Receipts credit the allocated
        # GL and therefore must be negative in the import file; Pastel then shows
        # the corresponding bank movement as a POSITIVE Bank Amount on Receipts.
        direction = (t.direction or "PAYMENT").upper()
        signed_gross = -gross if direction == "RECEIPT" else gross
        signed_tax = (-tax_amount if tax_amount != 0 else tax_amount) if direction == "RECEIPT" else tax_amount

        ref = (t.pastel_ref or derive_pastel_reference(t.details, t.match_key, t.row_no))[:8]
        desc = re.sub(r"\s+", " ", (t.description or t.details)).strip()[:36]
        amount_s = money(signed_gross)
        tax_amount_s = money(signed_tax)
        contra = effective_contra(t, settings)
        yield [
            str(period_for_date(t.txn_date, fiscal_start)),
            t.txn_date.strftime("%d/%m/%Y"),
            "G",
            t.account.strip(),
            ref,
            desc,
            amount_s,
            str(tax_type),
            tax_amount_s,
            "A",
            project,
            contra,
            "1",
            "1",
            "1",
            "0",
            "0.00",
            amount_s,
        ]


class RuleDialog(tk.Toplevel):
    MODES = [("Smart name + number", "SMART"), ("Contains", "CONTAINS"), ("Starts with", "STARTS"), ("Exact", "EXACT")]
    def __init__(self, parent, store: Store, txn: Optional[Transaction] = None, rule: Optional[Rule] = None, locked_identity: str = "", direction: str = ""):
        super().__init__(parent)
        self.store = store
        self.txn = txn
        self.rule = rule
        self.app = parent
        self.locked_identity = normalize_text(locked_identity)
        self.result = None
        self.amount_review_selected: set = set()
        self.pending_amount_review_assignments: Dict[int, Tuple[str, str, bool, int]] = {}
        self.applied_review_transaction_ids: set = set()
        direction = (direction or (rule.direction if rule else (txn.direction if txn else "PAYMENT")) or "PAYMENT").upper()
        noun = "receipt" if direction == "RECEIPT" else "payment"
        self.direction = direction
        self.title(f"Assign {noun} rule" if txn else ("Edit rule" if rule else f"New {noun} rule"))
        self.transient(parent)
        self.grab_set()
        self.resizable(True, True)
        self.minsize(520, 360)
        _screen_w = self.winfo_screenwidth()
        _screen_h = self.winfo_screenheight()
        _initial_w = max(560, min(980, _screen_w - 80))
        _initial_h = max(420, min(760, _screen_h - 100))
        self.geometry(f"{_initial_w}x{_initial_h}")

        initial_key = rule.pattern if rule else (smart_key(txn.details, txn.txn_type) if txn else "")
        initial_name = rule.name if rule else initial_key
        initial_mode = rule.mode if rule else "SMART"
        initial_account = rule.account if rule else (txn.account if txn else "")
        initial_vat = rule.vat if rule else (txn.vat if txn else False)
        initial_tax = str(rule.tax_type if rule else (txn.tax_type if txn else (store.get_setting("vat_tax_type", "") or "")))
        initial_ref = rule.pastel_ref if rule else (derive_pastel_reference(txn.details, initial_key, txn.row_no) if txn else "")
        initial_priority = str(rule.priority if rule else 100)
        initial_description = rule.description if rule else (txn.description if txn else "")
        initial_amount_action = amount_rule_action(rule) if rule else "AUTO"
        initial_amount_enabled = bool(rule and rule.amount_operator and (rule.amount_account or initial_amount_action == "REVIEW"))
        initial_amount_operator = rule.amount_operator if rule and rule.amount_operator else "<"
        initial_amount_threshold = rule.amount_threshold if rule else ""
        initial_amount_account = rule.amount_account if rule else ""
        initial_amount_description = rule.amount_description if rule else ""
        initial_amount_action_label = "Review each qualifying transaction" if initial_amount_action == "REVIEW" else "Automatically allocate"

        self.vars = {
            "name": tk.StringVar(value=initial_name),
            "pattern": tk.StringVar(value=initial_key),
            "mode_label": tk.StringVar(value=next((a for a,b in self.MODES if b == initial_mode), self.MODES[0][0])),
            "account": tk.StringVar(value=initial_account),
            "vat": tk.BooleanVar(value=initial_vat),
            "tax": tk.StringVar(value=initial_tax),
            "ref": tk.StringVar(value=initial_ref[:8]),
            "priority": tk.StringVar(value=initial_priority),
            "description": tk.StringVar(value=initial_description),
            "amount_enabled": tk.BooleanVar(value=initial_amount_enabled),
            "amount_operator": tk.StringVar(value=initial_amount_operator),
            "amount_threshold": tk.StringVar(value=initial_amount_threshold),
            "amount_account": tk.StringVar(value=initial_amount_account),
            "amount_description": tk.StringVar(value=initial_amount_description),
            "amount_action_label": tk.StringVar(value=initial_amount_action_label),
        }

        # Scrollable Rule-dialog viewport. Resizing is the primary experience;
        # the scrollbars are the fallback for small screens / high DPI scaling.
        viewport = ttk.Frame(self)
        viewport.grid(row=0, column=0, sticky="nsew")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        viewport.columnconfigure(0, weight=1)
        viewport.rowconfigure(0, weight=1)

        self.rule_canvas = tk.Canvas(viewport, highlightthickness=0, borderwidth=0)
        self.rule_vscroll = ttk.Scrollbar(viewport, orient="vertical", command=self.rule_canvas.yview)
        self.rule_hscroll = ttk.Scrollbar(viewport, orient="horizontal", command=self.rule_canvas.xview)
        self.rule_canvas.configure(yscrollcommand=self.rule_vscroll.set, xscrollcommand=self.rule_hscroll.set)
        self.rule_canvas.grid(row=0, column=0, sticky="nsew")
        self.rule_vscroll.grid(row=0, column=1, sticky="ns")
        self.rule_hscroll.grid(row=1, column=0, sticky="ew")

        root = ttk.Frame(self.rule_canvas, padding=14)
        self.rule_canvas_window = self.rule_canvas.create_window((0, 0), window=root, anchor="nw")
        root.columnconfigure(1, weight=1)

        def _sync_rule_scrollregion(_event=None):
            bbox = self.rule_canvas.bbox("all")
            if bbox:
                self.rule_canvas.configure(scrollregion=bbox)

        def _fit_rule_content(event):
            # Fill available space when the window is large, but retain the
            # content's requested dimensions when the viewport is smaller so
            # horizontal/vertical scrolling exposes every control.
            root.update_idletasks()
            width = max(root.winfo_reqwidth(), event.width)
            height = max(root.winfo_reqheight(), event.height)
            self.rule_canvas.itemconfigure(self.rule_canvas_window, width=width, height=height)
            _sync_rule_scrollregion()

        root.bind("<Configure>", _sync_rule_scrollregion, add="+")
        self.rule_canvas.bind("<Configure>", _fit_rule_content, add="+")
        row = 0
        if txn:
            ttk.Label(root, text=f"Selected bank {noun}", font=("Segoe UI", 10, "bold")).grid(row=row, column=0, columnspan=2, sticky="w")
            row += 1
            ttk.Label(root, text=f"{txn.txn_date:%d/%m/%Y}   R {money(txn.payment_amount)}\n{txn.txn_type} — {txn.details}", wraplength=560).grid(row=row, column=0, columnspan=2, sticky="w", pady=(0,12))
            row += 1
        fields = [
            ("Rule name", "name"),
            ("Name / number to match", "pattern"),
            ("General ledger account", "account"),
            ("Pastel description (optional)", "description"),
            ("Pastel reference (auto-generated on each transaction)", "ref"),
            ("Priority", "priority"),
        ]
        for label, key in fields:
            ttk.Label(root, text=label).grid(row=row, column=0, sticky="w", padx=(0,10), pady=4)
            if key == "account":
                entry = ttk.Combobox(root, textvariable=self.vars[key], values=self.store.known_accounts(), width=45)
                entry.grid(row=row, column=1, sticky="ew", pady=4)
            else:
                entry = ttk.Entry(root, textvariable=self.vars[key], width=48)
                entry.grid(row=row, column=1, sticky="ew", pady=4)
                if key == "pattern" and self.locked_identity:
                    self.vars["pattern"].set(self.locked_identity)
                    entry.configure(state="readonly")
            row += 1
        ttk.Label(root, text="Matching method").grid(row=row, column=0, sticky="w", pady=4)
        combo = ttk.Combobox(root, textvariable=self.vars["mode_label"], values=[x[0] for x in self.MODES], state="readonly", width=45)
        if self.locked_identity:
            self.vars["mode_label"].set("Smart name + number")
            combo.configure(state="disabled")
        combo.grid(row=row, column=1, sticky="ew", pady=4); row += 1
        if self.locked_identity:
            ttk.Label(root,text=f"This rule is locked to {self.locked_identity}; it will not be applied to the merchant's other reference numbers.",wraplength=560,foreground="#555555").grid(row=row,column=0,columnspan=2,sticky="w",pady=(2,6)); row += 1

        vat_box = ttk.LabelFrame(root, text="VAT treatment", padding=8)
        vat_box.grid(row=row, column=0, columnspan=2, sticky="ew", pady=(8,4)); row += 1
        ttk.Radiobutton(vat_box, text="No VAT", variable=self.vars["vat"], value=False, command=self._vat_state).pack(side="left", padx=(0,14))
        ttk.Radiobutton(vat_box, text="VAT", variable=self.vars["vat"], value=True, command=self._vat_state).pack(side="left")
        ttk.Label(vat_box, text="Pastel tax type:").pack(side="left", padx=(24,6))
        self.tax_entry = ttk.Entry(vat_box, textvariable=self.vars["tax"], width=6)
        self.tax_entry.pack(side="left")
        self._vat_state()

        amount_box = ttk.LabelFrame(root, text="Optional amount-based allocation", padding=8)
        amount_box.grid(row=row, column=0, columnspan=2, sticky="nsew", pady=(8,4))
        root.rowconfigure(row, weight=1)
        amount_box.columnconfigure(0, weight=1)
        amount_box.rowconfigure(6, weight=1)
        row += 1
        ttk.Checkbutton(amount_box, text="Use amount-based allocation rule", variable=self.vars["amount_enabled"], command=self._amount_state).grid(row=0, column=0, columnspan=6, sticky="w", pady=(0,6))
        ttk.Label(amount_box, text="If amount").grid(row=1, column=0, sticky="w")
        self.amount_op = ttk.Combobox(amount_box, textvariable=self.vars["amount_operator"], values=["<", "<=", ">", ">=", "="], state="readonly", width=5)
        self.amount_op.grid(row=1, column=1, padx=(5,8))
        self.amount_threshold = ttk.Entry(amount_box, textvariable=self.vars["amount_threshold"], width=12)
        self.amount_threshold.grid(row=1, column=2, padx=(0,10))
        ttk.Label(amount_box, text="then").grid(row=1, column=3, sticky="w")
        self.amount_action = ttk.Combobox(amount_box, textvariable=self.vars["amount_action_label"], values=["Automatically allocate", "Review each qualifying transaction"], state="readonly", width=31)
        self.amount_action.grid(row=1, column=4, padx=(6,0), sticky="ew")
        help_icon(amount_box, "Automatically allocate applies the alternative GL/description immediately. Review each qualifying transaction leaves matching amounts for you to allocate individually.").grid(row=1, column=5, padx=(4,0), sticky="w")
        self.amount_action.bind("<<ComboboxSelected>>", lambda e: self._amount_state())
        ttk.Label(amount_box, text="Alternative GL").grid(row=2, column=0, columnspan=2, sticky="w", pady=(7,0))
        self.amount_account = ttk.Combobox(amount_box, textvariable=self.vars["amount_account"], values=self.store.known_accounts(), width=20)
        self.amount_account.grid(row=2, column=2, columnspan=3, sticky="ew", pady=(7,0))
        help_icon(amount_box, "General ledger account used only when the amount condition is met and the action is Automatically allocate.").grid(row=2, column=5, padx=(4,0), pady=(7,0), sticky="w")
        ttk.Label(amount_box, text="Alternative description").grid(row=3, column=0, columnspan=2, sticky="w", pady=(7,0))
        self.amount_description = ttk.Entry(amount_box, textvariable=self.vars["amount_description"], width=36)
        self.amount_description.grid(row=3, column=2, columnspan=3, sticky="ew", pady=(7,0))
        help_icon(amount_box, "Optional Pastel description used for the amount-condition branch. Leave blank to keep the normal rule description.").grid(row=3, column=5, padx=(4,0), pady=(7,0), sticky="w")
        ttk.Label(amount_box, text="Automatically allocate uses the Alternative GL/description. Review each qualifying transaction shows the matching exception payments/receipts in the table below so you can allocate one or many of them separately.", foreground="#555555", wraplength=650).grid(row=4, column=0, columnspan=6, sticky="w", pady=(6,0))
        ttk.Label(amount_box, text="If the amount condition is not met, the normal GL account and normal description above are used automatically.", foreground="#555555", wraplength=650).grid(row=5, column=0, columnspan=6, sticky="w", pady=(3,0))

        self.amount_review_box = ttk.LabelFrame(amount_box, text="Transactions caught by this amount condition — select and allocate individually", padding=7)
        self.amount_review_box.grid(row=6, column=0, columnspan=6, sticky="nsew", pady=(8,0))
        for _c in range(6):
            amount_box.columnconfigure(_c, weight=1 if _c == 0 else 0)
        review_cols = ("pick", "date", "amount", "details", "account", "description")
        self.amount_review_tree = ttk.Treeview(self.amount_review_box, columns=review_cols, show="headings", selectmode="none", height=7)
        review_labels = {"pick":"Select", "date":"Date", "amount":"Amount", "details":"Bank description / reference", "account":"Assigned GL", "description":"Pastel description"}
        review_widths = {"pick":58, "date":82, "amount":92, "details":245, "account":95, "description":150}
        for c in review_cols:
            self.amount_review_tree.heading(c, text=review_labels[c])
            self.amount_review_tree.column(c, width=review_widths[c], anchor="center" if c in {"pick", "date"} else ("e" if c == "amount" else "w"), stretch=c in {"details", "description"})
        ry = ttk.Scrollbar(self.amount_review_box, orient="vertical", command=self.amount_review_tree.yview)
        self.amount_review_tree.configure(yscrollcommand=ry.set, height=6)

        # Always-visible allocation toolbar. This deliberately sits ABOVE the
        # transaction table so Windows display scaling cannot hide the action.
        self.amount_review_toolbar = ttk.Frame(self.amount_review_box)
        self.amount_review_toolbar.grid(row=0, column=0, columnspan=6, sticky="ew", pady=(0,7))
        ttk.Label(self.amount_review_toolbar, text="Tick the transactions to allocate, then:", font=("Segoe UI", 9, "bold")).pack(side="left")
        self.amount_review_assign_button = ttk.Button(
            self.amount_review_toolbar, text="Assign selected…", command=self._amount_review_assign_selected, style="Accent.TButton"
        )
        self.amount_review_assign_button.pack(side="left", padx=(10,6))
        ttk.Button(self.amount_review_toolbar, text="Select all shown", command=self._amount_review_select_all).pack(side="left", padx=3)
        ttk.Button(self.amount_review_toolbar, text="Clear selection", command=self._amount_review_clear_selection).pack(side="left", padx=3)
        self.amount_review_summary = ttk.Label(self.amount_review_toolbar, text="", foreground="#555555")
        self.amount_review_summary.pack(side="right", padx=(12,0))

        self.amount_review_tree.grid(row=1, column=0, columnspan=5, sticky="nsew")
        ry.grid(row=1, column=5, sticky="ns")
        self.amount_review_box.columnconfigure(0, weight=1)
        self.amount_review_box.rowconfigure(1, weight=1)
        self.amount_review_tree.bind("<Button-1>", self._amount_review_tree_click, add="+")
        self.amount_review_tree.bind("<Return>", lambda _e: self._amount_review_assign_selected(), add="+")

        self.vars["amount_threshold"].trace_add("write", lambda *_: self._refresh_amount_review_table())
        self.vars["amount_operator"].trace_add("write", lambda *_: self._refresh_amount_review_table())
        self.vars["pattern"].trace_add("write", lambda *_: self._refresh_amount_review_table())
        self.vars["mode_label"].trace_add("write", lambda *_: self._refresh_amount_review_table())
        self._amount_state()

        ttk.Label(root, text="Tip: Smart matching lets 'HOLLARD 0923' match a bank reference such as 'HOLLARD HOL5910923 260601'.", wraplength=560).grid(row=row, column=0, columnspan=2, sticky="w", pady=(8,10)); row += 1
        btns = ttk.Frame(root); btns.grid(row=row, column=0, columnspan=2, sticky="e")
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=(8,0))
        ttk.Button(btns, text="Save rule", command=self.save).pack(side="right")
        root.columnconfigure(1, weight=1)
        self.bind("<Return>", lambda e: self.save())
        self.bind("<Escape>", lambda e: self.destroy())
        self.wait_visibility(); self.focus_force()

    def _vat_state(self):
        self.tax_entry.configure(state="normal" if self.vars["vat"].get() else "disabled")

    def _amount_state(self):
        enabled = bool(self.vars["amount_enabled"].get())
        review_each = self.vars["amount_action_label"].get() == "Review each qualifying transaction"
        self.amount_op.configure(state="readonly" if enabled else "disabled")
        self.amount_threshold.configure(state="normal" if enabled else "disabled")
        self.amount_action.configure(state="readonly" if enabled else "disabled")
        auto_state = "normal" if (enabled and not review_each) else "disabled"
        self.amount_account.configure(state=auto_state)
        self.amount_description.configure(state=auto_state)
        if hasattr(self, "amount_review_box"):
            if enabled and review_each:
                self.amount_review_box.grid()
                self._refresh_amount_review_table()
            else:
                self.amount_review_box.grid_remove()

    def _amount_review_candidates(self) -> List[Tuple[int, Transaction]]:
        if not hasattr(self.app, "_list"):
            return []
        pattern = self.locked_identity or self.vars["pattern"].get().strip()
        mode = "SMART" if self.locked_identity else next((b for a,b in self.MODES if a == self.vars["mode_label"].get()), "SMART")
        return rule_window_amount_candidates(
            self.app._list(self.direction), self.direction, mode, pattern,
            self.vars["amount_operator"].get().strip(), self.vars["amount_threshold"].get().strip()
        )

    def _refresh_amount_review_table(self):
        if not hasattr(self, "amount_review_tree"):
            return
        tree = self.amount_review_tree
        tree.delete(*tree.get_children())
        candidates = self._amount_review_candidates()
        valid = {idx for idx, _t in candidates}
        self.amount_review_selected.intersection_update(valid)
        for idx, t in candidates:
            pending = self.pending_amount_review_assignments.get(idx)
            account = pending[0] if pending else t.account
            description = pending[1] if (pending and pending[1]) else (t.description or "")
            tree.insert(
                "", "end", iid=str(idx),
                values=("☑" if idx in self.amount_review_selected else "☐", t.txn_date.strftime("%d/%m/%Y"), f"R {money(t.payment_amount)}", t.details, account, description)
            )
        selected_count = len(self.amount_review_selected)
        self.amount_review_summary.configure(text=f"{len(candidates)} qualifying • {selected_count} selected")
        if hasattr(self, "amount_review_assign_button"):
            self.amount_review_assign_button.configure(
                text=f"Assign selected ({selected_count})…" if selected_count else "Assign selected…",
                state="normal" if selected_count else "disabled",
            )

    def _amount_review_tree_click(self, event):
        tree = self.amount_review_tree
        if tree.identify_region(event.x, event.y) != "cell" or tree.identify_column(event.x) != "#1":
            return
        iid = tree.identify_row(event.y)
        if not iid:
            return
        try:
            idx = int(iid)
        except ValueError:
            return
        if idx in self.amount_review_selected:
            self.amount_review_selected.remove(idx)
        else:
            self.amount_review_selected.add(idx)
        self._refresh_amount_review_table()
        return "break"

    def _amount_review_select_all(self):
        self.amount_review_selected = {idx for idx, _t in self._amount_review_candidates()}
        self._refresh_amount_review_table()

    def _amount_review_clear_selection(self):
        self.amount_review_selected.clear()
        self._refresh_amount_review_table()

    def _amount_review_assign_selected(self):
        candidates = dict(self._amount_review_candidates())
        selected_pairs = [(idx, candidates[idx]) for idx in sorted(self.amount_review_selected) if idx in candidates]
        if not selected_pairs:
            messagebox.showinfo(APP_NAME, "Tick one or more transactions in the table first.", parent=self)
            return
        txns = [t for _idx, t in selected_pairs]
        dlg = MultiReviewAssignDialog(self, txns, self.store.get_setting("vat_tax_type", ""), self.store.known_accounts())
        self.wait_window(dlg)
        if not dlg.result:
            return
        account, description, vat, tax_type = dlg.result
        for idx, _t in selected_pairs:
            self.pending_amount_review_assignments[idx] = (account, description, vat, tax_type)
        self.amount_review_selected.clear()
        self._refresh_amount_review_table()

    def save(self):
        name = self.vars["name"].get().strip()
        pattern = self.vars["pattern"].get().strip()
        account = self.vars["account"].get().strip()
        ref = self.vars["ref"].get().strip()
        description = self.vars["description"].get().strip()
        if not name or not pattern or not account:
            messagebox.showerror(APP_NAME, "Rule name, match text and GL account are required.", parent=self)
            return
        if len(account) > 7:
            if not messagebox.askyesno(APP_NAME, "This GL account is longer than Sage's published 7-character cash-book layout. Save it anyway? Validation will block export until corrected.", parent=self):
                return
        if len(ref) > 8:
            messagebox.showerror(APP_NAME, "Pastel reference may not exceed 8 characters.", parent=self); return
        amount_operator = ""
        amount_threshold = ""
        amount_account = ""
        amount_description = ""
        amount_action = "AUTO"
        if self.vars["amount_enabled"].get():
            amount_operator = self.vars["amount_operator"].get().strip()
            amount_action = "REVIEW" if self.vars["amount_action_label"].get() == "Review each qualifying transaction" else "AUTO"
            raw_threshold = self.vars["amount_threshold"].get().strip()
            if amount_operator not in {"<", "<=", ">", ">=", "="} or not raw_threshold:
                messagebox.showerror(APP_NAME, "For an amount-based rule, choose an operator and enter the amount threshold.", parent=self); return
            if amount_action == "AUTO":
                amount_account = self.vars["amount_account"].get().strip()
                amount_description = self.vars["amount_description"].get().strip()
                if not amount_account:
                    messagebox.showerror(APP_NAME, "Automatic amount allocation requires an Alternative GL account. Choose Review each qualifying transaction if you want to allocate those rows one at a time.", parent=self); return
            try:
                threshold_value = Decimal(raw_threshold.replace(",", ""))
            except (InvalidOperation, ValueError):
                messagebox.showerror(APP_NAME, "The amount-rule threshold must be a valid number.", parent=self); return
            amount_threshold = money(threshold_value)
        try:
            priority = int(self.vars["priority"].get() or 100)
            tax_type = int(self.vars["tax"].get() or 0) if self.vars["vat"].get() else 0
        except ValueError:
            messagebox.showerror(APP_NAME, "Priority and tax type must be whole numbers.", parent=self); return
        mode = next((b for a,b in self.MODES if a == self.vars["mode_label"].get()), "SMART")
        r = Rule(
            self.rule.id if self.rule else None, name, mode, pattern, account, self.vars["vat"].get(), tax_type, ref, priority, True, self.direction,
            description, amount_operator, amount_threshold, amount_account, amount_description, amount_action,
        )
        rid = self.store.save_rule(r)
        self.applied_review_transaction_ids = set()
        if amount_action == "REVIEW" and self.pending_amount_review_assignments and hasattr(self.app, "_list"):
            current_candidates = dict(self._amount_review_candidates())
            live = self.app._list(self.direction)
            for idx, assignment in list(self.pending_amount_review_assignments.items()):
                if idx not in current_candidates or not (0 <= idx < len(live)):
                    continue
                account_i, description_i, vat_i, tax_type_i = assignment
                t = live[idx]
                apply_rule_window_manual_assignment([t], account_i, description_i, vat_i, tax_type_i)
                self.applied_review_transaction_ids.add(id(t))
        self.result = rid
        self.destroy()


class ManualAssignDialog(tk.Toplevel):
    def __init__(self, parent, txn: Transaction, default_tax_type: str, known_accounts: Optional[List[str]] = None):
        super().__init__(parent)
        self.txn = txn
        self.result = None
        noun = "receipt" if (txn.direction or "PAYMENT").upper() == "RECEIPT" else "payment"
        self.title(f"Assign this {noun} only")
        self.transient(parent); self.grab_set(); self.resizable(False, False)
        a = tk.StringVar(value=txn.account)
        v = tk.BooleanVar(value=txn.vat)
        tax = tk.StringVar(value=str(txn.tax_type or default_tax_type or ""))
        ref = tk.StringVar(value=txn.pastel_ref or derive_pastel_reference(txn.details, smart_key(txn.details), txn.row_no))
        desc = tk.StringVar(value=txn.description or "")
        f = ttk.Frame(self, padding=14); f.grid()
        ttk.Label(f, text=f"{txn.txn_date:%d/%m/%Y}   R {money(txn.payment_amount)}", font=("Segoe UI",10,"bold")).grid(row=0,column=0,columnspan=2,sticky="w")
        ttk.Label(f, text=txn.details, wraplength=520).grid(row=1,column=0,columnspan=2,sticky="w",pady=(0,10))
        ttk.Label(f,text="GL account").grid(row=2,column=0,sticky="w",pady=4); ttk.Combobox(f,textvariable=a,values=known_accounts or [],width=37).grid(row=2,column=1,pady=4)
        ttk.Label(f,text="Pastel description").grid(row=3,column=0,sticky="w",pady=4); ttk.Entry(f,textvariable=desc,width=40).grid(row=3,column=1,pady=4)
        ttk.Label(f,text="Pastel reference").grid(row=4,column=0,sticky="w",pady=4); ttk.Entry(f,textvariable=ref,width=40).grid(row=4,column=1,pady=4)
        vatframe=ttk.Frame(f); vatframe.grid(row=5,column=0,columnspan=2,sticky="w",pady=6)
        ttk.Checkbutton(vatframe,text="VAT",variable=v).pack(side="left")
        ttk.Label(vatframe,text="Tax type").pack(side="left",padx=(18,5)); ttk.Entry(vatframe,textvariable=tax,width=6).pack(side="left")
        ttk.Label(f,text="This assignment applies only to this statement. Use 'Save rule' when you want future CSV files to remember the GL/VAT/description allocation.",wraplength=520).grid(row=6,column=0,columnspan=2,sticky="w",pady=(4,10))
        b=ttk.Frame(f); b.grid(row=7,column=0,columnspan=2,sticky="e")
        ttk.Button(b,text="Cancel",command=self.destroy).pack(side="right",padx=(8,0)); ttk.Button(b,text="Apply",command=lambda:self._save(a,v,tax,ref,desc)).pack(side="right")
        self.wait_visibility(); self.focus_force()
    def _save(self,a,v,tax,ref,desc):
        account=a.get().strip(); rr=ref.get().strip()
        if not account:
            messagebox.showerror(APP_NAME,"GL account is required.",parent=self); return
        if len(rr)>8:
            messagebox.showerror(APP_NAME,"Pastel reference may not exceed 8 characters.",parent=self); return
        try: tt=int(tax.get() or 0) if v.get() else 0
        except ValueError:
            messagebox.showerror(APP_NAME,"Tax type must be a whole number.",parent=self); return
        self.result=(account,bool(v.get()),tt,rr,desc.get().strip()); self.destroy()


class MultiReviewAssignDialog(tk.Toplevel):
    def __init__(self, parent, txns: List[Transaction], default_tax_type: str, known_accounts: Optional[List[str]] = None):
        super().__init__(parent)
        self.result = None
        self.txns = txns
        count = len(txns)
        noun = "receipt" if txns and (txns[0].direction or "PAYMENT").upper() == "RECEIPT" else "payment"
        self.title(f"Assign {count} selected {noun}{'' if count == 1 else 's'}")
        self.transient(parent); self.grab_set(); self.resizable(False, False)
        account = tk.StringVar(value="")
        descriptions = {(t.description or "").strip() for t in txns}
        description = tk.StringVar(value=next(iter(descriptions)) if len(descriptions) == 1 else "")
        vat_values = {bool(t.vat) for t in txns}
        vat = tk.BooleanVar(value=next(iter(vat_values)) if len(vat_values) == 1 else False)
        tax_values = {int(t.tax_type or 0) for t in txns if t.vat}
        initial_tax = str(next(iter(tax_values))) if len(tax_values) == 1 else str(default_tax_type or "")
        tax = tk.StringVar(value=initial_tax)
        total = sum((t.payment_amount for t in txns), Decimal("0.00"))
        f = ttk.Frame(self, padding=14); f.grid(sticky="nsew")
        ttk.Label(f, text=f"{count} Amount Review {noun}{'' if count == 1 else 's'} selected • Total R {money(total)}", font=("Segoe UI",10,"bold")).grid(row=0,column=0,columnspan=2,sticky="w")
        preview = "\n".join(f"{t.txn_date:%d/%m/%Y}  R {money(t.payment_amount)}  {t.details[:55]}" for t in txns[:6])
        if count > 6:
            preview += f"\n… plus {count - 6} more selected rows"
        ttk.Label(f, text=preview, wraplength=620).grid(row=1,column=0,columnspan=2,sticky="w",pady=(4,10))
        ttk.Label(f,text="GL account for selected rows").grid(row=2,column=0,sticky="w",pady=4)
        ttk.Combobox(f,textvariable=account,values=known_accounts or [],width=40).grid(row=2,column=1,pady=4)
        ttk.Label(f,text="Pastel description (optional)").grid(row=3,column=0,sticky="w",pady=4)
        ttk.Entry(f,textvariable=description,width=43).grid(row=3,column=1,pady=4)
        ttk.Label(f,text="Leave description blank to keep each selected row's existing description.",foreground="#555555",wraplength=560).grid(row=4,column=0,columnspan=2,sticky="w")
        vatframe=ttk.Frame(f); vatframe.grid(row=5,column=0,columnspan=2,sticky="w",pady=8)
        ttk.Checkbutton(vatframe,text="VAT",variable=vat).pack(side="left")
        ttk.Label(vatframe,text="Tax type").pack(side="left",padx=(18,5)); ttk.Entry(vatframe,textvariable=tax,width=6).pack(side="left")
        ttk.Label(f,text="Only the transactions selected in the rule window will receive this allocation. All other qualifying transactions stay unchanged so you can assign them separately.",foreground="#555555",wraplength=600).grid(row=6,column=0,columnspan=2,sticky="w",pady=(4,10))
        b=ttk.Frame(f); b.grid(row=7,column=0,columnspan=2,sticky="e")
        ttk.Button(b,text="Cancel",command=self.destroy).pack(side="right",padx=(8,0))
        ttk.Button(b,text="Assign selected",command=lambda:self._save(account,description,vat,tax)).pack(side="right")
        self.wait_visibility(); self.focus_force()

    def _save(self, account, description, vat, tax):
        acc = account.get().strip()
        if not acc:
            messagebox.showerror(APP_NAME,"GL account is required.",parent=self); return
        if len(acc) > 7:
            if not messagebox.askyesno(APP_NAME,"This GL account is longer than Sage's published 7-character layout. Use it anyway? Export validation will still block invalid accounts.",parent=self):
                return
        try:
            tt = int(tax.get() or 0) if vat.get() else 0
        except ValueError:
            messagebox.showerror(APP_NAME,"Tax type must be a whole number.",parent=self); return
        self.result = (acc, description.get().strip(), bool(vat.get()), tt)
        self.destroy()


class CorrectionDialog(tk.Toplevel):
    def __init__(self, parent, store: Store, txn: Transaction, rule: Optional[Rule]):
        super().__init__(parent)
        self.result = None
        self.rule = rule
        noun = "receipt" if (txn.direction or "PAYMENT").upper() == "RECEIPT" else "payment"
        self.title(f"Correct auto-allocation — {noun}")
        self.transient(parent); self.grab_set(); self.resizable(False, False)
        a = tk.StringVar(value=txn.account)
        desc = tk.StringVar(value=txn.description or "")
        v = tk.BooleanVar(value=txn.vat)
        tax = tk.StringVar(value=str(txn.tax_type or store.get_setting("vat_tax_type", "") or ""))
        ref = tk.StringVar(value=txn.pastel_ref)
        update_rule = tk.BooleanVar(value=False)
        f = ttk.Frame(self, padding=14); f.grid(sticky="nsew")
        ttk.Label(f, text="Flagged false auto-allocation", font=("Segoe UI",10,"bold")).grid(row=0,column=0,columnspan=2,sticky="w")
        ttk.Label(f, text=f"{txn.txn_date:%d/%m/%Y}   R {money(txn.payment_amount)}\n{txn.details}", wraplength=560).grid(row=1,column=0,columnspan=2,sticky="w",pady=(0,10))
        ttk.Label(f,text="Correct GL account").grid(row=2,column=0,sticky="w",pady=4); ttk.Combobox(f,textvariable=a,values=store.known_accounts(),width=40).grid(row=2,column=1,pady=4)
        ttk.Label(f,text="Correct Pastel description").grid(row=3,column=0,sticky="w",pady=4); ttk.Entry(f,textvariable=desc,width=43).grid(row=3,column=1,pady=4)
        ttk.Label(f,text="Pastel reference").grid(row=4,column=0,sticky="w",pady=4); ttk.Entry(f,textvariable=ref,width=43).grid(row=4,column=1,pady=4)
        vatframe=ttk.Frame(f); vatframe.grid(row=5,column=0,columnspan=2,sticky="w",pady=6)
        ttk.Checkbutton(vatframe,text="VAT",variable=v).pack(side="left")
        ttk.Label(vatframe,text="Tax type").pack(side="left",padx=(18,5)); ttk.Entry(vatframe,textvariable=tax,width=6).pack(side="left")
        if rule:
            text = f"Also update saved rule '{rule.name}' for future matching transactions"
            ttk.Checkbutton(f,text=text,variable=update_rule).grid(row=6,column=0,columnspan=2,sticky="w",pady=(8,2))
            if txn.amount_condition_applied and rule.amount_operator:
                ttk.Label(f,text="This transaction used the amount-based branch; updating the saved rule will correct that branch's GL account.",foreground="#555555",wraplength=560).grid(row=7,column=0,columnspan=2,sticky="w")
        else:
            ttk.Label(f,text="No saved rule is available, so this correction will apply to this statement only.",foreground="#555555",wraplength=560).grid(row=6,column=0,columnspan=2,sticky="w",pady=(8,2))
        b=ttk.Frame(f); b.grid(row=8,column=0,columnspan=2,sticky="e",pady=(12,0))
        ttk.Button(b,text="Cancel",command=self.destroy).pack(side="right",padx=(8,0))
        ttk.Button(b,text="Apply correction",command=lambda:self._save(a,desc,v,tax,ref,update_rule)).pack(side="right")
        self.wait_visibility(); self.focus_force()

    def _save(self,a,desc,v,tax,ref,update_rule):
        account=a.get().strip(); rr=ref.get().strip()
        if not account:
            messagebox.showerror(APP_NAME,"GL account is required.",parent=self); return
        if len(rr)>8:
            messagebox.showerror(APP_NAME,"Pastel reference may not exceed 8 characters.",parent=self); return
        try:
            tt=int(tax.get() or 0) if v.get() else 0
        except ValueError:
            messagebox.showerror(APP_NAME,"Tax type must be a whole number.",parent=self); return
        self.result=(account,desc.get().strip(),bool(v.get()),tt,rr,bool(update_rule.get())); self.destroy()


def tutorial_workspace_snapshot(store: "Store", txns=None, receipts=None) -> Dict[str, object]:
    """Summarise the user's current progress for adaptive onboarding."""
    txns = list(txns or [])
    receipts = list(receipts or [])
    all_txns = txns + receipts
    selected = [t for t in all_txns if t.include]
    unassigned = [t for t in selected if not t.account]
    ambiguous = [t for t in selected if t.ambiguous]
    assigned = [t for t in all_txns if t.account and not t.ambiguous]
    recurring = [t for t in all_txns if t.recurring_count >= 2]
    try:
        rule_count = len(store.all_rules())
    except Exception:
        rule_count = 0
    settings = {
        "contra_account": (store.get_setting("contra_account", "") or "").strip(),
        "vat_tax_type": (store.get_setting("vat_tax_type", "") or "").strip(),
        "vat_rate": (store.get_setting("vat_rate", "15") or "15").strip(),
        "fiscal_start_month": (store.get_setting("fiscal_start_month", "3") or "3").strip(),
    }
    try:
        hist_row = store.conn.execute("SELECT COUNT(*) AS c FROM transaction_history").fetchone()
        history_count = int(hist_row["c"] if hist_row else 0)
    except Exception:
        history_count = 0
    return {
        "loaded": bool(all_txns),
        "payments": len(txns),
        "receipts": len(receipts),
        "selected": len(selected),
        "assigned": len(assigned),
        "unassigned": len(unassigned),
        "ambiguous": len(ambiguous),
        "recurring": len(recurring),
        "rules": rule_count,
        "history": history_count,
        "settings_ready": bool(settings["contra_account"] or settings["vat_tax_type"]),
        "has_activity": bool(all_txns or rule_count or history_count or settings["contra_account"] or settings["vat_tax_type"]),
    }


def should_auto_start_tutorial(store: "Store") -> bool:
    """Only auto-open onboarding in a genuinely new/empty workspace."""
    try:
        if (store.get_setting(TUTORIAL_SETTING_KEY, "") or "").strip():
            return False
        snap = tutorial_workspace_snapshot(store)
        if snap["has_activity"]:
            return False
        if (store.get_setting(SESSION_SETTING_KEY, "") or "").strip():
            return False
        return True
    except Exception:
        return False


def adaptive_tutorial_topic_ids(snapshot: Dict[str, object]) -> List[str]:
    """Build the shortest useful curriculum from current profile/statement state."""
    ids = ["workflow", "profiles"]
    if not snapshot.get("settings_ready"):
        ids.append("settings")
    if not snapshot.get("loaded"):
        ids.extend(["load", "payments_receipts", "assign_once", "vat", "recurring", "selection", "validation", "export", "autosave", "classic", "backup"])
        return ids
    ids.append("payments_receipts")
    if int(snapshot.get("unassigned") or 0) > 0:
        ids.extend(["orange", "assign_once"])
    elif int(snapshot.get("assigned") or 0) > 0:
        ids.append("green")
    if int(snapshot.get("ambiguous") or 0) > 0:
        ids.append("ambiguous")
    if int(snapshot.get("rules") or 0) == 0:
        ids.extend(["assign_once", "vat", "amount_rules"])
    else:
        ids.extend(["wrong_gl", "amount_rules"])
    if int(snapshot.get("recurring") or 0) > 0:
        ids.append("recurring")
    else:
        ids.append("recurring_missing")
    ids.extend(["selection", "validation", "export", "autosave", "classic", "backup"])
    out = []
    for topic_id in ids:
        if topic_id not in out:
            out.append(topic_id)
    return out


def search_tutorial_topics(query: str) -> List[Dict[str, str]]:
    q = normalize_text(query)
    if not q:
        return list(TUTORIAL_TOPICS)
    words = [w for w in q.split() if len(w) > 1]
    ranked = []
    for topic in TUTORIAL_TOPICS:
        hay = normalize_text(f"{topic['title']} {topic['keywords']} {topic['body']}")
        score = 0
        if q and q in hay:
            score += 12
        for word in words:
            if word in hay:
                score += 3
            if word in normalize_text(topic["title"]):
                score += 3
            if word in normalize_text(topic["keywords"]):
                score += 2
        if score:
            ranked.append((score, topic["title"], topic))
    ranked.sort(key=lambda x: (-x[0], x[1]))
    return [x[2] for x in ranked]


class App(tk.Tk):
    DIRECTIONS = ("PAYMENT", "RECEIPT")

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1380x800")
        self.minsize(1100, 680)
        self.profile_manager = ProfileManager()
        self.active_profile_id = self.profile_manager.active_id
        self.store = Store(self.profile_manager.db_path(self.active_profile_id))
        self.profile_var = tk.StringVar(value=self.profile_manager.profile_name(self.active_profile_id))
        self.profile_db_var = tk.StringVar(value=f"Profile database: {self.store.path}")
        self.txns: List[Transaction] = []
        self.receipts: List[Transaction] = []
        self.review_selection: Dict[str, set] = {d: set() for d in self.DIRECTIONS}
        self.current_file = ""
        self.parser_name = ""
        self.status_var = tk.StringVar(value="Load a bank CSV to begin.")
        self.search_vars = {d: tk.StringVar() for d in self.DIRECTIONS}
        self.filter_vars = {d: tk.StringVar(value="All") for d in self.DIRECTIONS}
        self.repeat_vars = {d: tk.StringVar(value="— Select repeat description —") for d in self.DIRECTIONS}
        self.sort_vars = {d: tk.StringVar(value="Oldest first") for d in self.DIRECTIONS}
        self.summary_vars = {d: tk.StringVar(value="No statement loaded") for d in self.DIRECTIONS}
        self.repeat_display_to_key: Dict[str, Dict[str, str]] = {d: {} for d in self.DIRECTIONS}
        self.trees: Dict[str, ttk.Treeview] = {}
        self.repeat_combos: Dict[str, ttk.Combobox] = {}
        self.recurring_trees: Dict[str, ttk.Treeview] = {}
        self.recurring_key_to_indices: Dict[str, Dict[str, List[int]]] = {d: {} for d in self.DIRECTIONS}
        self.recurring_item_to_index: Dict[str, Dict[str, int]] = {d: {} for d in self.DIRECTIONS}
        self._configure_style()
        self._build()
        self._refresh_profile_ui()
        self._startup_restore()
        self.after(450, self._maybe_start_tutorial)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _refresh_profile_ui(self):
        name = self.profile_manager.profile_name(self.active_profile_id)
        self.profile_var.set(name)
        for _combo_name in ("profile_combo", "profile_combo_modern", "profile_combo_classic"):
            _combo = getattr(self, _combo_name, None)
            if _combo is not None:
                _combo.configure(values=self.profile_manager.names())
        self.profile_db_var.set(f"Profile database: {self.store.path}")
        self.title(f"{APP_NAME} {APP_VERSION} — {name}")

    def _persist_profile_settings(self):
        if not hasattr(self, "setting_vars"):
            return
        for key, var in self.setting_vars.items():
            self.store.set_setting(key, var.get().strip())

    def _load_active_profile_settings(self):
        if not hasattr(self, "setting_vars"):
            return
        defaults = {"contra_account":"", "vat_tax_type":"", "vat_rate":"15", "fiscal_start_month":"3", "project_code":""}
        for key, var in self.setting_vars.items():
            var.set(self.store.get_setting(key, defaults.get(key, "")))

    def _confirm_profile_change(self) -> bool:
        if not (self.txns or self.receipts):
            return True
        return messagebox.askyesno(
            APP_NAME,
            "Switching company profiles will clear the currently loaded bank statement and any statement-only manual changes.\n\nSaved rules and settings are already stored in the current profile. Continue?"
        )

    def _clear_statement_for_profile_change(self):
        self.txns = []
        self.receipts = []
        self.current_file = ""
        self.parser_name = ""
        for direction in self.DIRECTIONS:
            self.search_vars[direction].set("")
            self.filter_vars[direction].set("All")
            self.repeat_vars[direction].set("— Select repeat description —")
            self.repeat_display_to_key[direction] = {}
            self.summary_vars[direction].set("No statement loaded")
            tree = self.trees.get(direction)
            if tree:
                tree.delete(*tree.get_children())
            rtree = self.recurring_trees.get(direction)
            if rtree:
                rtree.delete(*rtree.get_children())
            self.update_repeat_dropdown(direction)
        self.refresh_rules()

    def _activate_profile(self, profile_id: str):
        if profile_id == self.active_profile_id:
            self._refresh_profile_ui()
            return
        self._persist_profile_settings()
        try:
            self.store.conn.close()
        except Exception:
            pass
        self.profile_manager.set_active(profile_id)
        self.active_profile_id = profile_id
        self.store = Store(self.profile_manager.db_path(profile_id))
        self._load_active_profile_settings()
        self._clear_statement_for_profile_change()
        self._refresh_profile_ui()
        self.status_var.set(f"Switched to profile '{self.profile_manager.profile_name(profile_id)}'. Load that company's bank CSV to begin.")

    def select_profile(self, event=None):
        profile_id = self.profile_manager.id_for_name(self.profile_var.get())
        if not profile_id or profile_id == self.active_profile_id:
            self._refresh_profile_ui()
            return
        if not self._confirm_profile_change():
            self._refresh_profile_ui()
            return
        self._activate_profile(profile_id)

    def new_profile(self):
        if not self._confirm_profile_change():
            return
        name = simpledialog.askstring(APP_NAME, "New company profile name:", parent=self)
        if name is None:
            return
        try:
            profile_id = self.profile_manager.create_profile(name)
        except ValueError as e:
            messagebox.showerror(APP_NAME, str(e), parent=self)
            return
        self._activate_profile(profile_id)

    def rename_profile(self):
        old_name = self.profile_manager.profile_name(self.active_profile_id)
        name = simpledialog.askstring(APP_NAME, "Rename current company profile:", initialvalue=old_name, parent=self)
        if name is None:
            return
        try:
            self.profile_manager.rename_profile(self.active_profile_id, name)
        except ValueError as e:
            messagebox.showerror(APP_NAME, str(e), parent=self)
            return
        self._refresh_profile_ui()
        self.status_var.set(f"Profile renamed to '{self.profile_manager.profile_name(self.active_profile_id)}'.")

    def delete_profile(self):
        if self.active_profile_id == "default":
            messagebox.showinfo(APP_NAME, "The Default profile contains your original rules/settings database and cannot be deleted. You can rename it to the company name instead.")
            return
        name = self.profile_manager.profile_name(self.active_profile_id)
        if not messagebox.askyesno(APP_NAME, f"Delete profile '{name}'?\n\nThis permanently deletes that profile's saved rules, settings and transaction history. This cannot be undone."):
            return
        self._persist_profile_settings()
        try:
            self.store.conn.close()
        except Exception:
            pass
        old_id = self.active_profile_id
        self.profile_manager.delete_profile(old_id)
        self.active_profile_id = self.profile_manager.active_id
        self.store = Store(self.profile_manager.db_path(self.active_profile_id))
        self._load_active_profile_settings()
        self._clear_statement_for_profile_change()
        self._refresh_profile_ui()
        self.status_var.set(f"Deleted profile '{name}'. Switched to '{self.profile_manager.profile_name(self.active_profile_id)}'.")

    def _app_folder(self) -> Path:
        if getattr(sys, "frozen", False):
            return Path(sys.executable).resolve().parent
        return Path(__file__).resolve().parent

    def _bootstrap_rules_if_present(self) -> int:
        """Import a rules backup beside the EXE only into a completely empty profile.

        The public portable build does not contain a rules file. This hook allows a
        private/personal bundle to carry the user's rules without hard-coding or
        publishing them. Existing profiles are never overwritten or duplicated.
        """
        if not ALLOW_BUNDLED_RULE_BOOTSTRAP:
            return 0
        try:
            if self.store.all_rules():
                return 0
        except Exception:
            return 0
        candidate = self._app_folder() / BUNDLED_RULES_FILENAME
        if not candidate.exists():
            return 0
        count = 0
        try:
            with open(candidate, newline="", encoding="utf-8-sig") as f:
                for row in csv.DictReader(f):
                    direction = (row.get("direction") or "PAYMENT").strip().upper()
                    if direction not in self.DIRECTIONS:
                        direction = "PAYMENT"
                    try:
                        tax_type = int(row.get("tax_type", "0") or 0)
                    except ValueError:
                        tax_type = 0
                    try:
                        priority = int(row.get("priority", "100") or 100)
                    except ValueError:
                        priority = 100
                    r = Rule(
                        id=None,
                        name=(row.get("name") or "").strip(),
                        mode=(row.get("mode") or "SMART").strip(),
                        pattern=(row.get("pattern") or "").strip(),
                        account=(row.get("account") or "").strip(),
                        vat=(row.get("vat") or "0").strip() in {"1", "true", "True", "yes", "Yes"},
                        tax_type=tax_type,
                        pastel_ref=(row.get("pastel_ref") or "").strip(),
                        priority=priority,
                        enabled=(row.get("enabled") or "1").strip() not in {"0", "false", "False"},
                        direction=direction,
                        description=(row.get("description") or "").strip(),
                        amount_operator=(row.get("amount_operator") or "").strip(),
                        amount_threshold=(row.get("amount_threshold") or "").strip(),
                        amount_account=(row.get("amount_account") or "").strip(),
                        amount_description=(row.get("amount_description") or "").strip(),
                        amount_action=((row.get("amount_action") or "AUTO").strip().upper() or "AUTO"),
                    )
                    if r.name and r.pattern and r.account:
                        self.store.save_rule(r)
                        count += 1
        except Exception as e:
            self.status_var.set(f"Bundled rules were not imported: {e}")
            return 0
        if count:
            self.refresh_rules()
        return count

    def _session_ui_snapshot(self) -> Dict[str, object]:
        tx_selection = {}
        recurring_selection = {}
        recurring_open = {}
        for direction in self.DIRECTIONS:
            tree = self.trees.get(direction)
            tx_selection[direction] = list(tree.selection()) if tree else []
            rtree = self.recurring_trees.get(direction)
            recurring_selection[direction] = list(rtree.selection()) if rtree else []
            opened = []
            if rtree:
                for pid in rtree.get_children(""):
                    if rtree.item(pid, "open"):
                        opened.append(pid)
                    for kid in rtree.get_children(pid):
                        if rtree.item(kid, "open"):
                            opened.append(kid)
            recurring_open[direction] = opened
        active_tab = ""
        try:
            selected_tab = self.notebook.select()
            active_tab = str(self.notebook.tab(selected_tab, "text")) if selected_tab else ""
        except Exception:
            pass
        return {
            "search": {d: self.search_vars[d].get() for d in self.DIRECTIONS},
            "filter": {d: self.filter_vars[d].get() for d in self.DIRECTIONS},
            "repeat": {d: self.repeat_vars[d].get() for d in self.DIRECTIONS},
            "sort": {d: self.sort_vars[d].get() for d in self.DIRECTIONS},
            "transaction_selection": tx_selection,
            "recurring_selection": recurring_selection,
            "recurring_open": recurring_open,
            "active_tab": active_tab,
            "modern_page": getattr(self, "current_modern_page", ""),
            "window_geometry": self.geometry(),
        }

    def _save_session(self) -> bool:
        """Persist the current statement and UI state inside the active profile DB."""
        try:
            ui = self._session_ui_snapshot()
            payload = {
                "schema": 1,
                "saved_at": datetime.now().isoformat(timespec="seconds"),
                "current_file": self.current_file,
                "parser_name": self.parser_name,
                "payments": [transaction_to_session_dict(t) for t in self.txns],
                "receipts": [transaction_to_session_dict(t) for t in self.receipts],
                **ui,
            }
            self.store.set_setting(SESSION_SETTING_KEY, json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
            return True
        except Exception as e:
            try:
                self.status_var.set(f"Could not autosave current session: {e}")
            except Exception:
                pass
            return False

    def _restore_session(self) -> bool:
        """Restore the last autosaved snapshot for the active company profile."""
        try:
            raw = self.store.get_setting(SESSION_SETTING_KEY, "")
        except Exception:
            return False
        if not raw:
            return False
        try:
            data = json.loads(raw)
            if not isinstance(data, dict) or int(data.get("schema") or 0) != 1:
                return False
            self.txns = [transaction_from_session_dict(x) for x in (data.get("payments") or []) if isinstance(x, dict)]
            self.receipts = [transaction_from_session_dict(x) for x in (data.get("receipts") or []) if isinstance(x, dict)]
            self.current_file = str(data.get("current_file") or "")
            self.parser_name = str(data.get("parser_name") or "")
            self.store.remember_transactions(self.txns)
            self.store.remember_transactions(self.receipts)

            saved_search = data.get("search") if isinstance(data.get("search"), dict) else {}
            saved_filter = data.get("filter") if isinstance(data.get("filter"), dict) else {}
            saved_repeat = data.get("repeat") if isinstance(data.get("repeat"), dict) else {}
            saved_sort = data.get("sort") if isinstance(data.get("sort"), dict) else {}
            for direction in self.DIRECTIONS:
                self.search_vars[direction].set(str(saved_search.get(direction, "")))
                self.filter_vars[direction].set(str(saved_filter.get(direction, "All")))
                self.sort_vars[direction].set(str(saved_sort.get(direction, "Oldest first")))
                self.update_repeat_dropdown(direction)
                self.repeat_vars[direction].set(str(saved_repeat.get(direction, "— Select repeat description —")))
                self.refresh_transaction_tree(direction)
                self.refresh_recurring_tree(direction)
            self.refresh_rules()

            saved_open = data.get("recurring_open") if isinstance(data.get("recurring_open"), dict) else {}
            saved_rsel = data.get("recurring_selection") if isinstance(data.get("recurring_selection"), dict) else {}
            saved_tsel = data.get("transaction_selection") if isinstance(data.get("transaction_selection"), dict) else {}
            for direction in self.DIRECTIONS:
                tree = self.trees.get(direction)
                if tree:
                    valid = [str(iid) for iid in (saved_tsel.get(direction) or []) if tree.exists(str(iid))]
                    if valid:
                        tree.selection_set(valid)
                        tree.see(valid[0])
                rtree = self.recurring_trees.get(direction)
                if rtree:
                    for iid in (saved_open.get(direction) or []):
                        iid = str(iid)
                        if rtree.exists(iid):
                            rtree.item(iid, open=True)
                    valid_r = [str(iid) for iid in (saved_rsel.get(direction) or []) if rtree.exists(str(iid))]
                    if valid_r:
                        rtree.selection_set(valid_r)
                        rtree.see(valid_r[0])

            active_tab = str(data.get("active_tab") or "")
            if active_tab:
                for tab_id in self.notebook.tabs():
                    if str(self.notebook.tab(tab_id, "text")) == active_tab:
                        self.notebook.select(tab_id)
                        break
            saved_modern_page = str(data.get("modern_page") or "")
            self._restore_modern_view(active_tab, saved_modern_page)

            geometry = str(data.get("window_geometry") or "")
            if geometry and "x" in geometry:
                try:
                    self.geometry(geometry)
                except Exception:
                    pass

            if self.txns or self.receipts:
                source_note = ""
                if self.current_file and not Path(self.current_file).exists():
                    source_note = " The original CSV is no longer at its saved path; the autosaved transaction snapshot was restored instead."
                saved_at = str(data.get("saved_at") or "previous exit")
                self.status_var.set(f"Restored autosaved session from {saved_at}.{source_note}")
                return True
            return False
        except Exception as e:
            self.status_var.set(f"Saved session could not be restored: {e}")
            return False

    def _startup_restore(self):
        imported = self._bootstrap_rules_if_present()
        restored = self._restore_session()
        if imported and not restored:
            self.status_var.set(f"Imported {imported} bundled saved rule(s) into this empty profile. Load a bank CSV to continue.")

    def _confirm_profile_change(self) -> bool:
        if not (self.txns or self.receipts):
            return True
        return messagebox.askyesno(
            APP_NAME,
            "Switch company profiles?\n\nThe current statement, allocations, export ticks and view state will be autosaved to this profile and restored when you return."
        )

    def _activate_profile(self, profile_id: str):
        if profile_id == self.active_profile_id:
            self._refresh_profile_ui()
            return
        self._save_session()
        self._persist_profile_settings()
        try:
            self.store.conn.close()
        except Exception:
            pass
        self.profile_manager.set_active(profile_id)
        self.active_profile_id = profile_id
        self.store = Store(self.profile_manager.db_path(profile_id))
        self._load_active_profile_settings()
        self._clear_statement_for_profile_change()
        self._refresh_profile_ui()
        imported = self._bootstrap_rules_if_present()
        restored = self._restore_session()
        name = self.profile_manager.profile_name(profile_id)
        if restored:
            self.status_var.set(f"Switched to profile '{name}' and restored its autosaved session.")
        elif imported:
            self.status_var.set(f"Switched to profile '{name}'. Imported {imported} bundled rule(s); no prior statement session was saved.")
        else:
            self.status_var.set(f"Switched to profile '{name}'. No prior statement session was saved.")

    def delete_profile(self):
        if self.active_profile_id == "default":
            messagebox.showinfo(APP_NAME, "The Default profile contains the original app database and cannot be deleted. You can rename it to the company name instead.")
            return
        name = self.profile_manager.profile_name(self.active_profile_id)
        if not messagebox.askyesno(APP_NAME, f"Delete profile '{name}'?\n\nThis permanently deletes that profile's saved rules, settings, transaction history and autosaved session. This cannot be undone."):
            return
        self._persist_profile_settings()
        try:
            self.store.conn.close()
        except Exception:
            pass
        old_id = self.active_profile_id
        self.profile_manager.delete_profile(old_id)
        self.active_profile_id = self.profile_manager.active_id
        self.store = Store(self.profile_manager.db_path(self.active_profile_id))
        self._load_active_profile_settings()
        self._clear_statement_for_profile_change()
        self._refresh_profile_ui()
        self._bootstrap_rules_if_present()
        restored = self._restore_session()
        target = self.profile_manager.profile_name(self.active_profile_id)
        self.status_var.set(f"Deleted profile '{name}'. Switched to '{target}'" + (" and restored its autosaved session." if restored else "."))

    def _configure_style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("vista" if os.name == "nt" else "clam")
        except tk.TclError:
            pass
        s.configure("Treeview", rowheight=25, font=("Segoe UI", 9))
        s.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        s.configure("Accent.TButton", font=("Segoe UI", 9, "bold"))

    def _tutorial_topic_by_id(self, topic_id: str):
        for topic in TUTORIAL_TOPICS:
            if topic["id"] == topic_id:
                return topic
        return TUTORIAL_TOPICS[0]

    def _tutorial_snapshot(self):
        return tutorial_workspace_snapshot(self.store, self.txns, self.receipts)

    def _tutorial_progress_summary(self, snap):
        if not snap["loaded"]:
            return f"{snap['rules']} saved rule(s) found. No statement is currently loaded."
        return (f"Current statement: {snap['payments']} payments, {snap['receipts']} receipts, "
                f"{snap['assigned']} assigned, {snap['unassigned']} unassigned, "
                f"{snap['ambiguous']} ambiguous, {snap['recurring']} recurring transaction(s).")

    def _maybe_start_tutorial(self):
        if should_auto_start_tutorial(self.store):
            self.start_tutorial(auto=True)

    def start_tutorial(self, auto: bool = False):
        old = getattr(self, "tutorial_window", None)
        if old is not None:
            try:
                if old.winfo_exists():
                    old.lift(); old.focus_force(); return
            except Exception:
                pass
        self._tutorial_previous_mode = getattr(self, "ui_mode", DEFAULT_UI_MODE)
        self._tutorial_auto = bool(auto)
        self._tutorial_snapshot_data = self._tutorial_snapshot()
        self._tutorial_topic_ids = adaptive_tutorial_topic_ids(self._tutorial_snapshot_data)
        self._tutorial_index = 0
        self._tutorial_search_mode = False
        if getattr(self, "ui_mode", DEFAULT_UI_MODE) != "modern":
            self._apply_ui_mode("modern", initial=True)

        win = tk.Toplevel(self)
        self.tutorial_window = win
        win.title(f"{APP_NAME} - Tutorial & Help")
        win.minsize(820, 560)
        win.configure(bg="#f4f7fb")
        win.transient(self)
        try:
            self.update_idletasks()
            width, height = 940, 650
            x = max(0, self.winfo_rootx() + (self.winfo_width() - width) // 2)
            y = max(0, self.winfo_rooty() + (self.winfo_height() - height) // 2)
            win.geometry(f"{width}x{height}+{x}+{y}")
        except Exception:
            win.geometry("940x650")

        header = tk.Frame(win, bg="#0f2744", padx=22, pady=16)
        header.pack(fill="x")
        tk.Label(header, text="TUTORIAL & SEARCHABLE HELP", bg="#0f2744", fg="#9dd8cb", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        tk.Label(header, text="Learn what matters next - or search for a problem", bg="#0f2744", fg="#ffffff", font=("Segoe UI", 18, "bold")).pack(anchor="w", pady=(3, 0))

        searchbar = tk.Frame(win, bg="#ffffff", padx=18, pady=12, highlightthickness=1, highlightbackground="#e2e8f0")
        searchbar.pack(fill="x", padx=18, pady=(16, 8))
        tk.Label(searchbar, text="Search help", bg="#ffffff", fg="#334155", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 8))
        self.tutorial_search_var = tk.StringVar()
        entry = ttk.Entry(searchbar, textvariable=self.tutorial_search_var)
        entry.pack(side="left", fill="x", expand=True)
        entry.bind("<KeyRelease>", lambda e: self._tutorial_search())
        entry.bind("<Return>", lambda e: self._tutorial_open_first_search_result())
        ttk.Button(searchbar, text="Clear search", command=self._tutorial_clear_search, style="Modern.TButton").pack(side="left", padx=(8, 0))

        body = tk.Frame(win, bg="#f4f7fb", padx=18, pady=6)
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg="#ffffff", width=255, highlightthickness=1, highlightbackground="#e2e8f0")
        left.pack(side="left", fill="y", padx=(0, 10))
        left.pack_propagate(False)
        tk.Label(left, text="Recommended path / search results", bg="#ffffff", fg="#64748b", font=("Segoe UI", 8, "bold"), anchor="w", wraplength=220, justify="left").pack(fill="x", padx=12, pady=(12, 7))
        self.tutorial_list = tk.Listbox(left, bd=0, highlightthickness=0, activestyle="none", font=("Segoe UI", 9), selectbackground="#dbeafe", selectforeground="#1d4ed8")
        self.tutorial_list.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tutorial_list.bind("<<ListboxSelect>>", lambda e: self._tutorial_list_selected())
        self.tutorial_rescan_button = ttk.Button(left, text="Re-scan my progress", command=self._tutorial_rescan, style="Modern.TButton")
        self.tutorial_rescan_button.pack(fill="x", padx=10, pady=(0, 10))

        right = tk.Frame(body, bg="#ffffff", highlightthickness=1, highlightbackground="#e2e8f0")
        right.pack(side="left", fill="both", expand=True)
        top = tk.Frame(right, bg="#ffffff", padx=18, pady=14)
        top.pack(fill="x")
        self.tutorial_step_var = tk.StringVar()
        self.tutorial_title_var = tk.StringVar()
        self.tutorial_progress_var = tk.StringVar(value=self._tutorial_progress_summary(self._tutorial_snapshot_data))
        tk.Label(top, textvariable=self.tutorial_step_var, bg="#ffffff", fg="#2563eb", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        tk.Label(top, textvariable=self.tutorial_title_var, bg="#ffffff", fg="#172033", font=("Segoe UI", 16, "bold"), wraplength=580, justify="left").pack(anchor="w", pady=(3, 6))
        tk.Label(top, textvariable=self.tutorial_progress_var, bg="#eef6ff", fg="#334155", font=("Segoe UI", 8), wraplength=590, justify="left", padx=10, pady=7).pack(fill="x")
        self.tutorial_body_text = tk.Text(right, wrap="word", bd=0, bg="#ffffff", fg="#334155", font=("Segoe UI", 10), padx=18, pady=10, spacing1=3, spacing3=6)
        self.tutorial_body_text.pack(fill="both", expand=True)
        self.tutorial_body_text.configure(state="disabled")

        footer = tk.Frame(win, bg="#f4f7fb", padx=18, pady=12)
        footer.pack(fill="x")
        self.tutorial_skip_button = ttk.Button(footer, text="Skip tutorial", command=self._tutorial_skip, style="Modern.TButton")
        self.tutorial_skip_button.pack(side="left")
        ttk.Button(footer, text="Close", command=self._tutorial_close, style="Modern.TButton").pack(side="left", padx=6)
        self.tutorial_back_button = ttk.Button(footer, text="Back", command=lambda: self._tutorial_move(-1), style="Modern.TButton")
        self.tutorial_back_button.pack(side="right", padx=(6, 0))
        self.tutorial_next_button = ttk.Button(footer, text="Next", command=lambda: self._tutorial_move(1), style="Accent.TButton")
        self.tutorial_next_button.pack(side="right")

        win.protocol("WM_DELETE_WINDOW", self._tutorial_close)
        self._tutorial_fill_list()
        self._tutorial_show_current()
        entry.focus_set() if not auto else None

    def _tutorial_current_topics(self):
        if self._tutorial_search_mode:
            return getattr(self, "_tutorial_search_results", [])
        return [self._tutorial_topic_by_id(x) for x in self._tutorial_topic_ids]

    def _tutorial_fill_list(self):
        topics = self._tutorial_current_topics()
        self.tutorial_list.delete(0, "end")
        for idx, topic in enumerate(topics):
            prefix = "" if self._tutorial_search_mode else f"{idx + 1}. "
            self.tutorial_list.insert("end", prefix + topic["title"])
        if topics:
            self._tutorial_index = max(0, min(self._tutorial_index, len(topics) - 1))
            self.tutorial_list.selection_clear(0, "end")
            self.tutorial_list.selection_set(self._tutorial_index)
            self.tutorial_list.see(self._tutorial_index)

    def _tutorial_show_current(self):
        topics = self._tutorial_current_topics()
        if not topics:
            self.tutorial_step_var.set("No matching help topic")
            self.tutorial_title_var.set("Try a different search")
            body = "Search using a short description of the problem, for example: orange transaction, wrong GL, VAT, recurring missing, receipt negative, export, autosave, or company profile."
            self.tutorial_back_button.configure(state="disabled")
            self.tutorial_next_button.configure(state="disabled")
        else:
            self._tutorial_index = max(0, min(self._tutorial_index, len(topics) - 1))
            topic = topics[self._tutorial_index]
            if self._tutorial_search_mode:
                self.tutorial_step_var.set(f"Search result {self._tutorial_index + 1} of {len(topics)}")
            else:
                self.tutorial_step_var.set(f"Recommended step {self._tutorial_index + 1} of {len(topics)}")
            self.tutorial_title_var.set(topic["title"])
            body = topic["body"]
            self.tutorial_back_button.configure(state="normal" if self._tutorial_index > 0 else "disabled")
            if self._tutorial_search_mode:
                self.tutorial_next_button.configure(text="Next result", state="normal" if self._tutorial_index < len(topics) - 1 else "disabled")
            else:
                is_last = self._tutorial_index == len(topics) - 1
                self.tutorial_next_button.configure(text="Finish" if is_last else "Next", state="normal")
            try:
                if topic.get("page"):
                    self._navigate_modern(topic["page"])
            except Exception:
                pass
        self.tutorial_body_text.configure(state="normal")
        self.tutorial_body_text.delete("1.0", "end")
        self.tutorial_body_text.insert("1.0", body)
        self.tutorial_body_text.configure(state="disabled")

    def _tutorial_list_selected(self):
        sel = self.tutorial_list.curselection()
        if not sel:
            return
        self._tutorial_index = int(sel[0])
        self._tutorial_show_current()

    def _tutorial_move(self, delta: int):
        topics = self._tutorial_current_topics()
        if not topics:
            return
        if not self._tutorial_search_mode and delta > 0 and self._tutorial_index >= len(topics) - 1:
            self._tutorial_finish(); return
        new_idx = self._tutorial_index + delta
        if 0 <= new_idx < len(topics):
            self._tutorial_index = new_idx
            self.tutorial_list.selection_clear(0, "end")
            self.tutorial_list.selection_set(new_idx)
            self.tutorial_list.see(new_idx)
            self._tutorial_show_current()

    def _tutorial_search(self):
        query = self.tutorial_search_var.get().strip()
        if not query:
            self._tutorial_clear_search(); return
        self._tutorial_search_mode = True
        self._tutorial_search_results = search_tutorial_topics(query)
        self._tutorial_index = 0
        self._tutorial_fill_list()
        self._tutorial_show_current()

    def _tutorial_open_first_search_result(self):
        if self.tutorial_search_var.get().strip():
            self._tutorial_search()

    def _tutorial_clear_search(self):
        self.tutorial_search_var.set("")
        self._tutorial_search_mode = False
        self._tutorial_index = 0
        self._tutorial_fill_list()
        self._tutorial_show_current()

    def _tutorial_rescan(self):
        self._tutorial_snapshot_data = self._tutorial_snapshot()
        self._tutorial_topic_ids = adaptive_tutorial_topic_ids(self._tutorial_snapshot_data)
        self.tutorial_progress_var.set(self._tutorial_progress_summary(self._tutorial_snapshot_data))
        self._tutorial_search_mode = False
        self.tutorial_search_var.set("")
        self._tutorial_index = 0
        self._tutorial_fill_list()
        self._tutorial_show_current()
        self.status_var.set("Tutorial re-scanned the active profile and tailored the recommended path to the work currently completed.")

    def _tutorial_record_state(self, state: str):
        try:
            self.store.set_setting(TUTORIAL_SETTING_KEY, state)
        except Exception:
            pass

    def _tutorial_skip(self):
        self._tutorial_record_state("skipped")
        self.status_var.set("Tutorial skipped. You can run Tutorial & Help from the menu at any time.")
        self._tutorial_close()

    def _tutorial_finish(self):
        self._tutorial_record_state("completed")
        self.status_var.set("Tutorial completed. Tutorial & Help remains available from the menu whenever you need it.")
        self._tutorial_close()

    def _tutorial_close(self):
        win = getattr(self, "tutorial_window", None)
        if win is not None:
            try:
                win.destroy()
            except Exception:
                pass
        self.tutorial_window = None
        previous = getattr(self, "_tutorial_previous_mode", "modern")
        if previous == "classic" and getattr(self, "ui_mode", "modern") != "classic":
            self._apply_ui_mode("classic", initial=True)

    def _configure_modern_style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        self.configure(bg="#f4f7fb")
        s.configure("Treeview", rowheight=30, font=("Segoe UI", 9), background="#ffffff", fieldbackground="#ffffff", foreground="#253247")
        s.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), padding=(7, 8), background="#eef3f8", foreground="#334155")
        s.configure("Accent.TButton", font=("Segoe UI", 9, "bold"), padding=(10, 7), background="#2563eb", foreground="#ffffff")
        s.map("Accent.TButton", background=[("active", "#1d4ed8"), ("pressed", "#1e40af")], foreground=[("disabled", "#cbd5e1"), ("!disabled", "#ffffff")])
        s.configure("Modern.TButton", font=("Segoe UI", 9), padding=(9, 6))
        s.configure("ModernHeader.TFrame", background="#ffffff")
        s.configure("ModernPage.TFrame", background="#f4f7fb")
        s.configure("ModernCard.TFrame", background="#ffffff", relief="solid", borderwidth=1)
        s.configure("ModernTitle.TLabel", background="#ffffff", foreground="#172033", font=("Segoe UI", 18, "bold"))
        s.configure("ModernSubtitle.TLabel", background="#ffffff", foreground="#64748b", font=("Segoe UI", 9))
        s.configure("DashboardTitle.TLabel", background="#f4f7fb", foreground="#172033", font=("Segoe UI", 22, "bold"))
        s.configure("DashboardText.TLabel", background="#f4f7fb", foreground="#64748b", font=("Segoe UI", 10))
        s.configure("CardLabel.TLabel", background="#ffffff", foreground="#64748b", font=("Segoe UI", 9))
        s.configure("CardValue.TLabel", background="#ffffff", foreground="#172033", font=("Segoe UI", 22, "bold"))
        s.configure("CardNote.TLabel", background="#ffffff", foreground="#64748b", font=("Segoe UI", 8))
        s.configure("GuideTitle.TLabel", background="#ffffff", foreground="#172033", font=("Segoe UI", 12, "bold"))
        s.configure("GuideText.TLabel", background="#ffffff", foreground="#475569", font=("Segoe UI", 9))
        s.configure("StatusBar.TFrame", background="#ffffff")

    def _list(self, direction: str) -> List[Transaction]:
        return self.receipts if direction == "RECEIPT" else self.txns

    @staticmethod
    def _noun(direction: str, plural: bool = False) -> str:
        if direction == "RECEIPT":
            return "receipts" if plural else "receipt"
        return "payments" if plural else "payment"

    def _build_profile_controls(self, parent, modern: bool = False):
        box = ttk.Frame(parent, style="ModernHeader.TFrame" if modern else "TFrame")
        ttk.Label(box, text="Company" if modern else "Company profile:", style="ModernSubtitle.TLabel" if modern else "TLabel").pack(side="left", padx=(0, 6))
        combo = ttk.Combobox(box, textvariable=self.profile_var, values=self.profile_manager.names(), state="readonly", width=22)
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", self.select_profile)
        ttk.Button(box, text="New", command=self.new_profile, style="Modern.TButton" if modern else "TButton").pack(side="left", padx=(6, 2))
        ttk.Button(box, text="Rename", command=self.rename_profile, style="Modern.TButton" if modern else "TButton").pack(side="left", padx=2)
        ttk.Button(box, text="Delete", command=self.delete_profile, style="Modern.TButton" if modern else "TButton").pack(side="left", padx=2)
        return box, combo

    def _build_dashboard(self):
        self.dashboard_vars = {}
        outer = self.dashboard_frame
        heading = ttk.Frame(outer, style="ModernPage.TFrame", padding=(20, 18, 20, 8))
        heading.pack(fill="x")
        ttk.Label(heading, text="Accounting workspace", style="DashboardTitle.TLabel").pack(anchor="w")
        ttk.Label(heading, text="A guided overview of the current statement and the next action to take.", style="DashboardText.TLabel").pack(anchor="w", pady=(3, 0))

        cards = ttk.Frame(outer, style="ModernPage.TFrame", padding=(20, 8, 20, 8))
        cards.pack(fill="x")
        for col in range(5):
            cards.grid_columnconfigure(col, weight=1, uniform="dashboard_card")

        card_specs = [
            ("payments", "Payments", "Money out"),
            ("receipts", "Receipts", "Money in"),
            ("ready", "Ready", "Selected + allocated"),
            ("attention", "Needs attention", "Unassigned / ambiguous"),
            ("rules", "Saved rules", "Automation available"),
        ]
        for col, (key, title, note) in enumerate(card_specs):
            frame = ttk.Frame(cards, style="ModernCard.TFrame", padding=(14, 12))
            frame.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else 5, 0 if col == 4 else 5))
            var = tk.StringVar(value="0")
            self.dashboard_vars[key] = var
            ttk.Label(frame, text=title, style="CardLabel.TLabel").pack(anchor="w")
            ttk.Label(frame, textvariable=var, style="CardValue.TLabel").pack(anchor="w", pady=(3, 0))
            ttk.Label(frame, text=note, style="CardNote.TLabel").pack(anchor="w", pady=(2, 0))

        body = ttk.Frame(outer, style="ModernPage.TFrame", padding=(20, 8, 20, 20))
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure(0, weight=3)
        body.grid_columnconfigure(1, weight=2)
        body.grid_rowconfigure(0, weight=1)

        guide = ttk.Frame(body, style="ModernCard.TFrame", padding=(18, 16))
        guide.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        ttk.Label(guide, text="Recommended workflow", style="GuideTitle.TLabel").pack(anchor="w")
        ttk.Label(guide, text="Follow these steps from top to bottom. You can return here at any time.", style="GuideText.TLabel").pack(anchor="w", pady=(2, 10))
        steps = [
            ("1", "Load a bank statement", "Choose the CSV exported by your bank."),
            ("2", "Review allocations", "Resolve orange/unassigned or ambiguous rows. Saved rules can automate future statements."),
            ("3", "Choose what to export", "Add Auto-Allocated and Manual Allocations; the selections are additive."),
            ("4", "Validate", "Run the pre-import checks before creating the Pastel files."),
            ("5", "Export to Pastel", "Import Payments on the Payments side and Receipts on the Receipts side."),
        ]
        for number, title, note in steps:
            row = ttk.Frame(guide, style="ModernCard.TFrame")
            row.pack(fill="x", pady=4)
            badge = tk.Label(row, text=number, bg="#dbeafe", fg="#1d4ed8", font=("Segoe UI", 9, "bold"), width=3, pady=3)
            badge.pack(side="left", padx=(0, 9))
            text = ttk.Frame(row, style="ModernCard.TFrame")
            text.pack(side="left", fill="x", expand=True)
            ttk.Label(text, text=title, style="GuideTitle.TLabel").pack(anchor="w")
            ttk.Label(text, text=note, style="GuideText.TLabel", wraplength=560).pack(anchor="w")

        quick = ttk.Frame(body, style="ModernCard.TFrame", padding=(18, 16))
        quick.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        ttk.Label(quick, text="What should I do next?", style="GuideTitle.TLabel").pack(anchor="w")
        self.dashboard_vars["next_step"] = tk.StringVar(value="Load a bank CSV to begin.")
        ttk.Label(quick, textvariable=self.dashboard_vars["next_step"], style="GuideText.TLabel", wraplength=360).pack(anchor="w", pady=(4, 12))
        ttk.Button(quick, text="Load bank CSV...", command=self.load_csv, style="Accent.TButton").pack(fill="x", pady=3)
        ttk.Button(quick, text="Review Payments", command=lambda: self._navigate_modern("payments"), style="Modern.TButton").pack(fill="x", pady=3)
        ttk.Button(quick, text="Review Receipts", command=lambda: self._navigate_modern("receipts"), style="Modern.TButton").pack(fill="x", pady=3)
        ttk.Button(quick, text="Check selected for errors", command=self.show_validation, style="Modern.TButton").pack(fill="x", pady=(12, 3))
        ttk.Button(quick, text="Export selected to Pastel...", command=self.export_files, style="Accent.TButton").pack(fill="x", pady=3)
        ttk.Button(quick, text="Tutorial & searchable help", command=self.start_tutorial, style="Modern.TButton").pack(fill="x", pady=(10, 3))
        ttk.Separator(quick).pack(fill="x", pady=12)
        self.dashboard_vars["statement"] = tk.StringVar(value="No statement loaded")
        ttk.Label(quick, text="Current statement", style="CardLabel.TLabel").pack(anchor="w")
        ttk.Label(quick, textvariable=self.dashboard_vars["statement"], style="GuideText.TLabel", wraplength=350).pack(anchor="w", pady=(2, 0))

    def _refresh_dashboard(self):
        if not hasattr(self, "dashboard_vars"):
            return
        payments = len(self.txns)
        receipts = len(self.receipts)
        selected = [t for t in (self.txns + self.receipts) if t.include]
        ready = sum(1 for t in selected if t.account and not t.ambiguous)
        attention = sum(1 for t in selected if (not t.account) or t.ambiguous)
        recurring = sum(1 for t in (self.txns + self.receipts) if t.recurring_count >= 2)
        try:
            rules = len(self.store.all_rules())
        except Exception:
            rules = 0
        for key, value in (("payments", payments), ("receipts", receipts), ("ready", ready), ("attention", attention), ("rules", rules)):
            if key in self.dashboard_vars:
                self.dashboard_vars[key].set(str(value))
        if "statement" in self.dashboard_vars:
            if self.current_file:
                self.dashboard_vars["statement"].set(f"{Path(self.current_file).name}  |  {payments + receipts} transactions  |  {recurring} recurring")
            else:
                self.dashboard_vars["statement"].set("No statement loaded")
        if "next_step" in self.dashboard_vars:
            if not (self.txns or self.receipts):
                text = "Start by loading a bank CSV. The app will separate Payments and Receipts automatically."
            elif attention:
                text = f"{attention} selected transaction(s) still need attention. Review orange/unassigned or ambiguous rows before export."
            elif not selected:
                text = "Nothing is selected for export. Use the additive Auto and Manual quick-select buttons on Payments / Receipts."
            else:
                text = f"{ready} selected transaction(s) are allocated. Run validation, then export when the checks are clear."
            self.dashboard_vars["next_step"].set(text)

    def _set_modern_page_header(self, title: str, subtitle: str):
        self.page_title_var.set(title)
        self.page_subtitle_var.set(subtitle)

    def _set_nav_active(self, key: str):
        for nav_key, button in getattr(self, "nav_buttons", {}).items():
            active = nav_key == key
            button.configure(
                bg="#e8f0ff" if active else "#ffffff",
                fg="#1d4ed8" if active else "#334155",
                activebackground="#e8f0ff" if active else "#f1f5f9",
                activeforeground="#1d4ed8" if active else "#172033",
                font=("Segoe UI", 10, "bold" if active else "normal"),
            )

    def _show_modern_dashboard(self):
        self.current_modern_page = "dashboard"
        self.notebook.pack_forget()
        self.dashboard_frame.pack(fill="both", expand=True)
        self._set_modern_page_header("Overview", "Your statement, allocations and next steps at a glance.")
        self._set_nav_active("dashboard")
        self._refresh_dashboard()

    def _show_modern_notebook(self, tab, key: str, title: str, subtitle: str):
        self.current_modern_page = key
        self.dashboard_frame.pack_forget()
        if not self.notebook.winfo_manager():
            self.notebook.pack(fill="both", expand=True)
        self.notebook.select(tab)
        self._set_modern_page_header(title, subtitle)
        self._set_nav_active(key)

    def _navigate_modern(self, key: str):
        if self.ui_mode != "modern":
            self.ui_mode = "modern"
            self._apply_ui_mode("modern")
        if key == "dashboard":
            self._show_modern_dashboard(); return
        pages = {
            "payments": (self.pay_tab, "Payments", "Allocate and select money leaving the bank."),
            "receipts": (self.receipt_tab, "Receipts", "Allocate and select money entering the bank."),
            "recurring_payments": (self.recurring_pay_tab, "Recurring Payments", "Review repeated outgoing transactions while keeping each child transaction independently controllable."),
            "recurring_receipts": (self.recurring_receipt_tab, "Recurring Receipts", "Review repeated incoming transactions and their individual allocations."),
            "rules": (self.rule_tab, "Saved Rules", "Manage the rules that automate future allocations."),
            "settings": (self.settings_tab, "Settings", "Configure VAT, fiscal periods and the Pastel cash-book bank GL for this company profile."),
        }
        tab, title, subtitle = pages.get(key, pages["payments"])
        self._show_modern_notebook(tab, key, title, subtitle)

    def toggle_ui_mode(self):
        self._apply_ui_mode("classic" if self.ui_mode == "modern" else "modern")

    def _apply_ui_mode(self, mode: str = None, initial: bool = False):
        chosen = (mode or getattr(self, "ui_mode", DEFAULT_UI_MODE) or DEFAULT_UI_MODE).lower()
        if chosen not in UI_MODES:
            chosen = DEFAULT_UI_MODE
        self.ui_mode = chosen
        try:
            self.store.set_setting("ui_mode", chosen)
        except Exception:
            pass
        style = ttk.Style(self)
        if chosen == "classic":
            try:
                style.theme_use("vista" if os.name == "nt" else "clam")
            except tk.TclError:
                pass
            if hasattr(self, "_classic_tab_layout"):
                try:
                    style.layout("TNotebook.Tab", self._classic_tab_layout)
                except tk.TclError:
                    pass
            self.modern_header.pack_forget()
            self.sidebar.pack_forget()
            self.modern_page_header.pack_forget()
            self.dashboard_frame.pack_forget()
            if not self.classic_toolbar.winfo_manager():
                self.classic_toolbar.pack(fill="x", before=self.main_shell)
            if not self.notebook.winfo_manager():
                self.notebook.pack(fill="both", expand=True)
            self.classic_mode_button.configure(text="Modern UI")
            self.status_var.set("Classic UI enabled. Your data and accounting logic are unchanged.")
        else:
            self._configure_modern_style()
            try:
                style.layout("TNotebook.Tab", [])
            except tk.TclError:
                pass
            self.classic_toolbar.pack_forget()
            if not self.modern_header.winfo_manager():
                self.modern_header.pack(fill="x", before=self.main_shell)
            if not self.sidebar.winfo_manager():
                self.sidebar.pack(side="left", fill="y", before=self.content_shell)
            if not self.modern_page_header.winfo_manager():
                self.modern_page_header.pack(fill="x")
            self.modern_mode_button.configure(text="Classic UI")
            page = getattr(self, "current_modern_page", "dashboard")
            if page == "dashboard":
                self._show_modern_dashboard()
            else:
                self._navigate_modern(page)
            if not initial:
                self.status_var.set("Modern UI enabled. Use the Overview page for guided next steps, or switch back to Classic UI at any time.")

    def _restore_modern_view(self, active_tab: str, saved_page: str = ""):
        if getattr(self, "ui_mode", DEFAULT_UI_MODE) != "modern":
            return
        if saved_page == "dashboard":
            self._show_modern_dashboard(); return
        by_tab = {
            "Payments": "payments",
            "Receipts / Money In": "receipts",
            "Recurring Payments": "recurring_payments",
            "Recurring Receipts": "recurring_receipts",
            "Saved Rules": "rules",
            "Settings": "settings",
        }
        self._navigate_modern(saved_page if saved_page in {"payments", "receipts", "recurring_payments", "recurring_receipts", "rules", "settings"} else by_tab.get(active_tab, "dashboard"))

    def _build(self):
        self.ui_mode = (self.store.get_setting("ui_mode", DEFAULT_UI_MODE) or DEFAULT_UI_MODE).strip().lower()
        if self.ui_mode not in UI_MODES:
            self.ui_mode = DEFAULT_UI_MODE
        self.current_modern_page = "dashboard"
        self.nav_buttons = {}

        # Classic toolbar: deliberately keeps the previous layout available.
        self.classic_toolbar = ttk.Frame(self, padding=(12, 10))
        ttk.Label(self.classic_toolbar, text=APP_NAME, font=("Segoe UI", 18, "bold")).pack(side="left")
        classic_profile_box, self.profile_combo_classic = self._build_profile_controls(self.classic_toolbar, modern=False)
        classic_profile_box.pack(side="left", padx=(18, 8))
        ttk.Button(self.classic_toolbar, text="Load bank CSV...", command=self.load_csv, style="Accent.TButton").pack(side="left", padx=8)
        ttk.Button(self.classic_toolbar, text="Apply saved rules", command=self.reapply_rules).pack(side="left")
        self.classic_mode_button = ttk.Button(self.classic_toolbar, text="Modern UI", command=self.toggle_ui_mode)
        self.classic_mode_button.pack(side="right", padx=(4, 0))
        ttk.Button(self.classic_toolbar, text="Tutorial & Help", command=self.start_tutorial).pack(side="right", padx=4)
        ttk.Button(self.classic_toolbar, text="Check selected for errors", command=self.show_validation).pack(side="right")
        ttk.Button(self.classic_toolbar, text="Export selected to Pastel...", command=self.export_files, style="Accent.TButton").pack(side="right", padx=8)

        # Modern header: focused primary actions and a compact company switcher.
        self.modern_header = ttk.Frame(self, style="ModernHeader.TFrame", padding=(18, 11))
        title_box = ttk.Frame(self.modern_header, style="ModernHeader.TFrame")
        title_box.pack(side="left")
        ttk.Label(title_box, text=APP_NAME, style="ModernTitle.TLabel").pack(anchor="w")
        ttk.Label(title_box, text=f"v{APP_VERSION} Personal workspace", style="ModernSubtitle.TLabel").pack(anchor="w")
        modern_profile_box, self.profile_combo_modern = self._build_profile_controls(self.modern_header, modern=True)
        modern_profile_box.pack(side="left", padx=(24, 0))
        self.profile_combo = self.profile_combo_modern
        self.modern_mode_button = ttk.Button(self.modern_header, text="Classic UI", command=self.toggle_ui_mode, style="Modern.TButton")
        self.modern_mode_button.pack(side="right", padx=(6, 0))
        ttk.Button(self.modern_header, text="Export to Pastel", command=self.export_files, style="Accent.TButton").pack(side="right", padx=6)
        ttk.Button(self.modern_header, text="Validate", command=self.show_validation, style="Modern.TButton").pack(side="right", padx=4)
        ttk.Button(self.modern_header, text="Load statement", command=self.load_csv, style="Accent.TButton").pack(side="right", padx=6)

        self.main_shell = ttk.Frame(self, style="ModernPage.TFrame")
        self.main_shell.pack(fill="both", expand=True)
        self.sidebar = tk.Frame(self.main_shell, bg="#ffffff", width=220, highlightthickness=1, highlightbackground="#e2e8f0")
        self.sidebar.pack_propagate(False)
        tk.Label(self.sidebar, text="WORKSPACE", bg="#ffffff", fg="#94a3b8", font=("Segoe UI", 8, "bold"), anchor="w").pack(fill="x", padx=18, pady=(20, 8))
        nav = [
            ("dashboard", "Overview"),
            ("payments", "Payments"),
            ("receipts", "Receipts / Money In"),
            ("recurring_payments", "Recurring Payments"),
            ("recurring_receipts", "Recurring Receipts"),
            ("rules", "Saved Rules"),
            ("settings", "Settings"),
        ]
        for key, label in nav:
            button = tk.Button(
                self.sidebar, text=label, command=lambda k=key: self._navigate_modern(k), anchor="w",
                bd=0, relief="flat", bg="#ffffff", fg="#334155", activebackground="#f1f5f9", activeforeground="#172033",
                padx=18, pady=10, font=("Segoe UI", 10), cursor="hand2"
            )
            button.pack(fill="x", padx=8, pady=1)
            self.nav_buttons[key] = button
        tk.Frame(self.sidebar, bg="#e2e8f0", height=1).pack(fill="x", padx=16, pady=(18, 10))
        tutorial_btn = tk.Button(
            self.sidebar, text="Tutorial & Help", command=self.start_tutorial, anchor="w", bd=0, relief="flat",
            bg="#ffffff", fg="#0f766e", activebackground="#ecfdf5", activeforeground="#0f766e",
            padx=18, pady=10, font=("Segoe UI", 10, "bold"), cursor="hand2"
        )
        tutorial_btn.pack(fill="x", padx=8, pady=(0, 8))
        tk.Frame(self.sidebar, bg="#e2e8f0", height=1).pack(fill="x", padx=16, pady=(0, 12))
        tk.Label(self.sidebar, text="ACTIVE COMPANY", bg="#ffffff", fg="#94a3b8", font=("Segoe UI", 8, "bold"), anchor="w").pack(fill="x", padx=18)
        tk.Label(self.sidebar, textvariable=self.profile_var, bg="#ffffff", fg="#172033", font=("Segoe UI", 10, "bold"), anchor="w", wraplength=180, justify="left").pack(fill="x", padx=18, pady=(4, 0))
        tk.Label(self.sidebar, text="Modern and Classic views use the same company data.", bg="#ffffff", fg="#64748b", font=("Segoe UI", 8), anchor="w", wraplength=180, justify="left").pack(fill="x", padx=18, pady=(5, 0))

        self.content_shell = ttk.Frame(self.main_shell, style="ModernPage.TFrame")
        self.content_shell.pack(side="left", fill="both", expand=True)
        self.modern_page_header = ttk.Frame(self.content_shell, style="ModernHeader.TFrame", padding=(18, 12))
        self.page_title_var = tk.StringVar(value="Overview")
        self.page_subtitle_var = tk.StringVar(value="Your statement, allocations and next steps at a glance.")
        ttk.Label(self.modern_page_header, textvariable=self.page_title_var, style="ModernTitle.TLabel").pack(anchor="w")
        ttk.Label(self.modern_page_header, textvariable=self.page_subtitle_var, style="ModernSubtitle.TLabel").pack(anchor="w", pady=(2, 0))

        self.dashboard_frame = ttk.Frame(self.content_shell, style="ModernPage.TFrame")
        self._build_dashboard()

        self.notebook = ttk.Notebook(self.content_shell)
        try:
            self._classic_tab_layout = ttk.Style(self).layout("TNotebook.Tab")
        except tk.TclError:
            self._classic_tab_layout = []
        self.pay_tab = ttk.Frame(self.notebook)
        self.receipt_tab = ttk.Frame(self.notebook)
        self.recurring_pay_tab = ttk.Frame(self.notebook)
        self.recurring_receipt_tab = ttk.Frame(self.notebook)
        self.rule_tab = ttk.Frame(self.notebook)
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.pay_tab, text="Payments")
        self.notebook.add(self.receipt_tab, text="Receipts / Money In")
        self.notebook.add(self.recurring_pay_tab, text="Recurring Payments")
        self.notebook.add(self.recurring_receipt_tab, text="Recurring Receipts")
        self.notebook.add(self.rule_tab, text="Saved Rules")
        self.notebook.add(self.settings_tab, text="Settings")

        self._build_transaction_tab(self.pay_tab, "PAYMENT")
        self._build_transaction_tab(self.receipt_tab, "RECEIPT")
        self._build_recurring_tab(self.recurring_pay_tab, "PAYMENT")
        self._build_recurring_tab(self.recurring_receipt_tab, "RECEIPT")
        self._build_rules()
        self._build_settings()

        bar = ttk.Frame(self, style="StatusBar.TFrame", padding=(12, 6, 12, 8))
        bar.pack(fill="x")
        ttk.Label(bar, textvariable=self.status_var).pack(side="left")
        ttk.Label(bar, textvariable=self.profile_db_var, foreground="#64748b").pack(side="right")

        self._apply_ui_mode(self.ui_mode, initial=True)
        self._refresh_dashboard()

    def _build_transaction_tab(self, tab, direction: str):
        noun_plural = self._noun(direction, True)
        controls = ttk.Frame(tab, padding=8); controls.pack(fill="x")

        filters = ttk.Frame(controls); filters.pack(fill="x", pady=(0, 6))
        ttk.Label(filters, text="Find:").pack(side="left")
        e = ttk.Entry(filters, textvariable=self.search_vars[direction], width=20)
        e.pack(side="left", padx=(5, 12)); e.bind("<KeyRelease>", lambda e, d=direction: self.refresh_transaction_tree(d))
        ttk.Label(filters, text="Show:").pack(side="left")
        flt = ttk.Combobox(
            filters, textvariable=self.filter_vars[direction],
            values=["All", "Recurring", "Unassigned", "Amount review", "Ambiguous", "Assigned", "Auto-allocated", "Corrected", "VAT", "No VAT", "Selected for export", "Not selected"],
            state="readonly", width=20
        )
        flt.pack(side="left", padx=(5, 12)); flt.bind("<<ComboboxSelected>>", lambda e, d=direction: self.refresh_transaction_tree(d))

        ttk.Label(filters, text="Repeat description:").pack(side="left")
        combo = ttk.Combobox(
            filters, textvariable=self.repeat_vars[direction],
            values=["— Select repeat description —", "All repeat descriptions"],
            state="readonly", width=28
        )
        combo.pack(side="left", padx=(5, 6)); combo.bind("<<ComboboxSelected>>", lambda e, d=direction: self._repeat_description_selected(d))
        self.repeat_combos[direction] = combo
        ttk.Button(filters, text="Clear", command=lambda d=direction: self.clear_repeat_description(d)).pack(side="left", padx=(0, 12))

        ttk.Label(filters, text="Sort date:").pack(side="left")
        sort = ttk.Combobox(filters, textvariable=self.sort_vars[direction], values=["Oldest first", "Newest first"], state="readonly", width=12)
        sort.pack(side="left", padx=(5, 0)); sort.bind("<<ComboboxSelected>>", lambda e, d=direction: self.refresh_transaction_tree(d))

        actions = ttk.LabelFrame(controls, text="Allocation tools"); actions.pack(fill="x", pady=(2, 4))
        help_action(actions, "Save rule from selected", lambda d=direction: self.assign_rule_selected(d), "Create or update a saved rule from the selected transaction. Matching transactions can then be allocated automatically.")
        help_action(actions, "Assign once", lambda d=direction: self.manual_assign_selected(d), "Allocate only the selected transaction in this statement. This does not create or change a saved rule.")
        help_action(actions, "Correct auto-allocation", lambda d=direction: self.correct_auto_allocation_selected(d), "Fix an automatically allocated transaction. You can apply the correction only to this statement or update the saved rule.")
        help_action(actions, "VAT / No VAT", lambda d=direction: self.toggle_vat_selected(d), "Toggle VAT for the selected transaction(s) in this statement.")
        help_action(actions, "Clear assignment", lambda d=direction: self.clear_assignment_selected(d), "Remove the current allocation from the selected transaction(s) in this statement.", padx=(12, 3))
        help_action(actions, "Reset to saved rule", lambda d=direction: self.reset_selected_to_rule(d), "Discard statement-only changes and reapply the matching saved allocation rule.")
        recurring_tab = self.recurring_receipt_tab if direction == "RECEIPT" else self.recurring_pay_tab
        help_action(actions, f"Manage recurring {noun_plural}…", lambda t=recurring_tab: self.notebook.select(t), "Open the recurring transactions screen where each recurring identity can be reviewed or allocated separately.", side="right")

        actions2 = ttk.LabelFrame(controls, text="Export selection"); actions2.pack(fill="x", pady=(4,0))
        ttk.Label(actions2, text="Quick-select buttons ADD matching rows to your current ticks. Use Clear All to start over.", foreground="#555555").pack(anchor="w", padx=6, pady=(3, 1))
        selection_row = ttk.Frame(actions2); selection_row.pack(fill="x", padx=3, pady=(0, 4))
        help_action(selection_row, "Toggle selected", lambda d=direction: self.toggle_include_selected(d), "Toggle the export tick only for the transaction rows you currently selected in the table.")
        help_action(selection_row, "Add Auto-Allocated", lambda d=direction: self.select_auto_allocated_export(d), "Add all successfully auto-allocated transactions to the current export selection. Existing manual selections stay ticked.", padx=(12, 3))
        help_action(selection_row, "Add Manual Allocations", lambda d=direction: self.select_manual_allocated_export(d), "Add all successfully manually allocated or manually corrected transactions to the current export selection. Existing automatic selections stay ticked.")
        help_action(selection_row, "Select All", lambda d=direction: self.set_all_export(d, True), "Tick every transaction in this payment/receipt list for export.")
        help_action(selection_row, "Clear All", lambda d=direction: self.set_all_export(d, False), "Untick every transaction in this payment/receipt list so you can start a new export selection.")

        summary = ttk.Frame(tab, padding=(8, 0, 8, 7)); summary.pack(fill="x")
        ttk.Label(summary, textvariable=self.summary_vars[direction], font=("Segoe UI", 10, "bold")).pack(side="left")
        ttk.Label(summary, text="☐ / ☑ controls export", foreground="#555555").pack(side="right")

        cols = ("inc", "date", "details", "description", "amount", "key", "repeat", "account", "vat", "rule", "status")
        tree = ttk.Treeview(tab, columns=cols, show="headings", selectmode="extended")
        self.trees[direction] = tree
        labels = {
            "inc": "Export", "date": "Date", "details": "Bank description / reference", "description": "Pastel description", "amount": "Current CSV amount",
            "key": "Matched name + number", "repeat": "Recurring", "account": "GL account", "vat": "VAT", "rule": "Rule", "status": "Status"
        }
        widths = {"inc": 58, "date": 88, "details": 280, "description": 170, "amount": 105, "key": 155, "repeat": 70, "account": 100, "vat": 55, "rule": 145, "status": 185}
        for c in cols:
            if c == "date":
                tree.heading(c, text=labels[c], command=lambda d=direction: self.toggle_date_sort(d))
            else:
                tree.heading(c, text=labels[c])
            tree.column(c, width=widths[c], anchor="center" if c == "inc" else ("e" if c == "amount" else "w"), stretch=(c in {"details", "description", "rule"}))
        y = ttk.Scrollbar(tab, orient="vertical", command=tree.yview)
        x = ttk.Scrollbar(tab, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=(0, 8)); y.pack(side="right", fill="y", pady=(0, 8)); x.pack(side="bottom", fill="x", padx=8)
        tree.bind("<Button-1>", lambda e, d=direction: self._tree_click(e, d), add="+")
        tree.bind("<Double-1>", lambda e, d=direction: self._tree_double_click(e, d))
        tree.tag_configure("unassigned", background="#fff4d6")
        tree.tag_configure("assigned", background="#eaf7ea")
        tree.tag_configure("excluded", foreground="#888888")
        tree.tag_configure("ambiguous", background="#ffe5e5")
        tree.tag_configure("corrected", background="#e8f1ff")

    def _build_recurring_tab(self, tab, direction: str):
        noun = self._noun(direction)
        noun_plural = self._noun(direction, True)
        top = ttk.Frame(tab, padding=8); top.pack(fill="x")
        ttk.Label(
            top,
            text=(f"Expand a name and recurring identity to see every individual {noun} underneath it. "
                  f"Each actual transaction can be selected, included/excluded from export, and assigned independently for this statement. "
                  f"Use 'Save / edit identity rule' only when you deliberately want the same rule to apply to that recurring identity in future CSV files."),
            wraplength=1160
        ).pack(side="left", fill="x", expand=True)

        actions = ttk.LabelFrame(tab, text="Recurring allocation tools", padding=(8, 4, 8, 6)); actions.pack(fill="x", padx=8, pady=(0, 5))
        help_action(actions, f"Assign selected {noun} once", lambda d=direction: self.assign_recurring_transaction_once(d), "Allocate only the selected recurring transaction. Other transactions in the same recurring group are not changed.")
        help_action(actions, "Correct auto-allocation", lambda d=direction: self.correct_recurring_auto_allocation(d), "Correct the selected recurring transaction. If you update the saved rule, matching rows remain automatic allocations.")
        help_action(actions, "Save / edit identity rule", lambda d=direction: self.assign_recurring_rule(d), "Create or edit the saved allocation rule for this recurring identity so future matching CSV transactions can allocate automatically.")
        help_action(actions, "Toggle selected export", lambda d=direction: self.toggle_recurring_include_selected(d), "Toggle the export tick for the currently selected recurring transaction only.", padx=(12, 3))
        help_action(actions, "Clear assignment", lambda d=direction: self.clear_recurring_transaction_assignment(d), "Remove the allocation from the selected recurring transaction in this statement.")
        help_action(actions, "Reset to saved rule", lambda d=direction: self.reset_recurring_transaction_to_rule(d), "Discard statement-only changes for the selected recurring transaction and reapply its saved rule.")
        help_action(actions, f"Show in {noun_plural.title()}", lambda d=direction: self.show_recurring_in_transactions(d), "Jump back to the main transaction list and show the selected recurring transaction.", padx=(12, 3))

        actions2 = ttk.LabelFrame(tab, text="Quick select for export", padding=(8, 4, 8, 6)); actions2.pack(fill="x", padx=8, pady=(0, 7))
        ttk.Label(actions2, text="These buttons are additive: click Auto and Manual to keep BOTH groups ticked together. Clear only when you want to start over.", foreground="#555555").pack(anchor="w", pady=(0, 3))
        recurring_selection_row = ttk.Frame(actions2); recurring_selection_row.pack(fill="x")
        help_action(recurring_selection_row, "Add Auto-Allocated", lambda d=direction: self.select_auto_allocated_export(d, True), "Add recurring transactions allocated automatically by saved rules. Existing manual selections remain ticked.")
        help_action(recurring_selection_row, "Add Manual Allocations", lambda d=direction: self.select_manual_allocated_export(d, True), "Add recurring transactions that were allocated or corrected manually. Existing automatic selections remain ticked.")
        help_action(recurring_selection_row, "Select All Recurring", lambda d=direction: self.set_all_recurring_export(d, True), "Tick every recurring transaction for export.")
        help_action(recurring_selection_row, "Clear Recurring", lambda d=direction: self.set_all_recurring_export(d, False), "Untick every recurring transaction so you can build a new selection.")
        help_action(recurring_selection_row, "Expand all", lambda d=direction: self.set_recurring_expanded(d, True), "Expand every recurring group so its individual transactions are visible.", side="right")
        help_action(recurring_selection_row, "Collapse all", lambda d=direction: self.set_recurring_expanded(d, False), "Collapse every recurring group to show only the group headings.", side="right")

        cols = ("inc", "identity", "date", "details", "amount", "account", "vat", "rule", "status")
        tree = ttk.Treeview(tab, columns=cols, show="tree headings", selectmode="browse")
        self.recurring_trees[direction] = tree
        tree.heading("#0", text="Name / recurring identity / transaction")
        tree.column("#0", width=235, stretch=True)
        labels = {
            "inc": "Export", "identity": "Recurring identity", "date": "Date", "details": "Bank description / reference",
            "amount": "Current CSV amount", "account": "GL account", "vat": "VAT", "rule": "Rule", "status": "Status"
        }
        widths = {"inc":58, "identity":165, "date":88, "details":300, "amount":110, "account":100, "vat":55, "rule":145, "status":185}
        for c in cols:
            tree.heading(c, text=labels[c])
            anchor = "center" if c in {"inc", "date", "vat"} else ("e" if c == "amount" else "w")
            tree.column(c, width=widths[c], anchor=anchor, stretch=c in {"details", "rule", "status"})
        y = ttk.Scrollbar(tab, orient="vertical", command=tree.yview); x = ttk.Scrollbar(tab, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=(0, 8)); y.pack(side="right", fill="y", pady=(0, 8)); x.pack(side="bottom", fill="x", padx=8)
        tree.bind("<Button-1>", lambda e, d=direction: self._recurring_tree_click(e, d), add="+")
        tree.bind("<Double-1>", lambda e, d=direction: self._recurring_tree_double_click(e, d))
        tree.tag_configure("unassigned", background="#fff4d6")
        tree.tag_configure("assigned", background="#eaf7ea")
        tree.tag_configure("excluded", foreground="#888888")
        tree.tag_configure("ambiguous", background="#ffe5e5")
        tree.tag_configure("corrected", background="#e8f1ff")
        tree.tag_configure("mixed", background="#eef3ff")
        tree.tag_configure("parent", font=("Segoe UI", 9, "bold"))
        tree.tag_configure("identity", font=("Segoe UI", 9, "bold"))

    def _build_rules(self):
        top = ttk.Frame(self.rule_tab, padding=8); top.pack(fill="x")
        ttk.Button(top, text="New payment rule", command=lambda: self.edit_rule(None, "PAYMENT")).pack(side="left", padx=3)
        ttk.Button(top, text="New receipt rule", command=lambda: self.edit_rule(None, "RECEIPT")).pack(side="left", padx=3)
        ttk.Button(top, text="Edit", command=self.edit_selected_rule).pack(side="left", padx=(12, 3))
        ttk.Button(top, text="Delete", command=self.delete_selected_rule).pack(side="left", padx=3)
        ttk.Button(top, text="Export rules backup…", command=self.export_rules).pack(side="right", padx=3)
        ttk.Button(top, text="Import rules backup…", command=self.import_rules).pack(side="right", padx=3)
        cols = ("id", "direction", "name", "mode", "pattern", "account", "description", "amount_rule", "vat", "tax", "ref", "priority")
        self.rule_tree = ttk.Treeview(self.rule_tab, columns=cols, show="headings", selectmode="browse")
        labels = {"id":"ID", "direction":"Type", "name":"Rule name", "mode":"Match", "pattern":"Name / number", "account":"GL account", "description":"Pastel description", "amount_rule":"Amount rule", "vat":"VAT", "tax":"Tax type", "ref":"Pastel ref", "priority":"Priority"}
        widths = {"id":45, "direction":75, "name":150, "mode":75, "pattern":180, "account":90, "description":160, "amount_rule":190, "vat":50, "tax":65, "ref":75, "priority":60}
        for c in cols:
            self.rule_tree.heading(c, text=labels[c]); self.rule_tree.column(c, width=widths[c], stretch=c in {"name", "pattern", "description", "amount_rule"})
        self.rule_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8)); self.rule_tree.bind("<Double-1>", lambda e: self.edit_selected_rule())
        self.refresh_rules()

    def _build_settings(self):
        f = ttk.Frame(self.settings_tab, padding=18); f.pack(anchor="nw", fill="x")
        self.setting_vars = {
            "contra_account": tk.StringVar(value=self.store.get_setting("contra_account")),
            "vat_tax_type": tk.StringVar(value=self.store.get_setting("vat_tax_type")),
            "vat_rate": tk.StringVar(value=self.store.get_setting("vat_rate", "15")),
            "fiscal_start_month": tk.StringVar(value=self.store.get_setting("fiscal_start_month", "3")),
            "project_code": tk.StringVar(value=self.store.get_setting("project_code")),
        }
        rows = [
            ("Cash Book bank GL account (Pastel import column L)", "contra_account", "This is the bank/general-ledger account linked to the Cash Book. Pastel's CSV layout calls column L 'Contra Account', but it is NOT a different contra per payment/receipt. Enter it once for the Cash Book (max 7 characters). You may leave it blank if your Pastel import accepts a blank column L."),
            ("VAT tax type number", "vat_tax_type", "Company-specific Pastel tax type. Leave blank until you confirm it in your Pastel company."),
            ("VAT rate (%)", "vat_rate", "Default 15%. VAT is calculated as inclusive from the bank transaction total."),
            ("Fiscal year start month (1–12)", "fiscal_start_month", "Used to calculate Pastel period 1–12 from each transaction date. Confirm against Setup → Periods."),
            ("Project code (optional)", "project_code", "Optional Pastel project/cost code, max 5 characters."),
        ]
        for i, (label, key, helptext) in enumerate(rows):
            ttk.Label(f, text=label, font=("Segoe UI", 10, "bold")).grid(row=i*2, column=0, sticky="w", pady=(6, 0))
            ttk.Entry(f, textvariable=self.setting_vars[key], width=24).grid(row=i*2, column=1, sticky="w", padx=14, pady=(6, 0))
            ttk.Label(f, text=helptext, wraplength=700, foreground="#555555").grid(row=i*2+1, column=0, columnspan=3, sticky="w", pady=(0, 6))
        buttons = ttk.Frame(f)
        buttons.grid(row=len(rows)*2, column=0, columnspan=3, sticky="w", pady=16)
        ttk.Button(buttons, text="Save settings", command=self.save_settings, style="Accent.TButton").pack(side="left", padx=(0,8))
        ttk.Button(buttons, text="Export settings backup…", command=self.export_settings_backup).pack(side="left", padx=4)
        ttk.Button(buttons, text="Import settings backup / v1.10 database…", command=self.import_settings_backup).pack(side="left", padx=4)
        transfer_note = ("The Default company profile uses the original Pastel Payment Assistant database, so existing rules/settings/history are preserved when upgrading. "
                         "Each additional company profile has its own separate database. Settings import/export acts only on the currently selected profile.")
        ttk.Label(f, text=transfer_note, wraplength=820, foreground="#555555").grid(row=len(rows)*2+1, column=0, columnspan=3, sticky="w", pady=(0,8))
        note = ("The app creates review-first Pastel cash-book import files. Selected outgoing rows are exported to a Payments CSV; "
                "selected incoming rows are exported to a Receipts CSV. Review each imported batch in Pastel before Update/Process.")
        ttk.Label(f, text=note, wraplength=820).grid(row=len(rows)*2+2, column=0, columnspan=3, sticky="w")

    def settings_dict(self):
        return {k: v.get().strip() for k, v in self.setting_vars.items()}

    def save_settings(self, quiet=False):
        for k, v in self.setting_vars.items():
            self.store.set_setting(k, v.get().strip())
        if self.txns or self.receipts:
            self.reapply_rules(silent=True)
        if not quiet:
            messagebox.showinfo(APP_NAME, "Settings saved.")

    def export_settings_backup(self):
        self.save_settings(quiet=True)
        p = filedialog.asksaveasfilename(
            title="Export settings backup",
            defaultextension=".json",
            filetypes=[("Pastel settings backup", "*.json"), ("All files", "*.*")],
            initialfile="Pastel_Payment_Assistant_Settings_Backup.json",
        )
        if not p:
            return
        data = {
            "format": "PastelPaymentAssistantSettings",
            "format_version": 1,
            "app_version": APP_VERSION,
            "settings": {k: self.store.get_setting(k, "") for k in SETTINGS_TRANSFER_KEYS},
        }
        try:
            with open(p, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not export settings backup:\n{e}")
            return
        messagebox.showinfo(APP_NAME, f"Settings backup saved:\n{p}")

    def import_settings_backup(self):
        p = filedialog.askopenfilename(
            title="Import settings backup or v1.10 database",
            filetypes=[
                ("Pastel settings backup / database", "*.json *.db"),
                ("JSON settings backup", "*.json"),
                ("Pastel Payment Assistant database", "*.db"),
                ("All files", "*.*"),
            ],
        )
        if not p:
            return
        try:
            incoming = read_settings_transfer(p)
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not import settings:\n{e}")
            return
        preview = "\n".join(f"{k}: {incoming.get(k, '')}" for k in SETTINGS_TRANSFER_KEYS if k in incoming)
        if not messagebox.askyesno(APP_NAME, "Import these settings and replace the current values?\n\n" + preview):
            return
        for k, value in incoming.items():
            if k in self.setting_vars:
                self.setting_vars[k].set(value)
        self.save_settings(quiet=True)
        source = "v1.10 database" if Path(p).suffix.lower() == ".db" else "settings backup"
        messagebox.showinfo(APP_NAME, f"Imported {len(incoming)} setting(s) from the {source}.\n\nThe imported values are now active in v1.11.")

    def load_csv(self):
        start = self.store.get_setting("last_folder", str(Path.home()))
        p = filedialog.askopenfilename(title="Select bank statement CSV", initialdir=start, filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not p:
            return
        try:
            payments, receipts, parser = BankCSVParser.load(p)
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not load this CSV:\n\n{e}")
            return
        if not payments and not receipts:
            messagebox.showwarning(APP_NAME, "No bank transactions were found in this CSV.")
            return
        self.current_file = p; self.parser_name = parser; self.txns = payments; self.receipts = receipts
        for d in self.DIRECTIONS:
            self.review_selection[d].clear()
        self.store.set_setting("last_folder", str(Path(p).parent))
        self.store.remember_transactions(self.txns)
        self.store.remember_transactions(self.receipts)
        self.reapply_rules(silent=True)
        self.notebook.select(self.pay_tab if payments else self.receipt_tab)
        if getattr(self, "ui_mode", DEFAULT_UI_MODE) == "modern":
            self._navigate_modern("payments" if payments else "receipts")
        self.status_var.set(f"Loaded {len(payments)} payments and {len(receipts)} receipts from {Path(p).name} • amounts taken from this CSV")

    def reapply_rules(self, silent=False):
        if not self.txns and not self.receipts:
            if not silent:
                messagebox.showinfo(APP_NAME, "Load a bank CSV first.")
            return
        try:
            default_tax = int(self.store.get_setting("vat_tax_type", "") or 0)
        except Exception:
            default_tax = 0
        apply_rules(self.txns, self.store.rules("PAYMENT"), default_tax)
        apply_rules(self.receipts, self.store.rules("RECEIPT"), default_tax)
        assign_monthly_sequential_references(self.txns + self.receipts)
        for d in self.DIRECTIONS:
            self.update_repeat_dropdown(d)
            self.refresh_transaction_tree(d)
            self.refresh_recurring_tree(d)
        self.refresh_rules()
        psel = sum(1 for t in self.txns if t.include)
        rsel = sum(1 for t in self.receipts if t.include)
        passigned = sum(1 for t in self.txns if t.include and t.account and not t.ambiguous)
        rassigned = sum(1 for t in self.receipts if t.include and t.account and not t.ambiguous)
        self.status_var.set(f"Selected for export: {psel} payments ({passigned} assigned) • {rsel} receipts ({rassigned} assigned)")
        if not silent:
            messagebox.showinfo(APP_NAME, f"Saved rules applied.\n\nPayments selected: {psel}\nReceipts selected: {rsel}")

    def update_repeat_dropdown(self, direction: str):
        combo = self.repeat_combos.get(direction)
        if not combo:
            return
        txns = self._list(direction)
        keys = repeat_description_choices(txns)
        mapping = {}
        values = ["— Select repeat description —", "All repeat descriptions"]
        for key in keys:
            count = max((t.recurring_count for t in txns if recurring_identity_key(t.details, t.txn_type) == key), default=2)
            display = f"{key}  (x{count})"
            mapping[display] = key
            values.append(display)
        self.repeat_display_to_key[direction] = mapping
        combo.configure(values=values)
        if self.repeat_vars[direction].get() not in values:
            self.repeat_vars[direction].set("— Select repeat description —")

    def _repeat_description_selected(self, direction: str):
        choice = self.repeat_vars[direction].get()
        if choice == "All repeat descriptions" or choice in self.repeat_display_to_key[direction]:
            self.filter_vars[direction].set("Recurring")
        self.refresh_transaction_tree(direction)

    def clear_repeat_description(self, direction: str):
        self.repeat_vars[direction].set("— Select repeat description —")
        self.refresh_transaction_tree(direction)

    def toggle_date_sort(self, direction: str):
        self.sort_vars[direction].set("Newest first" if self.sort_vars[direction].get() == "Oldest first" else "Oldest first")
        self.refresh_transaction_tree(direction)

    def refresh_transaction_tree(self, direction: str):
        tree = self.trees.get(direction)
        if not tree:
            return
        txns = self._list(direction)
        q = normalize_text(self.search_vars[direction].get())
        flt = self.filter_vars[direction].get()
        repeat_choice = self.repeat_vars[direction].get()
        repeat_key = self.repeat_display_to_key[direction].get(repeat_choice, "")
        newest = self.sort_vars[direction].get() == "Newest first"
        tree.heading("date", text="Date ▼" if newest else "Date ▲", command=lambda d=direction: self.toggle_date_sort(d))
        tree.delete(*tree.get_children())
        shown = 0
        items = sorted(enumerate(txns), key=lambda p: (p[1].txn_date, p[1].row_no), reverse=newest)
        for idx, t in items:
            hay = normalize_text(f"{t.details} {t.description} {t.txn_type} {t.match_key} {t.account} {t.rule_name} {t.status}")
            if q and q not in hay:
                continue
            current_repeat_key = recurring_identity_key(t.details, t.txn_type)
            if repeat_choice == "All repeat descriptions" and t.recurring_count < 2:
                continue
            if repeat_key and current_repeat_key != repeat_key:
                continue
            if flt == "Recurring" and t.recurring_count < 2:
                continue
            if flt == "Unassigned" and (t.account or not t.include):
                continue
            if flt == "Ambiguous" and (not t.ambiguous or not t.include):
                continue
            if flt == "Assigned" and (not t.account or not t.include or t.ambiguous):
                continue
            if flt == "Auto-allocated" and (not t.auto_allocated or not t.include or t.ambiguous):
                continue
            if flt == "Amount review" and (not t.status.startswith("Amount review required") or not t.include):
                continue
            if flt == "Corrected" and (not t.status.startswith("Corrected") or not t.include):
                continue
            if flt == "VAT" and (not t.vat or not t.include):
                continue
            if flt == "No VAT" and (t.vat or not t.include):
                continue
            if flt == "Selected for export" and not t.include:
                continue
            if flt == "Not selected" and t.include:
                continue
            tag = "excluded" if not t.include else ("ambiguous" if t.ambiguous else ("corrected" if t.status.startswith("Corrected") else ("assigned" if t.account else "unassigned")))
            repeat = f"x{t.recurring_count}" if t.recurring_count >= 2 else ""
            vals = ("☑" if t.include else "☐", t.txn_date.strftime("%d/%m/%Y"), t.details, t.description, f"R {money(t.payment_amount)}", t.match_key, repeat, t.account, "VAT" if t.vat else "No", t.rule_name, t.status)
            tree.insert("", "end", iid=str(idx), values=vals, tags=(tag,))
            shown += 1
        selected = [t for t in txns if t.include]
        total = sum((t.payment_amount for t in selected), Decimal("0.00"))
        assigned = sum(1 for t in selected if t.account and not t.ambiguous)
        ambiguous = sum(1 for t in selected if t.ambiguous)
        unassigned = sum(1 for t in selected if not t.account and not t.ambiguous)
        vat_count = sum(1 for t in selected if t.account and t.vat)
        auto_count = sum(1 for t in selected if t.auto_allocated and t.account and not t.ambiguous)
        corrected_count = sum(1 for t in selected if t.status.startswith("Corrected"))
        recurring = sum(1 for t in txns if t.recurring_count >= 2)
        recurring_groups = len({recurring_identity_key(t.details, t.txn_type) for t in txns if t.recurring_count >= 2})
        self.summary_vars[direction].set(
            f"{len(txns)} {self._noun(direction, True)} • {len(selected)} selected for export • {assigned} assigned • {unassigned} unassigned • "
            f"{recurring} recurring ({recurring_groups} groups) • {ambiguous} ambiguous • {auto_count} auto • {corrected_count} corrected • {vat_count} VAT • Selected total R {money(total)} • Showing {shown}"
        )

        if hasattr(self, "dashboard_vars"):
            self._refresh_dashboard()

    def _tree_click(self, event, direction: str):
        tree = self.trees[direction]
        if tree.identify_region(event.x, event.y) == "cell" and tree.identify_column(event.x) == "#1":
            iid = tree.identify_row(event.y)
            if iid:
                txns = self._list(direction)
                try:
                    idx = int(iid); txns[idx].include = not txns[idx].include
                except Exception:
                    return
                self.refresh_transaction_tree(direction)
                tree.selection_set(iid)
                return "break"

    def _tree_double_click(self, event, direction: str):
        if self.trees[direction].identify_column(event.x) != "#1":
            self.assign_rule_selected(direction)

    def selected_txns(self, direction: str) -> List[Transaction]:
        out = []
        txns = self._list(direction)
        for iid in self.trees[direction].selection():
            try:
                out.append(txns[int(iid)])
            except Exception:
                pass
        return out

    def one_selected(self, direction: str) -> Optional[Transaction]:
        xs = self.selected_txns(direction)
        if not xs:
            messagebox.showinfo(APP_NAME, f"Select a {self._noun(direction)} first.")
            return None
        if len(xs) > 1:
            messagebox.showinfo(APP_NAME, f"Select one {self._noun(direction)} for this action.")
            return None
        return xs[0]

    def assign_rule_selected(self, direction: str):
        t = self.one_selected(direction)
        if not t:
            return
        existing = self.store.get_rule(t.rule_id) if t.rule_id else None
        if existing:
            choice = messagebox.askyesnocancel(
                APP_NAME,
                f"This {self._noun(direction)} is already matched by rule '{existing.name}'.\n\n"
                "Yes = edit that existing rule (affects future statements)\n"
                "No = create a new, more specific rule from this transaction\n"
                "Cancel = do nothing"
            )
            if choice is None:
                return
            if choice is False:
                existing = None
        dlg = RuleDialog(self, self.store, t, existing)
        self.wait_window(dlg)
        if dlg.result:
            if id(t) not in getattr(dlg, "applied_review_transaction_ids", set()):
                t.manual_override = False
            self.reapply_rules(silent=True)

    def manual_assign_selected(self, direction: str):
        t = self.one_selected(direction)
        if not t:
            return
        dlg = ManualAssignDialog(self, t, self.store.get_setting("vat_tax_type", ""), self.store.known_accounts()); self.wait_window(dlg)
        if dlg.result:
            t.account, t.vat, t.tax_type, t.pastel_ref, t.description = dlg.result
            t.rule_id = None; t.rule_name = "Manual (this file only)"; t.status = "Manual assignment"; t.manual_override = True; t.ambiguous = False; t.auto_allocated = False; t.amount_condition_applied = False
            t.match_key = smart_key(t.details, t.txn_type)
            self.refresh_transaction_tree(direction)

    def toggle_vat_selected(self, direction: str):
        xs = self.selected_txns(direction)
        if not xs:
            messagebox.showinfo(APP_NAME, f"Select one or more {self._noun(direction, True)} first.")
            return
        try:
            default_tax = int(self.store.get_setting("vat_tax_type", "") or 0)
        except Exception:
            default_tax = 0
        target = not all(t.vat for t in xs)
        for t in xs:
            t.vat = target; t.tax_type = default_tax if target else 0; t.manual_override = True; t.auto_allocated = False
            if t.account:
                t.status = "Manual VAT override"
        self.refresh_transaction_tree(direction)

    def toggle_include_selected(self, direction: str):
        xs = self.selected_txns(direction)
        if not xs:
            messagebox.showinfo(APP_NAME, f"Select one or more {self._noun(direction, True)} first.")
            return
        target = not all(t.include for t in xs)
        for t in xs:
            t.include = target
        self.refresh_transaction_tree(direction)

    def set_all_export(self, direction: str, selected: bool):
        for t in self._list(direction):
            t.include = selected
        self.refresh_transaction_tree(direction)
        self.status_var.set(f"{'Selected all' if selected else 'Cleared all'} {self._noun(direction, True)} for export.")

    def select_auto_allocated_export(self, direction: str, recurring_only: bool = False):
        # Add matching automatic allocations to the current export selection.
        # Do not clear manual allocations (or any other rows) that are already ticked.
        matched = 0
        added = 0
        for t in self._list(direction):
            if recurring_only and t.recurring_count < 2:
                continue
            selected = bool(t.auto_allocated and t.account and not t.ambiguous)
            if selected:
                matched += 1
                if not t.include:
                    added += 1
                t.include = True
        self.refresh_transaction_tree(direction)
        self.refresh_recurring_tree(direction)
        scope = "recurring " if recurring_only else ""
        self.status_var.set(f"Added {added} automatically allocated {scope}{self._noun(direction, True)} to the export selection ({matched} matching). Existing manual selections were preserved.")

    def select_manual_allocated_export(self, direction: str, recurring_only: bool = False):
        """Add allocated manual/corrected rows to the existing export selection."""
        matched = 0
        added = 0
        for t in self._list(direction):
            if recurring_only and t.recurring_count < 2:
                continue
            selected = bool(t.manual_override and t.account and not t.ambiguous)
            if selected:
                matched += 1
                if not t.include:
                    added += 1
                t.include = True
        self.refresh_transaction_tree(direction)
        self.refresh_recurring_tree(direction)
        scope = "recurring " if recurring_only else ""
        self.status_var.set(f"Added {added} manually allocated {scope}{self._noun(direction, True)} to the export selection ({matched} matching). Existing automatic selections were preserved.")

    def correct_auto_allocation_selected(self, direction: str, txn: Optional[Transaction] = None):
        t = txn or self.one_selected(direction)
        if not t:
            return
        if not (t.auto_allocated and t.account and not t.ambiguous):
            messagebox.showinfo(APP_NAME, "Select an untouched automatically allocated transaction. Manual, corrected, ambiguous or unassigned rows are not treated as false auto-allocations.")
            return
        rule = self.store.get_rule(t.rule_id) if t.rule_id else None
        dlg = CorrectionDialog(self, self.store, t, rule)
        self.wait_window(dlg)
        if not dlg.result:
            return
        account, description, vat, tax_type, pastel_ref, update_rule = dlg.result
        if update_rule and rule:
            if t.amount_condition_applied and rule.amount_operator and rule.amount_account:
                rule.amount_account = account
                rule.amount_description = description
            else:
                rule.account = account
                rule.description = description
            rule.vat = vat
            rule.tax_type = tax_type
            rule.pastel_ref = pastel_ref
            self.store.save_rule(rule)
            t.manual_override = False
            self.reapply_rules(silent=True)
            self.refresh_transaction_tree(direction)
            self.refresh_recurring_tree(direction)
            self.status_var.set("Saved rule updated and reapplied. Matching transactions are automatic allocations and will be included by Select Auto-Allocated.")
            return

        # A correction that is explicitly for this statement only remains a
        # manual/corrected row and must not be selected by Select Auto-Allocated.
        t.account = account
        t.description = description
        t.vat = vat
        t.tax_type = tax_type
        t.pastel_ref = pastel_ref
        t.rule_id = rule.id if rule else t.rule_id
        t.rule_name = f"Corrected • {rule.name}" if rule else "Corrected"
        t.status = "Corrected allocation • this statement only"
        t.manual_override = True
        t.auto_allocated = False
        t.ambiguous = False
        self.refresh_transaction_tree(direction)
        self.refresh_recurring_tree(direction)
        self.status_var.set("Correction saved for this statement only. It remains excluded by Select Auto-Allocated.")

    def clear_assignment_selected(self, direction: str):
        xs = self.selected_txns(direction)
        if not xs:
            return
        for t in xs:
            t.rule_id = None; t.rule_name = ""; t.account = ""; t.description = ""; t.vat = False; t.tax_type = 0
            t.status = f"Recurring x{t.recurring_count} • unassigned" if t.recurring_count >= 2 else "Unassigned"
            t.manual_override = True; t.ambiguous = False; t.auto_allocated = False; t.amount_condition_applied = False
        self.refresh_transaction_tree(direction)

    def reset_selected_to_rule(self, direction: str):
        xs = self.selected_txns(direction)
        if not xs:
            messagebox.showinfo(APP_NAME, f"Select one or more {self._noun(direction, True)} first.")
            return
        for t in xs:
            t.manual_override = False
        self.reapply_rules(silent=True)

    def _specific_rule_for_key(self, key: str, direction: str) -> Optional[Rule]:
        nk = normalize_text(key)
        candidates = []
        for r in self.store.all_rules(direction):
            if r.enabled and (r.mode or "").upper() == "SMART" and normalize_text(r.pattern) == nk:
                candidates.append(r)
        if not candidates:
            return None
        candidates.sort(key=lambda r: (r.priority, len(normalize_text(r.pattern)), r.id or 0), reverse=True)
        return candidates[0]

    def refresh_recurring_tree(self, direction: str):
        tree = self.recurring_trees.get(direction)
        if not tree:
            return
        txns = self._list(direction)
        open_items = {iid for iid in tree.get_children("") if tree.item(iid, "open")}
        for pid in tree.get_children(""):
            for kid in tree.get_children(pid):
                if tree.item(kid, "open"):
                    open_items.add(kid)
        selected_before = tree.selection()[0] if tree.selection() else ""
        tree.delete(*tree.get_children())
        self.recurring_key_to_indices[direction] = {}
        self.recurring_item_to_index[direction] = {}

        groups: Dict[str, Dict[str, List[int]]] = {}
        for idx, t in enumerate(txns):
            if t.recurring_count < 2:
                continue
            key = recurring_identity_key(t.details, t.txn_type)
            if not key:
                continue
            parent = recurring_parent_name(key)
            groups.setdefault(parent, {}).setdefault(key, []).append(idx)
            self.recurring_key_to_indices[direction].setdefault(key, []).append(idx)

        for parent in sorted(groups, key=normalize_text):
            children = groups[parent]
            pid = "grp:" + hashlib.sha1(f"{direction}|{parent}".encode("utf-8")).hexdigest()[:12]
            total_txns = sum(len(v) for v in children.values())
            specific_rules = sum(1 for key in children if self._specific_rule_for_key(key, direction))
            tree.insert(
                "", "end", iid=pid, text=parent, open=(pid in open_items),
                values=("", "", "", f"{len(children)} recurring identities • {total_txns} individual transactions", "", "", "", "", f"{specific_rules}/{len(children)} identity rules"),
                tags=("parent",)
            )

            for key in sorted(children, key=normalize_text):
                idxs = sorted(children[key], key=lambda i: (txns[i].txn_date, txns[i].row_no))
                txs = [txns[i] for i in idxs]
                exact = self._specific_rule_for_key(key, direction)
                kid = "key:" + hashlib.sha1(f"{direction}|{key}".encode("utf-8")).hexdigest()[:12]

                if exact:
                    account = exact.account
                    vat = "VAT" if exact.vat else "No"
                    rule_name = exact.name
                    status = f"Identity rule saved • {len(txs)} transactions"
                    tag = "assigned"
                else:
                    eff_accounts = {t.account for t in txs if t.account}
                    eff_rules = {t.rule_name for t in txs if t.rule_name}
                    account = next(iter(eff_accounts)) if len(eff_accounts) == 1 else ("Multiple" if len(eff_accounts) > 1 else "")
                    vat_values = {"VAT" if t.vat else "No" for t in txs if t.account}
                    vat = next(iter(vat_values)) if len(vat_values) == 1 else ("Mixed" if len(vat_values) > 1 else "")
                    rule_name = next(iter(eff_rules)) if len(eff_rules) == 1 else ("Multiple" if len(eff_rules) > 1 else "")
                    status = f"{len(txs)} individual transactions — expand to manage separately"
                    tag = "mixed" if account else "unassigned"

                total = sum((t.payment_amount for t in txs), Decimal("0.00"))
                tree.insert(
                    pid, "end", iid=kid, text=recurring_child_label(key), open=(kid in open_items),
                    values=("", key, "", f"{len(txs)} individual transactions", f"R {money(total)} total", account, vat, rule_name, status),
                    tags=("identity", tag)
                )

                for idx in idxs:
                    t = txns[idx]
                    tiid = f"txn:{idx}"
                    self.recurring_item_to_index[direction][tiid] = idx
                    txn_tag = "excluded" if not t.include else ("ambiguous" if t.ambiguous else ("corrected" if t.status.startswith("Corrected") else ("assigned" if t.account else "unassigned")))
                    tree.insert(
                        kid, "end", iid=tiid,
                        text=f"{t.txn_date:%d/%m/%Y} • R {money(t.payment_amount)}",
                        values=("☑" if t.include else "☐", key, t.txn_date.strftime("%d/%m/%Y"), t.details,
                                f"R {money(t.payment_amount)}", t.account, "VAT" if t.vat else "No", t.rule_name, t.status),
                        tags=(txn_tag,)
                    )

        if selected_before and tree.exists(selected_before):
            tree.selection_set(selected_before)
            tree.see(selected_before)

    def _selected_recurring_key(self, direction: str, quiet: bool = False) -> Optional[str]:
        tree = self.recurring_trees[direction]
        sel = tree.selection()
        if not sel:
            if not quiet:
                messagebox.showinfo(APP_NAME, "Select a recurring identity or an individual transaction first.")
            return None
        iid = sel[0]
        if iid.startswith("grp:"):
            tree.item(iid, open=not bool(tree.item(iid, "open")))
            if not quiet:
                messagebox.showinfo(APP_NAME, "Expand the name, then select a recurring identity or one individual transaction.")
            return None
        if iid.startswith("txn:"):
            idx = self.recurring_item_to_index[direction].get(iid)
            if idx is None:
                return None
            t = self._list(direction)[idx]
            return recurring_identity_key(t.details, t.txn_type)
        key = tree.set(iid, "identity").strip()
        return key or None

    def _selected_recurring_transaction(self, direction: str, quiet: bool = False) -> Optional[Transaction]:
        tree = self.recurring_trees[direction]
        sel = tree.selection()
        if not sel:
            if not quiet:
                messagebox.showinfo(APP_NAME, f"Expand a recurring identity and select one individual {self._noun(direction)} first.")
            return None
        iid = sel[0]
        idx = self.recurring_item_to_index[direction].get(iid)
        if idx is None:
            if not quiet:
                messagebox.showinfo(APP_NAME, f"Select one individual transaction row, not the group or recurring identity.")
            return None
        txns = self._list(direction)
        if idx < 0 or idx >= len(txns):
            return None
        return txns[idx]

    def _selected_recurring_index(self, direction: str) -> Optional[int]:
        tree = self.recurring_trees[direction]
        sel = tree.selection()
        if not sel:
            return None
        return self.recurring_item_to_index[direction].get(sel[0])

    def _recurring_tree_click(self, event, direction: str):
        tree = self.recurring_trees[direction]
        if tree.identify_region(event.x, event.y) == "cell" and tree.identify_column(event.x) == "#1":
            iid = tree.identify_row(event.y)
            idx = self.recurring_item_to_index[direction].get(iid)
            if idx is None:
                return
            txns = self._list(direction)
            txns[idx].include = not txns[idx].include
            self.refresh_transaction_tree(direction)
            self.refresh_recurring_tree(direction)
            if tree.exists(iid):
                tree.selection_set(iid); tree.see(iid)
            return "break"

    def _recurring_tree_double_click(self, event, direction: str):
        tree = self.recurring_trees[direction]
        iid = tree.identify_row(event.y)
        if not iid:
            return
        tree.selection_set(iid)
        if iid.startswith("txn:"):
            self.assign_recurring_transaction_once(direction)
        elif iid.startswith("key:"):
            self.assign_recurring_rule(direction)
        elif iid.startswith("grp:"):
            tree.item(iid, open=not bool(tree.item(iid, "open")))

    def assign_recurring_transaction_once(self, direction: str):
        t = self._selected_recurring_transaction(direction)
        if not t:
            return
        dlg = ManualAssignDialog(self, t, self.store.get_setting("vat_tax_type", ""), self.store.known_accounts())
        self.wait_window(dlg)
        if dlg.result:
            t.account, t.vat, t.tax_type, t.pastel_ref, t.description = dlg.result
            t.rule_id = None
            t.rule_name = "Manual (this file only)"
            t.status = "Manual assignment — individual transaction"
            t.manual_override = True
            t.ambiguous = False
            t.auto_allocated = False
            t.amount_condition_applied = False
            t.match_key = smart_key(t.details, t.txn_type)
            self.refresh_transaction_tree(direction)
            self.refresh_recurring_tree(direction)
            self.status_var.set(f"Assigned only the selected {self._noun(direction)}. Other transactions in the recurring group were not changed.")

    def correct_recurring_auto_allocation(self, direction: str):
        t = self._selected_recurring_transaction(direction)
        if not t:
            return
        self.correct_auto_allocation_selected(direction, t)

    def toggle_recurring_include_selected(self, direction: str):
        idx = self._selected_recurring_index(direction)
        if idx is None:
            messagebox.showinfo(APP_NAME, f"Select one individual {self._noun(direction)} transaction first.")
            return
        t = self._list(direction)[idx]
        t.include = not t.include
        self.refresh_transaction_tree(direction)
        self.refresh_recurring_tree(direction)

    def clear_recurring_transaction_assignment(self, direction: str):
        t = self._selected_recurring_transaction(direction)
        if not t:
            return
        t.rule_id = None
        t.rule_name = ""
        t.account = ""
        t.description = ""
        t.vat = False
        t.tax_type = 0
        t.status = f"Recurring x{t.recurring_count} • unassigned"
        t.manual_override = True
        t.ambiguous = False
        t.auto_allocated = False
        t.amount_condition_applied = False
        self.refresh_transaction_tree(direction)
        self.refresh_recurring_tree(direction)

    def reset_recurring_transaction_to_rule(self, direction: str):
        t = self._selected_recurring_transaction(direction)
        if not t:
            return
        t.manual_override = False
        self.reapply_rules(silent=True)
        self.status_var.set(f"Reset the selected {self._noun(direction)} to its saved-rule result.")

    def set_all_recurring_export(self, direction: str, selected: bool):
        count = 0
        for t in self._list(direction):
            if t.recurring_count >= 2:
                t.include = selected
                count += 1
        self.refresh_transaction_tree(direction)
        self.refresh_recurring_tree(direction)
        self.status_var.set(f"{'Selected' if selected else 'Cleared'} {count} recurring {self._noun(direction, True)} for export.")

    def assign_recurring_rule(self, direction: str):
        key = self._selected_recurring_key(direction)
        if not key:
            return
        idxs = self.recurring_key_to_indices[direction].get(key, [])
        if not idxs:
            return
        txns = self._list(direction)
        selected_idx = self._selected_recurring_index(direction)
        txn = txns[selected_idx] if selected_idx is not None else txns[idxs[0]]
        existing = self._specific_rule_for_key(key, direction)
        dlg = RuleDialog(self, self.store, txn, existing, locked_identity=key)
        dlg.vars["name"].set(existing.name if existing else key)
        self.wait_window(dlg)
        if dlg.result:
            protected = getattr(dlg, "applied_review_transaction_ids", set())
            saved_rule = self._specific_rule_for_key(key, direction)
            if not saved_rule:
                # Defensive fallback: the dialog reported success but no exact
                # identity rule can be read back. Reapply normally and surface a
                # clear status instead of silently leaving orange child rows.
                for i in idxs:
                    if id(txns[i]) not in protected:
                        txns[i].manual_override = False
                self.reapply_rules(silent=True)
                self.status_var.set(f"Saved identity rule for {key}; rule was reapplied through normal matching.")
                return
            default_tax = int(self.store.get_setting("vat_tax_type", "0") or 0)
            direct_idxs = [i for i in idxs if id(txns[i]) not in protected]
            allocated, review = apply_saved_recurring_identity_rule(txns, direct_idxs, key, saved_rule, default_tax)
            self.refresh_transaction_tree(direction)
            self.refresh_recurring_tree(direction)
            self.refresh_rules()
            if review:
                self.status_var.set(f"Saved identity rule for {key}. {allocated} transaction(s) allocated automatically and {review} sent to amount review. Any allocations made inside the rule window were preserved.")
            else:
                self.status_var.set(f"Saved identity rule for {key}. {allocated} matching transaction(s) are now automatic allocations and no longer unassigned.")

    def show_recurring_in_transactions(self, direction: str):
        idx = self._selected_recurring_index(direction)
        target_tab = self.receipt_tab if direction == "RECEIPT" else self.pay_tab
        if idx is not None:
            self.search_vars[direction].set("")
            self.filter_vars[direction].set("All")
            self.repeat_vars[direction].set("— Select repeat description —")
            self.notebook.select(target_tab)
            self.refresh_transaction_tree(direction)
            iid = str(idx)
            tree = self.trees[direction]
            if tree.exists(iid):
                tree.selection_set(iid)
                tree.focus(iid)
                tree.see(iid)
            return

        key = self._selected_recurring_key(direction)
        if not key:
            return
        self.update_repeat_dropdown(direction)
        display = next((d for d, k in self.repeat_display_to_key[direction].items() if k == key), None)
        if display:
            self.repeat_vars[direction].set(display)
        self.filter_vars[direction].set("Recurring")
        self.notebook.select(target_tab)
        self.refresh_transaction_tree(direction)

    def set_recurring_expanded(self, direction: str, expanded: bool):
        tree = self.recurring_trees.get(direction)
        if not tree:
            return
        for pid in tree.get_children(""):
            tree.item(pid, open=expanded)
            for kid in tree.get_children(pid):
                tree.item(kid, open=expanded)

    def refresh_rules(self):
        if not hasattr(self, "rule_tree"):
            return
        self.rule_tree.delete(*self.rule_tree.get_children())
        for r in self.store.all_rules():
            amount_rule = ""
            if r.amount_operator and r.amount_threshold:
                if amount_rule_action(r) == "REVIEW":
                    amount_rule = f"{r.amount_operator} R {r.amount_threshold} → REVIEW EACH"
                elif r.amount_account:
                    amount_rule = f"{r.amount_operator} R {r.amount_threshold} → {r.amount_account}"
                    if r.amount_description:
                        amount_rule += f" • desc: {r.amount_description}"
            self.rule_tree.insert("", "end", iid=str(r.id), values=(r.id, "Receipt" if r.direction == "RECEIPT" else "Payment", r.name, r.mode, r.pattern, r.account, r.description, amount_rule, "Yes" if r.vat else "No", r.tax_type if r.vat else 0, r.pastel_ref, r.priority))

    def edit_rule(self, rule: Optional[Rule], direction: str = "PAYMENT"):
        if rule:
            direction = rule.direction
        if rule is None:
            dlg = RuleDialog(self, self.store, rule=None, direction=direction)
        else:
            dlg = RuleDialog(self, self.store, rule=rule)
        self.wait_window(dlg)
        if dlg.result:
            self.refresh_rules(); self.reapply_rules(silent=True) if (self.txns or self.receipts) else None

    def edit_selected_rule(self):
        sel = self.rule_tree.selection()
        if not sel:
            messagebox.showinfo(APP_NAME, "Select a rule first."); return
        r = self.store.get_rule(int(sel[0]))
        if r:
            self.edit_rule(r)

    def delete_selected_rule(self):
        sel = self.rule_tree.selection()
        if not sel:
            return
        rid = int(sel[0]); r = self.store.get_rule(rid)
        if r and messagebox.askyesno(APP_NAME, f"Delete rule '{r.name}'?\n\nFuture statements will no longer use this mapping."):
            self.store.delete_rule(rid); self.refresh_rules()
            if self.txns or self.receipts:
                self.reapply_rules(silent=True)

    def export_rules(self):
        p = filedialog.asksaveasfilename(title="Export rule backup", defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile="Pastel_Payment_Receipt_Rules_Backup.csv")
        if not p:
            return
        with open(p, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f); w.writerow(["direction", "name", "mode", "pattern", "account", "description", "amount_operator", "amount_threshold", "amount_account", "amount_description", "amount_action", "vat", "tax_type", "pastel_ref", "priority", "enabled"])
            for r in self.store.all_rules():
                w.writerow([r.direction, r.name, r.mode, r.pattern, r.account, r.description, r.amount_operator, r.amount_threshold, r.amount_account, r.amount_description, amount_rule_action(r), int(r.vat), r.tax_type, r.pastel_ref, r.priority, int(r.enabled)])
        messagebox.showinfo(APP_NAME, f"Rules backup saved:\n{p}")

    def import_rules(self):
        p = filedialog.askopenfilename(title="Import rule backup", filetypes=[("CSV", "*.csv")])
        if not p:
            return
        count = 0
        try:
            with open(p, newline="", encoding="utf-8-sig") as f:
                for row in csv.DictReader(f):
                    direction = (row.get("direction") or "PAYMENT").strip().upper()
                    if direction not in self.DIRECTIONS:
                        direction = "PAYMENT"
                    r = Rule(None, row.get("name", "").strip(), row.get("mode", "SMART").strip(), row.get("pattern", "").strip(), row.get("account", "").strip(), row.get("vat", "0").strip() in {"1", "true", "True", "yes", "Yes"}, int(row.get("tax_type", "0") or 0), row.get("pastel_ref", "").strip(), int(row.get("priority", "100") or 100), row.get("enabled", "1").strip() not in {"0", "false", "False"}, direction, row.get("description", "").strip(), row.get("amount_operator", "").strip(), row.get("amount_threshold", "").strip(), row.get("amount_account", "").strip(), row.get("amount_description", "").strip(), (row.get("amount_action", "AUTO") or "AUTO").strip().upper())
                    if r.name and r.pattern and r.account:
                        self.store.save_rule(r); count += 1
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not import rules:\n{e}"); return
        self.refresh_rules()
        if self.txns or self.receipts:
            self.reapply_rules(silent=True)
        messagebox.showinfo(APP_NAME, f"Imported {count} rule(s). Older v1.6 backups are treated as Payment rules.")

    def _combined_validation(self):
        settings = self.settings_dict()
        p_selected = any(t.include for t in self.txns)
        r_selected = any(t.include for t in self.receipts)
        if not p_selected and not r_selected:
            return ["Nothing is selected for export. Tick at least one payment or receipt."], [], settings
        errors, warnings = [], []
        if p_selected:
            e, w = validate_export(self.txns, settings, "payments")
            errors.extend(e); warnings.extend(w)
        if r_selected:
            e, w = validate_export(self.receipts, settings, "receipts")
            errors.extend(e); warnings.extend(w)
        # Keep the report concise when shared settings produce identical messages.
        errors = list(dict.fromkeys(errors)); warnings = list(dict.fromkeys(warnings))
        return errors, warnings, settings

    def show_validation(self):
        if not self.txns and not self.receipts:
            messagebox.showinfo(APP_NAME, "Load a bank CSV first."); return
        self.save_settings(quiet=True)
        errors, warnings, _ = self._combined_validation()
        psel = sum(1 for t in self.txns if t.include); rsel = sum(1 for t in self.receipts if t.include)
        passigned = sum(1 for t in self.txns if t.include and t.account); rassigned = sum(1 for t in self.receipts if t.include and t.account)
        text = f"Payments selected: {psel} ({passigned} assigned)\nReceipts selected: {rsel} ({rassigned} assigned)\n\n"
        if errors:
            text += "ERRORS — export is blocked\n• " + "\n• ".join(errors) + "\n\n"
        else:
            text += "No blocking format errors found for the selected rows.\n\n"
        if warnings:
            text += "WARNINGS / checks\n• " + "\n• ".join(warnings)
        messagebox.showinfo("Pastel pre-import validation", text)

    def _write_review(self, path: Path, txns: List[Transaction], settings: Dict[str, str], direction: str):
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["Source row", "Date", "Bank type", "Bank description/reference", "Pastel description", "Smart/matched key", "Recurring seen count", "Matched rule", "Allocation source", "GL account", "Cash Book bank GL (Pastel column L)", "VAT", "Tax type", "Gross amount", "VAT amount", "Pastel reference", "Pastel period", "Selected for export"])
            rate = D(settings.get("vat_rate", "15")); default_tax = int(settings.get("vat_tax_type", "") or 0); fiscal = int(settings.get("fiscal_start_month", "3"))
            for t in txns:
                tax = int(t.tax_type or default_tax or 0) if t.vat else 0
                allocation_source = "Corrected" if t.status.startswith("Corrected") else ("Auto" if t.auto_allocated else ("Manual" if t.manual_override and t.account else "Unassigned"))
                w.writerow([t.row_no, t.txn_date.strftime("%d/%m/%Y"), t.txn_type, t.details, t.description or t.details, t.match_key, t.recurring_count, t.rule_name, allocation_source, t.account, effective_contra(t, settings), "VAT" if t.vat else "No VAT", tax, money(t.payment_amount), money(calculate_tax(t.payment_amount, t.vat, rate)), t.pastel_ref, period_for_date(t.txn_date, fiscal), "Yes" if t.include else "No"])

    def export_files(self):
        if not self.txns and not self.receipts:
            messagebox.showinfo(APP_NAME, "Load a bank CSV first."); return
        self.save_settings(quiet=True)
        errors, warnings, settings = self._combined_validation()
        if errors:
            messagebox.showerror(APP_NAME, "Export blocked until these issues are fixed:\n\n• " + "\n• ".join(errors)); return
        folder = filedialog.askdirectory(title="Choose folder for Pastel import + review files", initialdir=self.store.get_setting("last_folder", str(Path.home())))
        if not folder:
            return
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        created = []
        p_rows = list(pastel_rows(self.txns, settings)) if any(t.include for t in self.txns) else []
        r_rows = list(pastel_rows(self.receipts, settings)) if any(t.include for t in self.receipts) else []
        if p_rows:
            path = Path(folder) / f"Pastel_Payments_{stamp}.csv"
            with open(path, "w", newline="", encoding="utf-8") as f:
                csv.writer(f, lineterminator="\r\n").writerows(p_rows)
            review = Path(folder) / f"Pastel_Payments_REVIEW_{stamp}.csv"
            self._write_review(review, self.txns, settings, "PAYMENT")
            created.extend([path, review])
        if r_rows:
            path = Path(folder) / f"Pastel_Receipts_{stamp}.csv"
            with open(path, "w", newline="", encoding="utf-8") as f:
                csv.writer(f, lineterminator="\r\n").writerows(r_rows)
            review = Path(folder) / f"Pastel_Receipts_REVIEW_{stamp}.csv"
            self._write_review(review, self.receipts, settings, "RECEIPT")
            created.extend([path, review])
        report_path = Path(folder) / f"Pastel_Selected_Transactions_VALIDATION_{stamp}.txt"
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(f"{APP_NAME} {APP_VERSION}\nPre-import validation report\nProfile: {self.profile_manager.profile_name(self.active_profile_id)}\nGenerated: {datetime.now():%Y-%m-%d %H:%M:%S}\nSource: {self.current_file}\n\n")
            f.write(f"Selected payment rows generated: {len(p_rows)}\nSelected receipt rows generated: {len(r_rows)}\n")
            f.write(f"Cash Book bank GL (Pastel column L): {settings.get('contra_account','')}\nVAT tax type: {settings.get('vat_tax_type','')}\nVAT rate: {settings.get('vat_rate','')}%\nFiscal start month: {settings.get('fiscal_start_month','')}\n\n")
            f.write("BLOCKING ERRORS\n" + ("None\n" if not errors else "\n".join("- " + x for x in errors) + "\n"))
            f.write("\nWARNINGS / MANUAL CHECKS\n" + ("None\n" if not warnings else "\n".join("- " + x for x in warnings) + "\n"))
            f.write("\nOnly rows ticked with ☑ were included in the Pastel import files. Import Payments and Receipts into their respective cash-book sides, review, then Update/Process.\n")
        created.append(report_path)
        self.store.set_setting("last_folder", folder)
        msg = f"Created {len(p_rows)} selected Payment row(s) and {len(r_rows)} selected Receipt row(s).\n\n"
        if p_rows:
            msg += f"Payments: Pastel_Payments_{stamp}.csv\n"
        if r_rows:
            msg += f"Receipts: Pastel_Receipts_{stamp}.csv\n"
        msg += f"Validation: {report_path.name}\n\nOnly checked rows were exported. Review each imported Pastel batch before Update/Process."
        if warnings:
            msg += "\n\nWarnings to review:\n• " + "\n• ".join(warnings)
        messagebox.showinfo(APP_NAME, msg)
        try:
            if os.name == "nt": os.startfile(folder)
            elif sys.platform == "darwin": subprocess.Popen(["open", folder])
            else: subprocess.Popen(["xdg-open", folder])
        except Exception:
            pass

    def on_close(self):
        try:
            self._persist_profile_settings()
            self.store.conn.close()
        except Exception:
            pass
        self.destroy()

    def on_close(self):
        """Autosave the complete active-profile session before the window closes."""
        try:
            self._save_session()
            self._persist_profile_settings()
            self.store.conn.close()
        except Exception:
            pass
        self.destroy()

def self_test(statement_path: Optional[str] = None) -> str:
    assert smart_key("HOLLARD   HOL5910923    260601") == "HOLLARD 0923"
    assert smart_key("HOLLARD HOL5986957 260530") == "HOLLARD 6957"
    assert smart_key("VODACOM 0489030492 B0003783") == "VODACOM 3783"
    assert calculate_tax(Decimal("115.00"), True, Decimal("15")) == Decimal("15.00")

    # Per-reference payment rules remain independent.
    p1 = Transaction(1, date(2026, 8, 1), Decimal("-1200"), "INSURANCE PREMIUM", "HOLLARD HOL5986957 260801")
    p2 = Transaction(2, date(2026, 8, 1), Decimal("-1300"), "INSURANCE PREMIUM", "HOLLARD HOL5910923 260801")
    prules = [
        Rule(1, "HOLLARD 6957", "SMART", "HOLLARD 6957", "7100001", False, 0, direction="PAYMENT"),
        Rule(2, "HOLLARD 0923", "SMART", "HOLLARD 0923", "7100002", True, 1, direction="PAYMENT"),
    ]
    apply_rules([p1, p2], prules, 1)
    assert [p1.account, p2.account] == ["7100001", "7100002"]

    # v1.11.1: strict identity matching prevents similar-name false allocations.
    assert smart_match("C E BRINK", "PAYMENT TO C E BRINK", "EFT PAYMENT")
    assert not smart_match("C E BRINK", "CHRIS BRINK", "EFT PAYMENT")
    assert not smart_match("CHRIS BRINK", "C E BRINK", "EFT PAYMENT")
    assert smart_match("C E BRINK 1234", "PAYMENT C E BRINK REF1234", "EFT PAYMENT")
    assert not smart_match("C E BRINK 1234", "PAYMENT C E BRINK REF5678", "EFT PAYMENT")
    false_name = Transaction(90, date(2026, 8, 4), Decimal("-100.00"), "EFT PAYMENT", "CHRIS BRINK", direction="PAYMENT")
    ce_rule = Rule(90, "C E BRINK", "SMART", "C E BRINK", "7100099", False, 0, direction="PAYMENT")
    apply_rules([false_name], [ce_rule], 0)
    assert false_name.account == "" and not false_name.auto_allocated

    # v1.11.2: strict identity protection applies to ALL rule modes and directions.
    for test_mode in ("SMART", "CONTAINS", "STARTS", "EXACT"):
        bad_payment = Transaction(101, date(2026, 8, 5), Decimal("-100.00"), "EFT PAYMENT", "CHRIS BRINK", direction="PAYMENT")
        ce_payment_rule = Rule(101, "C E BRINK", test_mode, "C E BRINK", "7100099", False, 0, direction="PAYMENT")
        apply_rules([bad_payment], [ce_payment_rule], 0)
        assert bad_payment.account == "" and not bad_payment.auto_allocated, test_mode

        bad_receipt = Transaction(102, date(2026, 8, 5), Decimal("100.00"), "EFT RECEIPT", "CHRIS BRINK", direction="RECEIPT")
        ce_receipt_rule = Rule(102, "C E BRINK", test_mode, "C E BRINK", "4100099", False, 0, direction="RECEIPT")
        apply_rules([bad_receipt], [ce_receipt_rule], 0)
        assert bad_receipt.account == "" and not bad_receipt.auto_allocated, test_mode

    # Reference mismatches are blocked globally too, even for loose modes.
    for test_mode in ("SMART", "CONTAINS", "STARTS"):
        wrong_ref = Transaction(103, date(2026, 8, 5), Decimal("-200.00"), "EFT PAYMENT", "C E BRINK REF5678", direction="PAYMENT")
        ref_rule = Rule(103, "C E BRINK 1234", test_mode, "C E BRINK 1234", "7100088", False, 0, direction="PAYMENT")
        apply_rules([wrong_ref], [ref_rule], 0)
        assert wrong_ref.account == "" and not wrong_ref.auto_allocated, test_mode

    # v1.11.3: amount-based allocation can use its own alternative description.
    alt_small = Transaction(130, date(2026, 8, 6), Decimal("-450.00"), "DEBIT", "ALT DESC TEST 5555", direction="PAYMENT")
    alt_large = Transaction(131, date(2026, 8, 6), Decimal("-750.00"), "DEBIT", "ALT DESC TEST 5555", direction="PAYMENT")
    alt_rule = Rule(130, "ALT DESC 5555", "SMART", "ALT DESC TEST 5555", "7100001", False, 0, direction="PAYMENT", description="Normal description", amount_operator="<", amount_threshold="500.00", amount_account="7200001", amount_description="Small payment description")
    apply_rules([alt_small, alt_large], [alt_rule], 0)
    assert alt_small.account == "7200001" and alt_small.description == "Small payment description" and alt_small.amount_condition_applied
    assert alt_large.account == "7100001" and alt_large.description == "Normal description" and not alt_large.amount_condition_applied

    # v1.11.4: qualifying amount rules can require one-at-a-time review instead of blanket allocation.
    review_small = Transaction(140, date(2026, 8, 7), Decimal("-250.00"), "DEBIT", "FUEL CARD 7788", direction="PAYMENT")
    review_large = Transaction(141, date(2026, 8, 7), Decimal("-850.00"), "DEBIT", "FUEL CARD 7788", direction="PAYMENT")
    review_rule = Rule(140, "FUEL CARD 7788", "SMART", "FUEL CARD 7788", "7100001", False, 0, direction="PAYMENT", description="Normal card spend", amount_operator="<", amount_threshold="500.00", amount_action="REVIEW")
    apply_rules([review_small, review_large], [review_rule], 0)
    assert review_small.account == "" and not review_small.auto_allocated and review_small.amount_condition_applied
    assert review_small.status.startswith("Amount review required") and review_small.rule_id == 140
    assert review_large.account == "7100001" and review_large.auto_allocated and not review_large.amount_condition_applied

    review_receipt = Transaction(142, date(2026, 8, 7), Decimal("200.00"), "CREDIT", "MISC RECEIPT 8899", direction="RECEIPT")
    review_receipt_rule = Rule(142, "MISC RECEIPT 8899", "SMART", "MISC RECEIPT 8899", "4100001", False, 0, direction="RECEIPT", amount_operator="<", amount_threshold="500.00", amount_action="REVIEW")
    apply_rules([review_receipt], [review_receipt_rule], 0)
    assert review_receipt.account == "" and not review_receipt.auto_allocated and review_receipt.status.startswith("Amount review required")

    # v1.11.5: calendar-month sequential Pastel references are unique per transaction.
    june_refs = [
        Transaction(30, date(2026, 6, 1), Decimal("-100.00"), "PAYMENT", "JUNE ONE A", direction="PAYMENT"),
        Transaction(31, date(2026, 6, 1), Decimal("-200.00"), "PAYMENT", "JUNE ONE B", direction="PAYMENT"),
        Transaction(32, date(2026, 6, 2), Decimal("-300.00"), "PAYMENT", "JUNE TWO", direction="PAYMENT"),
        Transaction(33, date(2026, 7, 1), Decimal("-400.00"), "PAYMENT", "JULY ONE", direction="PAYMENT"),
    ]
    june_receipts = [
        Transaction(34, date(2026, 6, 1), Decimal("500.00"), "RECEIPT", "JUNE RECEIPT A", direction="RECEIPT"),
        Transaction(35, date(2026, 6, 1), Decimal("600.00"), "RECEIPT", "JUNE RECEIPT B", direction="RECEIPT"),
    ]
    assign_monthly_sequential_references(june_refs + june_receipts)
    assert [t.pastel_ref for t in june_refs] == ["P6-0001", "P6-0002", "P6-0003", "P7-0001"]
    assert [t.pastel_ref for t in june_receipts] == ["R6-0001", "R6-0002"]
    assert len({t.pastel_ref for t in june_refs}) == len(june_refs)
    assert len({t.pastel_ref for t in june_receipts}) == len(june_receipts)

    # A saved rule reference must never override the unique transaction sequence.
    ref_override_a = Transaction(36, date(2026, 6, 3), Decimal("-10.00"), "PAYMENT", "REF OVERRIDE 7777", direction="PAYMENT")
    ref_override_b = Transaction(37, date(2026, 6, 3), Decimal("-20.00"), "PAYMENT", "REF OVERRIDE 7777", direction="PAYMENT")
    duplicate_ref_rule = Rule(36, "REF OVERRIDE", "SMART", "REF OVERRIDE 7777", "7100001", False, 0, pastel_ref="SAME", direction="PAYMENT")
    apply_rules([ref_override_a, ref_override_b], [duplicate_ref_rule], 0)
    assign_monthly_sequential_references([ref_override_a, ref_override_b])
    assert [ref_override_a.pastel_ref, ref_override_b.pastel_ref] == ["P6-0001", "P6-0002"]

    # v1.11.6: company profiles keep rules/settings/history in separate databases.
    import tempfile
    with tempfile.TemporaryDirectory() as profile_td:
        profile_root = Path(profile_td)
        legacy_db = profile_root / "pastel_payment_assistant.db"
        pm = ProfileManager(profile_root, legacy_db)
        assert pm.active_id == "default"
        assert pm.db_path("default") == legacy_db
        company_b = pm.create_profile("Company B")
        assert pm.db_path(company_b) != pm.db_path("default")
        default_store = Store(pm.db_path("default"))
        company_store = Store(pm.db_path(company_b))
        default_store.set_setting("contra_account", "1100000")
        company_store.set_setting("contra_account", "1200000")
        default_store.save_rule(Rule(None, "DEFAULT ONLY", "SMART", "DEFAULT ONLY 1234", "7100001", False, 0, direction="PAYMENT"))
        company_store.save_rule(Rule(None, "COMPANY B ONLY", "SMART", "COMPANY B 5678", "7200001", False, 0, direction="PAYMENT"))
        assert default_store.get_setting("contra_account") == "1100000"
        assert company_store.get_setting("contra_account") == "1200000"
        assert [r.name for r in default_store.all_rules()] == ["DEFAULT ONLY"]
        assert [r.name for r in company_store.all_rules()] == ["COMPANY B ONLY"]
        default_store.conn.close(); company_store.conn.close()
        pm.set_active(company_b)
        pm_again = ProfileManager(profile_root, legacy_db)
        assert pm_again.active_id == company_b
        pm_again.rename_profile(company_b, "Second Company")
        assert pm_again.profile_name(company_b) == "Second Company"
        pm_again.delete_profile(company_b)
        assert pm_again.active_id == "default" and pm_again.id_for_name("Second Company") is None

    # v1.11.7: one or many amount-review rows can be assigned together, without changing unselected review rows.
    petrol_a = Transaction(170, date(2026, 6, 1), Decimal("-100.00"), "DEBIT", "CARD SPEND A", direction="PAYMENT", status="Amount review required • amount < R 500.00")
    petrol_b = Transaction(171, date(2026, 6, 1), Decimal("-120.00"), "DEBIT", "CARD SPEND B", direction="PAYMENT", status="Amount review required • amount < R 500.00")
    petrol_c = Transaction(172, date(2026, 6, 1), Decimal("-140.00"), "DEBIT", "CARD SPEND C", direction="PAYMENT", status="Amount review required • amount < R 500.00")
    survey = Transaction(173, date(2026, 6, 1), Decimal("-160.00"), "DEBIT", "CARD SPEND D", direction="PAYMENT", status="Amount review required • amount < R 500.00")
    assert apply_review_assignment([petrol_a, petrol_b, petrol_c], "PETROL", "Petrol", False, 0) == 3
    assert [petrol_a.account, petrol_b.account, petrol_c.account] == ["PETROL", "PETROL", "PETROL"]
    assert survey.account == "" and survey.status.startswith("Amount review required")
    assert apply_review_assignment([survey], "SURVEY", "Survey", False, 0) == 1
    assert survey.account == "SURVEY" and survey.description == "Survey"

    # v1.11.8: the Rule window lists only matching transactions caught by the amount condition.
    rw_a = Transaction(180, date(2026, 6, 1), Decimal("-1610.00"), "DEBIT", "C VAN HEERDEN", direction="PAYMENT")
    rw_b = Transaction(181, date(2026, 6, 1), Decimal("-1778.65"), "DEBIT", "C VAN HEERDEN", direction="PAYMENT")
    rw_c = Transaction(182, date(2026, 6, 2), Decimal("-48452.10"), "DEBIT", "C VAN HEERDEN", direction="PAYMENT")
    rw_other = Transaction(183, date(2026, 6, 1), Decimal("-1200.00"), "DEBIT", "OTHER SUPPLIER", direction="PAYMENT")
    rw_candidates = rule_window_amount_candidates([rw_a, rw_b, rw_c, rw_other], "PAYMENT", "SMART", "C VAN HEERDEN", "<", "45000.00")
    assert [idx for idx, _t in rw_candidates] == [0, 1]
    assert apply_rule_window_manual_assignment([rw_a, rw_b], "3270000", "PETROL", False, 0) == 2
    assert rw_a.account == "3270000" and rw_b.account == "3270000" and rw_a.description == "PETROL"
    assert rw_c.account == "" and rw_other.account == ""
    assert apply_rule_window_manual_assignment([rw_c], "4400010", "SURVEY", False, 0) == 1
    assert rw_c.account == "4400010" and rw_c.description == "SURVEY"

    # v1.11.13: manual allocation selection classification.
    manual_pick = Transaction(713, date(2026, 8, 22), Decimal("-100.00"), "DEBIT", "MANUAL PICK 713", direction="PAYMENT")
    manual_pick.account = "7000001"
    manual_pick.manual_override = True
    assert manual_pick.manual_override and manual_pick.account and not manual_pick.ambiguous
    auto_not_manual = Transaction(714, date(2026, 8, 22), Decimal("-100.00"), "DEBIT", "AUTO PICK 714", direction="PAYMENT")
    auto_not_manual.account = "7000002"
    auto_not_manual.auto_allocated = True
    assert not auto_not_manual.manual_override
    ambiguous_manual = Transaction(715, date(2026, 8, 22), Decimal("-100.00"), "DEBIT", "AMBIG PICK 715", direction="PAYMENT")
    ambiguous_manual.account = "7000003"
    ambiguous_manual.manual_override = True
    ambiguous_manual.ambiguous = True
    assert not (ambiguous_manual.manual_override and ambiguous_manual.account and not ambiguous_manual.ambiguous)

    # v1.11.14: auto and manual selection are additive rather than exclusive.
    additive_auto = Transaction(814, date(2026, 8, 22), Decimal("-100.00"), "DEBIT", "ADDITIVE AUTO 814", direction="PAYMENT")
    additive_auto.account = "7000014"
    additive_auto.auto_allocated = True
    additive_auto.include = True
    additive_manual = Transaction(815, date(2026, 8, 22), Decimal("-100.00"), "DEBIT", "ADDITIVE MANUAL 815", direction="PAYMENT")
    additive_manual.account = "7000015"
    additive_manual.manual_override = True
    additive_manual.include = False
    # Selecting manual after auto must preserve the already-selected auto row.
    if additive_manual.manual_override and additive_manual.account and not additive_manual.ambiguous:
        additive_manual.include = True
    assert additive_auto.include and additive_manual.include
    # Selecting auto after manual must likewise preserve the manual row.
    additive_auto.include = False
    additive_manual.include = True
    if additive_auto.auto_allocated and additive_auto.account and not additive_auto.ambiguous:
        additive_auto.include = True
    assert additive_auto.include and additive_manual.include

    # v1.11.16: saving a recurring identity rule immediately allocates its child rows.
    identity_rows = [
        Transaction(916, date(2026, 6, 1), Decimal("-50.00"), "DEBIT", "STOP ORDER HANDLING FEE", direction="PAYMENT"),
        Transaction(917, date(2026, 6, 25), Decimal("-50.00"), "DEBIT", "STOP ORDER HANDLING FEE", direction="PAYMENT"),
    ]
    identity_key = smart_key(identity_rows[0].details, identity_rows[0].txn_type)
    identity_rule = Rule(916, "STOP ORDER FEE", "SMART", identity_key, "3200000", True, 15, direction="PAYMENT", description="FEE")
    got_allocated, got_review = apply_saved_recurring_identity_rule(identity_rows, [0, 1], identity_key, identity_rule, 15)
    assert got_allocated == 2 and got_review == 0
    assert all(t.account == "3200000" and t.auto_allocated and not t.manual_override and not t.ambiguous for t in identity_rows)
    assert all(t.vat and t.tax_type == 15 and t.description == "FEE" for t in identity_rows)

    # v1.11.17: Standard Bank bank-charge rows may have blank details.
    # Only an exact canonical transaction-type identity is allowed in that case.
    stop_fee = Transaction(1017, date(2026, 6, 1), Decimal("-50.00"), "STOP ORDER HANDLING FEE", "", direction="PAYMENT")
    stop_rule = Rule(1017, "STOP ORDER FEE", "SMART", "STOP ORDER HANDLING FEE", "3200000", True, 15, direction="PAYMENT", description="FEE")
    assert rule_matches(stop_rule.mode, stop_rule.pattern, stop_fee.details, stop_fee.txn_type)
    apply_rules([stop_fee], [stop_rule], 15)
    assert stop_fee.account == "3200000" and stop_fee.auto_allocated and stop_fee.vat and stop_fee.tax_type == 15
    assert stop_fee.description == "FEE"

    # The blank-detail fallback is exact-canonical only; similar/generic patterns
    # must not match merely because they appear in the transaction type.
    assert not rule_matches("SMART", "STOP ORDER", "", "STOP ORDER HANDLING FEE")
    assert not rule_matches("CONTAINS", "HANDLING", "", "STOP ORDER HANDLING FEE")
    assert not rule_matches("STARTS", "STOP", "", "STOP ORDER HANDLING FEE")
    assert not rule_matches("EXACT", "STOP ORDER FEE", "", "STOP ORDER HANDLING FEE")

    # v1.11.18: Pastel cash-book import signs must make bank receipts positive.
    sign_settings = {"project_code":"", "fiscal_start_month":"3", "vat_rate":"15", "vat_tax_type":"15", "contra_account":""}
    sign_payment = Transaction(1118, date(2026, 6, 3), Decimal("-100000.00"), "PAYMENT", "PAYMENT SIGN TEST", direction="PAYMENT")
    sign_payment.account = "9800000"
    sign_payment.include = True
    sign_receipt = Transaction(1119, date(2026, 6, 3), Decimal("100000.00"), "RECEIPT", "RECEIPT SIGN TEST", direction="RECEIPT")
    sign_receipt.account = "9800000"
    sign_receipt.include = True
    prow = list(pastel_rows([sign_payment], sign_settings))[0]
    rrow = list(pastel_rows([sign_receipt], sign_settings))[0]
    assert prow[6] == "100000.00" and prow[17] == "100000.00"
    assert rrow[6] == "-100000.00" and rrow[17] == "-100000.00"

    # VAT/tax follows the same GL-side credit sign for receipts and must not
    # produce a spurious -0.00 when no VAT applies.
    vat_receipt = Transaction(1120, date(2026, 6, 4), Decimal("115.00"), "RECEIPT", "VAT RECEIPT SIGN TEST", direction="RECEIPT")
    vat_receipt.account = "4000000"
    vat_receipt.include = True
    vat_receipt.vat = True
    vat_receipt.tax_type = 15
    vat_row = list(pastel_rows([vat_receipt], sign_settings))[0]
    assert vat_row[6] == "-115.00" and vat_row[8] == "-15.00" and vat_row[17] == "-115.00"
    assert rrow[8] == "0.00"

    # v1.11.19: autosaved transaction snapshots preserve manual/auto/export state.
    session_probe = Transaction(1119, date(2026, 8, 22), Decimal("123.45"), "RECEIPT", "SESSION TEST", direction="RECEIPT")
    session_probe.include = False
    session_probe.rule_id = 77
    session_probe.rule_name = "Saved rule"
    session_probe.account = "9800000"
    session_probe.description = "RESTORED DESC"
    session_probe.vat = True
    session_probe.tax_type = 15
    session_probe.match_key = "SESSION TEST"
    session_probe.pastel_ref = "R8-0001"
    session_probe.status = "Corrected allocation • this statement only"
    session_probe.manual_override = True
    session_probe.recurring_count = 3
    session_probe.previously_seen = True
    session_probe.auto_allocated = False
    restored_probe = transaction_from_session_dict(transaction_to_session_dict(session_probe))
    assert restored_probe.txn_date == session_probe.txn_date and restored_probe.amount == session_probe.amount
    assert restored_probe.direction == "RECEIPT" and not restored_probe.include
    assert restored_probe.account == "9800000" and restored_probe.description == "RESTORED DESC"
    assert restored_probe.vat and restored_probe.tax_type == 15 and restored_probe.manual_override
    assert restored_probe.status == session_probe.status and restored_probe.recurring_count == 3 and restored_probe.previously_seen

    # v1.11.20: verified Mary Hartslief bank variants are one recurring payee.
    mary_rows = [
        Transaction(58, date(2026, 6, 12), Decimal("-4000.00"), "IB PAYMENT TO", "MARY HARTSLIEF PCASH", direction="PAYMENT"),
        Transaction(114, date(2026, 6, 25), Decimal("-21515.63"), "IB PAYMENT TO", "MARY HARTSLIEF", direction="PAYMENT"),
        Transaction(133, date(2026, 6, 26), Decimal("-2000.00"), "IMMEDIATE PAYMENT", "299478576 MARY HARTSLIEF", direction="PAYMENT"),
        Transaction(200, date(2026, 7, 6), Decimal("-2000.00"), "IMMEDIATE PAYMENT", "300309850 MARY HARTSLIEF", direction="PAYMENT"),
        Transaction(225, date(2026, 7, 13), Decimal("-4000.00"), "IB PAYMENT TO", "MARY HARTSLIEF PETTY CASH", direction="PAYMENT"),
        Transaction(280, date(2026, 7, 24), Decimal("-20515.63"), "IMMEDIATE PAYMENT", "301673371 MARY HARTSLIEF", direction="PAYMENT"),
    ]
    # The stricter rule/matching key remains untouched and still sees variants;
    # only recurrence grouping collapses the verified payee aliases.
    assert len({smart_key(t.details, t.txn_type) for t in mary_rows}) >= 4
    assert {recurring_identity_key(t.details, t.txn_type) for t in mary_rows} == {"MARY HARTSLIEF"}
    with tempfile.TemporaryDirectory() as td:
        mary_store = Store(Path(td) / "mary.db")
        mary_store.remember_transactions(mary_rows)
        assert all(t.recurring_count == 6 for t in mary_rows)
        assert len(mary_store.recurring_summary("PAYMENT")) == 1
        mary_store.conn.close()

    # Grouping must not alter individual allocations: different Mary rows can
    # still carry different manual GLs while appearing under one recurring payee.
    mary_rows[0].account = "7100001"
    mary_rows[0].manual_override = True
    mary_rows[1].account = "7200002"
    mary_rows[1].manual_override = True
    assert mary_rows[0].account != mary_rows[1].account

    # v1.11.21: Modern UI is the default, while Classic remains available.
    assert DEFAULT_UI_MODE == "modern"
    assert UI_MODES == {"modern", "classic"}

    # v1.11.22: adaptive, searchable tutorial behavior.
    empty_snap = {"loaded": False, "payments": 0, "receipts": 0, "selected": 0, "assigned": 0, "unassigned": 0, "ambiguous": 0, "recurring": 0, "rules": 0, "history": 0, "settings_ready": False, "has_activity": False}
    empty_path = adaptive_tutorial_topic_ids(empty_snap)
    assert empty_path[0:2] == ["workflow", "profiles"] and "settings" in empty_path and "load" in empty_path and "export" in empty_path
    active_snap = dict(empty_snap, loaded=True, payments=10, receipts=3, selected=7, assigned=5, unassigned=2, ambiguous=1, recurring=4, rules=8, history=20, settings_ready=True, has_activity=True)
    active_path = adaptive_tutorial_topic_ids(active_snap)
    assert "settings" not in active_path and "load" not in active_path and "orange" in active_path and "ambiguous" in active_path and "recurring" in active_path
    assert search_tutorial_topics("orange transaction")[0]["id"] == "orange"
    assert search_tutorial_topics("receipt negative")[0]["id"] == "receipt_sign"
    assert search_tutorial_topics("wrong gl")[0]["id"] == "wrong_gl"
    assert search_tutorial_topics("recurring missing")[0]["id"] in {"recurring_missing", "recurring"}

    # Receipt and payment rules with the same description must never cross-apply.
    rec = Transaction(3, date(2026, 8, 2), Decimal("2500"), "DEPOSIT", "CLIENT ABC 1234", direction="RECEIPT")
    pay_same = Transaction(4, date(2026, 8, 2), Decimal("-500"), "PAYMENT", "CLIENT ABC 1234", direction="PAYMENT")
    rr = Rule(3, "CLIENT ABC 1234", "SMART", "CLIENT ABC 1234", "4000001", False, 0, direction="RECEIPT")
    apply_rules([rec, pay_same], [rr])
    assert rec.account == "4000001" and pay_same.account == ""

    # Checkbox/export selection: unticked rows are omitted without affecting saved rules.
    p1.include = False
    settings = {"contra_account":"1100000", "project_code":"", "fiscal_start_month":"3", "vat_rate":"15", "vat_tax_type":"1"}
    rows = list(pastel_rows([p1, p2], settings))
    assert len(rows) == 1 and rows[0][6] == "1300.00" and rows[0][11] == "1100000" and len(rows[0]) == 18
    rec.account = "4000001"
    rrows = list(pastel_rows([rec], settings))
    assert len(rrows) == 1 and rrows[0][6] == "-2500.00" and rrows[0][17] == "-2500.00" and rrows[0][11] == "1100000" and len(rrows[0]) == 18

    # Direction-aware persistence and recurrence history.
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        st = Store(Path(td) / "test.db")
        oldpay = st.save_rule(Rule(None, "PAY RULE", "SMART", "CLIENT ABC 1234", "5000001", False, 0, direction="PAYMENT"))
        newrec = st.save_rule(Rule(None, "REC RULE", "SMART", "CLIENT ABC 1234", "4000001", False, 0, direction="RECEIPT"))
        assert st.get_rule(oldpay).direction == "PAYMENT"
        assert st.get_rule(newrec).direction == "RECEIPT"
        assert len(st.rules("PAYMENT")) == 1 and len(st.rules("RECEIPT")) == 1
        r1 = Transaction(1, date(2026, 6, 1), Decimal("100"), "DEPOSIT", "CLIENT ABC 1234", source="june.csv", direction="RECEIPT")
        st.remember_transactions([r1]); assert r1.recurring_count == 1
        r2 = Transaction(1, date(2026, 7, 1), Decimal("175"), "DEPOSIT", "CLIENT ABC 1234", source="july.csv", direction="RECEIPT")
        st.remember_transactions([r2]); assert r2.recurring_count == 2
        st.conn.close()

    # v1.11: amount-based allocation, descriptions and auto-allocation state.
    small = Transaction(20, date(2026, 8, 3), Decimal("-450.00"), "DEBIT", "TEST MERCHANT 5555", direction="PAYMENT")
    large = Transaction(21, date(2026, 8, 3), Decimal("-750.00"), "DEBIT", "TEST MERCHANT 5555", direction="PAYMENT")
    amount_rule = Rule(20, "TEST 5555", "SMART", "TEST 5555", "7100001", False, 0, "5555", 100, True, "PAYMENT", "Test payment", "<", "500.00", "7200001")
    apply_rules([small, large], [amount_rule], 0)
    assert small.account == "7200001" and small.amount_condition_applied and small.auto_allocated
    assert large.account == "7100001" and not large.amount_condition_applied and large.auto_allocated
    assert small.description == "Test payment"
    test_settings = {"project_code":"", "fiscal_start_month":"3", "vat_rate":"15", "vat_tax_type":"", "contra_account":""}
    assert list(pastel_rows([small], test_settings))[0][5] == "Test payment"

    out = ["Core rules, descriptions, amount-based allocation, auto-allocation state, selection-only export, VAT and recurrence tests passed."]
    if statement_path:
        payments, receipts, parser = BankCSVParser.load(statement_path)
        assert len(payments) == 294, len(payments)
        assert len(receipts) == 32, len(receipts)
        out.append(f"Parsed {len(payments)} outgoing payments and {len(receipts)} incoming receipts using {parser}.")
    return "\n".join(out)


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        p = next((x for x in sys.argv[1:] if x != "--self-test"), None)
        print(self_test(p))
    else:
        App().mainloop()
