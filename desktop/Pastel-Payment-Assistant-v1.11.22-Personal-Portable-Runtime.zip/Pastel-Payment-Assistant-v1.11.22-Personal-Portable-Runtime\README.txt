﻿Pastel Payment Assistant v1.11.22 Personal - Portable Runtime Edition

This edition does NOT use PyInstaller. It runs the same verified v1.11.22 Personal application source with a bundled Python 3.12 runtime and Tkinter.

START
Double-click: Start Pastel Payment Assistant.cmd

Keep the entire extracted folder together. No separate Python installation is required.

YOUR EXISTING SETTINGS AND RULES ARE PRESERVED
This package uses the SAME Personal workspace as v1.11.20 and v1.11.22:
  %APPDATA%\PastelPaymentAssistant

It does not create a new Personal data namespace. Existing company profiles, saved rules, settings, transaction history and autosaved session remain in the same location.

SECURITY
The launcher invokes the bundled pythonw.exe directly and there is no PyInstaller-packed Pastel executable.
Endpoint security can still enforce its own policies, so no packaging method can guarantee that every security product will allow execution.

Application functionality remains v1.11.22 Personal, including Modern/Classic UI and Tutorial & Help.
