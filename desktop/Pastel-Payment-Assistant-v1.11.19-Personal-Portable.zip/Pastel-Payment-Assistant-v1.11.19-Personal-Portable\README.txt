Pastel Payment Assistant v1.11.19 Personal - Portable Windows

No Python installation is required. Keep the entire folder together.
Run: Pastel Payment Assistant v1.11.19 Personal.exe

Personal build behavior:
- Uses the normal PastelPaymentAssistant AppData location, preserving existing company profiles, rules, settings and history on the same PC.
- Autosaves the full active-profile session whenever the app closes and restores it on the next launch.
- Session snapshot includes transactions, manual/corrected allocations, export ticks, search/filter/sort state, recurring view state and active tab.
- A private bundle may place Pastel_Payment_Receipt_Rules_Backup.csv beside the EXE. It is imported only when the active profile has zero rules; existing rules are never overwritten.
- Receipts are exported with the GL-side credit sign required for a positive Bank Amount on Pastel Receipts.
- STOP ORDER HANDLING FEE blank-description matching fix remains included.
