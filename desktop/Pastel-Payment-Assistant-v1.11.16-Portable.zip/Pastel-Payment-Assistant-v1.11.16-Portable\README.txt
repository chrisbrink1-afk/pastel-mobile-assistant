Pastel Payment Assistant v1.11.16 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.16.exe

v1.11.16 recurring-rule fix:
- Saving or editing a recurring identity rule immediately applies that rule to every matching child transaction in that exact identity.
- Child rows inherit GL, VAT, tax type, description and saved-rule status instead of remaining orange/unassigned.
- The direct application is limited to the exact recurring identity selected in the recurring screen.
- Amount-review rules still send qualifying transactions to review rather than auto-allocating them.
- Auto and Manual quick-select actions remain additive.
- User-friendly grouped controls and hover ? help remain available.
