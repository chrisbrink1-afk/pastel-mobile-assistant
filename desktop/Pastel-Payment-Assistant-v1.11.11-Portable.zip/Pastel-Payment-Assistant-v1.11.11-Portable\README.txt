Pastel Payment Assistant v1.11.11 - Portable Windows

No Python installation is required.
Keep the extracted folder together.
Run: Pastel Payment Assistant v1.11.11.exe

Rule window improvements:
- Assign Payment Rule / Assign Receipt Rule is resizable in both directions.
- Vertical and horizontal scrollbars provide access to every field if the window is constrained.
- The amount-review transaction table expands when more space is available.
- The always-visible Assign selected control is retained.
