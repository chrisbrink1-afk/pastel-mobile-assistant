Pastel Payment Assistant v1.11.22 Personal - Portable Windows

Run: Pastel Payment Assistant v1.11.22 Personal.exe
No Python installation is required. Keep the entire extracted folder together.

Tutorial & Help:
- Opens automatically only for a genuinely new/empty workspace.
- Existing Personal users are not forced through onboarding.
- Skip, Back, Next and Finish are available.
- Re-scan my progress adapts the tutorial to current settings, rules and statement progress.
- Search accepts normal problem terms such as orange transaction, wrong GL, VAT, recurring missing, receipt negative, export and autosave.
- Tutorial & Help can be launched at any time from Modern or Classic UI.
- Launching from Classic temporarily uses Modern guidance and returns to Classic when closed.

Compatibility:
- Uses existing PastelPaymentAssistant AppData and preserves Personal profiles/rules/settings/history/session.
- Modern UI is default; Classic previous UI remains available.
- Receipt sign, blank-description STOP ORDER, Mary Hartslief recurrence, additive selection, strict matching and autosave fixes are retained.
