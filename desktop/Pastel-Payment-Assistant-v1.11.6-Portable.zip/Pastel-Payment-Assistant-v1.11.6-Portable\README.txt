Pastel Payment Assistant v1.11.6 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.6.exe

Built using the same PyInstaller --onedir --windowed packaging method as v1.10.

v1.11.6 company profiles:
- The existing app database becomes the Default profile automatically, preserving current rules/settings/history.
- Create additional company profiles from the top Profile selector.
- Every profile has its own saved allocation rules, settings, transaction history/recurring detection, amount rules and account lists.
- Switching profiles clears the currently loaded bank statement to prevent cross-company allocation mistakes.
- New profiles start empty and can import their own rules/settings backups if needed.
- Profiles can be renamed. Non-default profiles can be deleted after confirmation.
- The Default profile cannot be deleted because it preserves the original app database, but it can be renamed.

Retained features:
- v1.11.5 unique monthly Pastel references such as P6-0001 / R6-0001.
- Multiple same-date transactions receive different consecutive references.
- v1.11.4 per-transaction amount review mode.
- v1.11.3 alternative amount descriptions.
- v1.11.2 global strict name/reference allocation safety for all payments and receipts.
