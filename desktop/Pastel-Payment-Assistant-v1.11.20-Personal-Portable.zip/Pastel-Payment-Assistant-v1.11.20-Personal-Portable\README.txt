Pastel Payment Assistant v1.11.20 Personal - Portable Windows

No Python installation is required. Keep the entire folder together.
Run: Pastel Payment Assistant v1.11.20 Personal.exe

v1.11.20 recurrence improvement:
- Verified Mary Hartslief variants from the supplied Standard Bank statement are grouped as one recurring payee: MARY HARTSLIEF.
- Changing Immediate Payment bank reference numbers and PCASH/PETTY CASH wording no longer split that recurring payee.
- This affects recurrence grouping/history only; strict automatic-allocation matching remains separate.
- Individual transactions within the recurring payee can still have different manual GL/VAT/description allocations.
- Existing autosaved v1.11.19 sessions recalculate recurrence automatically on launch.
- Existing profiles/rules/settings/history are preserved in the normal v1.x AppData location.
- Receipt sign fix remains included so money into the bank shows positive on Pastel Receipts.
