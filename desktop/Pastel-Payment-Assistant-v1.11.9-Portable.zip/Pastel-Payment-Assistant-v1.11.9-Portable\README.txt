Pastel Payment Assistant v1.11.9 - Portable Windows

No Python installation is required.
Keep the extracted folder together.
Run: Pastel Payment Assistant v1.11.9.exe

Amount review allocation fix:
- In the Rule window, the allocation toolbar is above the transaction table.
- Tick one or more qualifying transactions.
- The button shows Assign selected (N).
- Click it to allocate exactly those selected rows.
- Unselected qualifying transactions remain untouched.
