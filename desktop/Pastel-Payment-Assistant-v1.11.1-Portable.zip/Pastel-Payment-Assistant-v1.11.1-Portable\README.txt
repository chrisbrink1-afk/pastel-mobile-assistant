Pastel Payment Assistant v1.11.1 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.1.exe

Built using the same PyInstaller --onedir --windowed packaging method as v1.10.
v1.10 rules-backup CSV files remain compatible.

v1.11.1 matching hotfix:
- SMART rules match whole name tokens in sequence.
- Reference numbers must match when present in the saved rule.
- Transaction type text is excluded from SMART identity matching.
- Example: C E BRINK will not auto-allocate CHRIS BRINK.
