Pastel Payment Assistant v1.11.13 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.13.exe

v1.11.13 selection options:
- Select Auto-Allocated keeps selecting only automatic saved-rule allocations.
- Select Manual Allocations selects manual/corrected allocated rows that have a GL account and are not ambiguous.
- On Recurring Payments/Receipts, Select manual allocations applies only to recurring rows.
- Automatic and manual selection remain separate so you can choose exactly which class to export.

Retains saved-rule edits as automatic allocations, resizable/scrollable Rule windows, amount-review allocation controls, profiles, monthly references, and strict matching.
