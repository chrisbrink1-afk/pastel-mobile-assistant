Pastel Payment Assistant v1.11.4 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.4.exe

Built using the same PyInstaller --onedir --windowed packaging method as v1.10.
Existing v1.10/v1.11 rules and rule-backup CSV files remain compatible.

v1.11.4 amount-based allocation review mode:
- Amount rules now offer Automatically allocate OR Review each qualifying transaction.
- Review mode does not blanket-allocate amounts below/above the threshold.
- Each qualifying row is left unallocated and marked Amount review required.
- Use the Amount review filter, select a row, then Assign once to choose its GL account/description.
- Transactions that do not meet the amount condition still use the normal saved rule automatically.
- Export validation blocks qualifying review rows until each selected row has been assigned.
- Existing automatic amount-based GL/description behavior remains available.
- v1.11.2 global strict name/reference allocation safety remains enabled for all payments and receipts.
