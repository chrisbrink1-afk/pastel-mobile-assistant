Pastel Payment Assistant v2.0.1 Clean - Portable Windows Feedback Build

No Python installation is required. Keep the entire folder together.
Run: Pastel Payment Assistant v2.0.1 Clean.exe

- Contains no personal rules, settings, transaction history, profiles or bundled session.
- Uses the isolated PastelPaymentAssistantV2Feedback AppData namespace.
- Includes the Mary Hartslief recurrence grouping improvement and all v1.11.20 core fixes.
- Includes receipt positive-bank sign handling, autosave/resume, strict matching and hover help.
