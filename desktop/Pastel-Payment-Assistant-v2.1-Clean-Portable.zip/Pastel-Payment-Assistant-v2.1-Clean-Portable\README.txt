Pastel Payment Assistant v2.1 Clean - Portable Windows Feedback Build

No Python installation is required. Keep the entire folder together.
Run: Pastel Payment Assistant v2.1 Clean.exe

UI:
- Modern accounting-dashboard UI is the default for first-time users.
- Overview provides guided next steps and live statement cards.
- Classic UI remains available from the top-right switch.

Clean/shareable behavior:
- Contains no personal rules, settings, transaction history, company profiles or saved session.
- Uses the isolated PastelPaymentAssistantV2Feedback AppData location.
- Does not read or modify a v1.x Personal installation.
- Private bundled-rule bootstrap is disabled.
- New users can create their own profiles/rules/settings and their own sessions autosave normally.

Accounting behavior:
- Same receipt-sign, recurring-payee, strict-matching, additive-selection and validation fixes as Personal.
