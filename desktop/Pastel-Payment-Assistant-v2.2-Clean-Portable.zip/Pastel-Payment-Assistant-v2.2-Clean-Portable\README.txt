Pastel Payment Assistant v2.2 Clean - Portable Windows Feedback Build

Run: Pastel Payment Assistant v2.2 Clean.exe
No Python installation is required. Keep the entire extracted folder together.

Clean/shareable behavior:
- Contains no personal rules, settings, history, profiles or saved session.
- Uses isolated PastelPaymentAssistantV2Feedback AppData.
- Does not read or modify the Personal installation.
- Modern and Classic UI are both included.

Tutorial & Help:
- Opens automatically in a genuinely new Clean workspace.
- Can be skipped and rerun at any time.
- Adapts to current progress and includes searchable troubleshooting help.
