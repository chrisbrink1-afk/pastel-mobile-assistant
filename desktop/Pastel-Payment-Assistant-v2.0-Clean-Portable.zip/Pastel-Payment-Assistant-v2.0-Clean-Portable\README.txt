Pastel Payment Assistant v2.0 Clean - Portable Windows Feedback Build

No Python installation is required. Keep the entire folder together.
Run: Pastel Payment Assistant v2.0 Clean.exe

Clean/shareable build:
- Contains no personal rules, settings, transaction history, company profiles, saved statement or autosaved session.
- Uses its own isolated PastelPaymentAssistantV2Feedback AppData location, so it will not read or modify a v1.x Personal installation on the same PC.
- Private bundled-rule bootstrap is disabled.
- New users can create their own profiles/rules/settings and the app will autosave their own sessions normally.
- Includes the same receipt-sign fix, STOP ORDER HANDLING FEE matching fix, additive Auto+Manual selection, hover help and Rule-window scrolling as the Personal build.
