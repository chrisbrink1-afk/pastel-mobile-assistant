Pastel Payment Assistant v1.11.8 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.8.exe

Corrected amount review workflow:
- In the Assign/Edit Rule window, choose Review each qualifying transaction.
- A table appears directly underneath showing every current-statement transaction caught by that amount condition.
- Tick one or many rows and click Assign selected.
- Assign 3 rows to PETROL, then a different row to SURVEY, etc.
- Only the selected rows receive that allocation; unselected qualifying rows stay untouched.
- The old v1.11.7 main-screen Allocate column/button has been removed.

Retains company profiles, unique monthly Pastel references, amount descriptions, and strict allocation matching.
