Pastel Payment Assistant v1.11.12 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.12.exe

v1.11.12 allocation behavior:
- Saved rule edits remain automatic allocations after the rule is reapplied.
- Select Auto-Allocated and Select auto-allocated recurring tick those transactions.
- Statement-only corrections remain manual/corrected and are not selected automatically.
- Resizable and scrollable Rule windows are retained.
