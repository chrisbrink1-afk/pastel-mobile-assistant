Pastel Payment Assistant v1.11.21 Personal - Portable Windows

No Python installation is required. Keep the entire folder together.
Run: Pastel Payment Assistant v1.11.21 Personal.exe

UI:
- Modern accounting-dashboard UI is the default.
- Overview gives first-time users a guided five-step workflow and live statement cards.
- Left navigation provides Payments, Receipts, Recurring, Rules and Settings.
- Use Classic UI at the top-right to return to the familiar previous tabbed layout at any time.
- Modern and Classic use exactly the same company profiles, rules, settings, history and autosaved session.

Compatibility:
- Uses the existing PastelPaymentAssistant AppData location and preserves v1.11.20 Personal data.
- Receipt positive-bank-amount fix remains included.
- STOP ORDER HANDLING FEE blank-description fix remains included.
- Mary Hartslief recurring-payee grouping remains included.
- Auto + Manual export quick-selection remains additive.
