Pastel Payment Assistant v1.11.7 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.7.exe

Built using the same PyInstaller --onedir --windowed packaging method as v1.10.

v1.11.7 Amount Review multi-select allocation:
- Amount Review rows now show a separate Allocate checkbox next to the Export checkbox.
- Tick one or many Allocate boxes, then click Assign selected review items.
- Example: tick 3 rows and assign them to PETROL, then tick 1 different row and assign it to SURVEY.
- Only the checked Allocate rows are changed; all other qualifying Amount Review rows remain untouched.
- One checked row works exactly like a single-item assignment.
- The grouped assignment supports GL account, optional common Pastel description, VAT and tax type.
- Leaving grouped description blank preserves each selected row's existing description.

Retained features:
- v1.11.6 isolated company profiles.
- v1.11.5 unique monthly Pastel references such as P6-0001 / R6-0001, including same-date sequencing.
- v1.11.4 amount-review mode.
- v1.11.3 alternative amount descriptions.
- v1.11.2 global strict name/reference allocation safety for all payments and receipts.
