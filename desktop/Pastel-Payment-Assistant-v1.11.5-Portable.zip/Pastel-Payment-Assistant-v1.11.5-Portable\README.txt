Pastel Payment Assistant v1.11.5 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.5.exe

Built using the same PyInstaller --onedir --windowed packaging method as v1.10.
Existing rules/settings remain compatible.

v1.11.5 automatic Pastel references:
- Every individual payment receives a unique calendar-month sequence such as P6-0001, P6-0002, P6-0003.
- Multiple payments on the same date still receive separate consecutive references, ordered by the original bank-statement row.
- Receipts use a separate R sequence such as R6-0001, R6-0002.
- The sequence changes with the calendar month, e.g. July starts at P7-0001 / R7-0001.
- Saved-rule/manual reference text cannot override the generated transaction reference at export.
- Export validation blocks duplicate generated references.
- v1.11.4 amount-review mode and v1.11.2 global strict name/reference allocation safety remain enabled.
