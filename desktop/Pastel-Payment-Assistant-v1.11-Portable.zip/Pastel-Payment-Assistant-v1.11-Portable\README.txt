Pastel Payment Assistant v1.11 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.exe

Built using the same PyInstaller --onedir --windowed packaging method as v1.10.
v1.10 rules-backup CSV files import directly into v1.11.
New: descriptions, amount-based allocation, Select Auto-Allocated, and correction of false auto-allocations.
