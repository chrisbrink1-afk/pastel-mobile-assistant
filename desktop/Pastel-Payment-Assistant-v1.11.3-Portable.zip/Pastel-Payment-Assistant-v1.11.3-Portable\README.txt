Pastel Payment Assistant v1.11.3 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.3.exe

Built using the same PyInstaller --onedir --windowed packaging method as v1.10.
Existing v1.10/v1.11 rules and rule-backup CSV files remain compatible.

v1.11.3 amount-based allocation description:
- Amount-based allocation rules can now have an Alternative description.
- When the amount condition is met, both the alternative GL and alternative Pastel description are used.
- Leave Alternative description blank to use the normal rule description.
- When the condition is not met, the normal GL and normal description are used.
- Rule backup/export includes the new alternative description field.
- v1.11.2 global strict name/reference allocation safety remains enabled for all payments and receipts.
