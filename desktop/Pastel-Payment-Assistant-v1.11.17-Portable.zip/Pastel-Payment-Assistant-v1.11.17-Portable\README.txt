Pastel Payment Assistant v1.11.17 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.17.exe

v1.11.17 blank-description recurring fix:
- Standard Bank rows with a blank description/reference can use their transaction type as the recurring identity only when it exactly equals the saved canonical rule pattern.
- STOP ORDER HANDLING FEE with blank details therefore applies its saved identity rule automatically when a CSV is loaded.
- Generic/partial blank-detail patterns are rejected; strict matching remains in place for normal transactions.
- Recurring child rows continue to inherit saved GL/VAT/description immediately after editing a rule.
- Auto and Manual quick-select actions remain additive.
- Grouped controls, hover ? help, profiles, amount review and resizable/scrollable Rule windows remain available.
