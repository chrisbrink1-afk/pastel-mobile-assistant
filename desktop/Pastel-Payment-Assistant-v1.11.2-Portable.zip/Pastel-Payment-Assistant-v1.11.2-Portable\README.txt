Pastel Payment Assistant v1.11.2 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.2.exe

Built using the same PyInstaller --onedir --windowed packaging method as v1.10.
v1.10/v1.11 rules-backup CSV files remain compatible.

v1.11.2 global allocation safety:
- Every automatic rule mode must pass strict name/reference identity matching.
- Applies to ALL payments and ALL receipts.
- SMART, Contains, Starts With and Exact cannot bypass the identity safety gate.
- Transaction type text is never used to create an identity match.
- Similar names such as C E BRINK and CHRIS BRINK remain separate.
- Saved reference numbers must match when present.
