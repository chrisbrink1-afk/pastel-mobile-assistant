Pastel Payment Assistant v1.11.18 - Portable Windows

No Python installation is required.
Keep this entire folder together.
Run: Pastel Payment Assistant v1.11.18.exe

v1.11.18 Pastel receipt sign fix:
- Payments keep a positive GL-side Amount/Home Amount in the Pastel import file.
- Receipts use a negative GL-side Amount/Home Amount, causing Pastel to show a positive Bank Amount on the Receipts tab.
- Receipt VAT/tax amounts use the same credit sign so the imported accounting entry remains balanced.
- Zero tax remains 0.00 rather than -0.00.
- All v1.11.17 recurring matching, rule, selection, profile and UI improvements remain available.
